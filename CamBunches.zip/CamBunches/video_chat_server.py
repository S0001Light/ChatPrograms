import socket
import threading
import json
import queue
import os
import struct


# ============================================================
# CONFIGURATION
# ============================================================

HOST = "0.0.0.0"

# Camera/chat server
CHAT_PORT = 5000

# File server
FILE_PORT = 5001

MAX_CLIENTS = 20

MAX_PACKET_SIZE = 2_000_000
MAX_USERNAME_LENGTH = 24
MAX_CHAT_LENGTH = 500

# Maximum uploaded file size: 100 MB
MAX_FILE_SIZE = 100 * 1024 * 1024

# File transfer chunk size
FILE_BUFFER_SIZE = 64 * 1024


# ============================================================
# SHARED FILE DIRECTORY
# ============================================================

BASE_DIR = os.path.dirname(
    os.path.abspath(__file__)
)

SHARED_DIR = os.path.join(
    BASE_DIR,
    "shared_files"
)

os.makedirs(
    SHARED_DIR,
    exist_ok=True
)


# ============================================================
# CHAT CLIENT STORAGE
# ============================================================

clients = {}

clients_lock = threading.Lock()

next_client_id = 1


# ============================================================
# CHAT NETWORK HELPERS
# ============================================================

def recv_exact(sock, size):
    data = bytearray()

    while len(data) < size:
        chunk = sock.recv(
            size - len(data)
        )

        if not chunk:
            raise ConnectionError(
                "Socket closed"
            )

        data.extend(chunk)

    return bytes(data)


def pack_packet(
    packet_type,
    payload=b""
):
    return (
        packet_type
        + len(payload).to_bytes(
            4,
            "big"
        )
        + payload
    )


# ============================================================
# CHAT CLIENT OBJECT
# ============================================================

class ClientConnection:

    def __init__(
        self,
        client_id,
        sock,
        address
    ):
        self.id = client_id

        self.sock = sock

        self.address = address

        self.username = (
            f"User {client_id}"
        )

        self.icon_color = [
            200,
            200,
            200
        ]

        self.alive = True

        self.outbox = queue.Queue(
            maxsize=256
        )

    # --------------------------------------------------------
    # QUEUE PACKET
    # --------------------------------------------------------

    def enqueue(
        self,
        packet,
        is_video=False
    ):
        if not self.alive:
            return

        try:
            self.outbox.put_nowait(
                packet
            )

        except queue.Full:

            # If this is video, simply drop the frame.
            # We want current frames rather than a huge backlog.
            if is_video:
                return

            # Try to make room for important packets.
            try:
                self.outbox.get_nowait()
            except queue.Empty:
                pass

            try:
                self.outbox.put_nowait(
                    packet
                )
            except queue.Full:
                pass

    # --------------------------------------------------------
    # WRITER THREAD
    # --------------------------------------------------------

    def writer_loop(self):

        try:

            while self.alive:

                packet = self.outbox.get()

                if packet is None:
                    break

                self.sock.sendall(
                    packet
                )

        except (
            OSError,
            ConnectionError,
            ConnectionResetError,
            BrokenPipeError
        ):
            pass

        finally:
            disconnect_client(
                self.id
            )


# ============================================================
# CHAT BROADCAST
# ============================================================

def broadcast_raw(
    packet,
    exclude_client_id=None,
    is_video=False
):

    with clients_lock:
        targets = list(
            clients.values()
        )

    for client in targets:

        if (
            exclude_client_id
            is not None
            and
            client.id
            == exclude_client_id
        ):
            continue

        client.enqueue(
            packet,
            is_video=is_video
        )


def broadcast_from_sender(
    packet_type,
    sender_id,
    payload,
    exclude_client_id=None,
    is_video=False
):

    full_payload = (
        sender_id.to_bytes(
            4,
            "big"
        )
        + payload
    )

    packet = pack_packet(
        packet_type,
        full_payload
    )

    broadcast_raw(
        packet,
        exclude_client_id,
        is_video
    )


# ============================================================
# USER INFORMATION
# ============================================================

def clean_username(
    value,
    fallback
):

    username = str(value).strip()

    if not username:
        return fallback

    return username[
        :MAX_USERNAME_LENGTH
    ]


def clean_icon_color(value):

    if not isinstance(
        value,
        (list, tuple)
    ):
        return [
            200,
            200,
            200
        ]

    if len(value) < 3:
        return [
            200,
            200,
            200
        ]

    cleaned = []

    for component in value[:3]:

        try:
            component = int(
                component
            )

        except (
            TypeError,
            ValueError
        ):
            component = 200

        component = max(
            0,
            min(
                255,
                component
            )
        )

        cleaned.append(
            component
        )

    return cleaned


def make_roster_payload(client):

    info = {
        "id": client.id,
        "username": client.username,
        "icon_color": client.icon_color
    }

    return json.dumps(
        info
    ).encode("utf-8")


def send_roster(client):

    with clients_lock:
        roster = list(
            clients.values()
        )

    for other in roster:

        payload = make_roster_payload(
            other
        )

        client.enqueue(
            pack_packet(
                b"J",
                payload
            )
        )


def broadcast_userinfo(client):

    info = {
        "username": client.username,
        "icon_color": client.icon_color
    }

    payload = json.dumps(
        info
    ).encode("utf-8")

    broadcast_from_sender(
        b"U",
        client.id,
        payload
    )


# ============================================================
# CHAT CLIENT DISCONNECT
# ============================================================

def disconnect_client(
    client_id
):

    with clients_lock:

        client = clients.pop(
            client_id,
            None
        )

    if client is None:
        return

    client.alive = False

    try:
        client.outbox.put_nowait(
            None
        )
    except queue.Full:
        pass

    try:
        client.sock.shutdown(
            socket.SHUT_RDWR
        )
    except OSError:
        pass

    try:
        client.sock.close()
    except OSError:
        pass

    # Tell everyone this client left.
    leave_packet = pack_packet(
        b"L",
        client_id.to_bytes(
            4,
            "big"
        )
    )

    broadcast_raw(
        leave_packet
    )

    print(
        f"Disconnected client "
        f"{client_id}: "
        f"{client.username}"
    )


# ============================================================
# CHAT CLIENT THREAD
# ============================================================

def handle_chat_client(client):

    try:

        # ----------------------------------------------------
        # SEND CLIENT ID
        # ----------------------------------------------------

        client.enqueue(
            pack_packet(
                b"I",
                client.id.to_bytes(
                    4,
                    "big"
                )
            )
        )

        # ----------------------------------------------------
        # SEND EXISTING USERS
        # ----------------------------------------------------

        send_roster(
            client
        )

        # ----------------------------------------------------
        # ANNOUNCE NEW USER
        # ----------------------------------------------------

        broadcast_userinfo(
            client
        )

        # ----------------------------------------------------
        # RECEIVE LOOP
        # ----------------------------------------------------

        while client.alive:

            header = recv_exact(
                client.sock,
                5
            )

            packet_type = (
                header[:1]
            )

            payload_length = (
                int.from_bytes(
                    header[1:5],
                    "big"
                )
            )

            if (
                payload_length
                > MAX_PACKET_SIZE
            ):
                raise ValueError(
                    "Packet too large"
                )

            payload = recv_exact(
                client.sock,
                payload_length
            )

            # =================================================
            # USER INFORMATION
            # =================================================

            if packet_type == b"U":

                info = json.loads(
                    payload.decode(
                        "utf-8"
                    )
                )

                client.username = (
                    clean_username(
                        info.get(
                            "username"
                        ),
                        client.username
                    )
                )

                client.icon_color = (
                    clean_icon_color(
                        info.get(
                            "icon_color"
                        )
                    )
                )

                broadcast_userinfo(
                    client
                )

                print(
                    f"User "
                    f"{client.id}: "
                    f"{client.username}"
                )

            # =================================================
            # CHAT
            # =================================================

            elif packet_type == b"T":

                message = (
                    payload.decode(
                        "utf-8",
                        errors="replace"
                    ).strip()
                )

                if not message:
                    continue

                message = message[
                    :MAX_CHAT_LENGTH
                ]

                broadcast_from_sender(
                    b"T",
                    client.id,
                    message.encode(
                        "utf-8"
                    )
                )

                print(
                    f"[{client.id}] "
                    f"{client.username}: "
                    f"{message}"
                )

            # =================================================
            # VIDEO
            # =================================================

            elif packet_type == b"V":

                broadcast_from_sender(
                    b"V",
                    client.id,
                    payload,
                    exclude_client_id=client.id,
                    is_video=True
                )

            else:

                print(
                    "Unknown packet from "
                    f"client {client.id}: "
                    f"{packet_type!r}"
                )

    except (
        OSError,
        ConnectionError,
        ConnectionResetError,
        BrokenPipeError,
        ValueError,
        json.JSONDecodeError
    ) as error:

        print(
            f"Client {client.id} "
            f"connection ended: "
            f"{error}"
        )

    finally:

        disconnect_client(
            client.id
        )


# ============================================================
#
#                    FILE SERVER
#
# ============================================================


# ============================================================
# FILE NETWORK HELPERS
# ============================================================

def file_recv_exact(
    sock,
    size
):

    data = bytearray()

    while len(data) < size:

        chunk = sock.recv(
            size - len(data)
        )

        if not chunk:

            raise ConnectionError(
                "File connection closed"
            )

        data.extend(
            chunk
        )

    return bytes(data)


# ============================================================
# SAFE FILE NAME
# ============================================================

def safe_filename(filename):

    filename = os.path.basename(
        filename
    )

    filename = filename.replace(
        "\x00",
        ""
    )

    filename = filename.strip()

    return filename[:255]


# ============================================================
# SEND FILE CONTROL PACKET
# ============================================================

def send_file_packet(
    sock,
    packet_type,
    payload=b""
):

    packet = (
        packet_type
        + struct.pack(
            "!Q",
            len(payload)
        )
        + payload
    )

    sock.sendall(
        packet
    )


# ============================================================
# GET FILE LIST
# ============================================================

def get_shared_files():

    file_list = []

    try:

        directory_items = (
            os.listdir(
                SHARED_DIR
            )
        )

    except OSError as error:

        print(
            "Could not read "
            f"shared_files: {error}"
        )

        return file_list

    for filename in directory_items:

        filepath = os.path.join(
            SHARED_DIR,
            filename
        )

        if not os.path.isfile(
            filepath
        ):
            continue

        try:

            file_size = (
                os.path.getsize(
                    filepath
                )
            )

            file_list.append({
                "name": filename,
                "size": file_size
            })

        except OSError:
            continue

    file_list.sort(
        key=lambda item:
        item["name"].lower()
    )

    return file_list


# ============================================================
# SEND FILE LIST
# ============================================================

def send_file_list(conn):

    file_list = get_shared_files()

    payload = json.dumps(
        file_list
    ).encode("utf-8")

    send_file_packet(
        conn,
        b"L",
        payload
    )


# ============================================================
# RECEIVE FILE UPLOAD
# ============================================================

def receive_upload(conn):

    # --------------------------------------------------------
    # RECEIVE FILENAME LENGTH
    # --------------------------------------------------------

    name_length_data = (
        file_recv_exact(
            conn,
            2
        )
    )

    name_length = struct.unpack(
        "!H",
        name_length_data
    )[0]

    if (
        name_length <= 0
        or
        name_length > 255
    ):

        raise ValueError(
            "Invalid filename length"
        )

    # --------------------------------------------------------
    # RECEIVE FILENAME
    # --------------------------------------------------------

    name_data = file_recv_exact(
        conn,
        name_length
    )

    filename = name_data.decode(
        "utf-8",
        errors="replace"
    )

    filename = safe_filename(
        filename
    )

    if not filename:

        raise ValueError(
            "Invalid filename"
        )

    # --------------------------------------------------------
    # RECEIVE FILE SIZE
    # --------------------------------------------------------

    size_data = file_recv_exact(
        conn,
        8
    )

    file_size = struct.unpack(
        "!Q",
        size_data
    )[0]

    if file_size > MAX_FILE_SIZE:

        raise ValueError(
            "File exceeds "
            "maximum upload size"
        )

    # --------------------------------------------------------
    # CREATE OUTPUT PATH
    # --------------------------------------------------------

    save_path = os.path.join(
        SHARED_DIR,
        filename
    )

    print(
        f"Receiving upload: "
        f"{filename} "
        f"({file_size} bytes)"
    )

    # --------------------------------------------------------
    # RECEIVE FILE
    # --------------------------------------------------------

    remaining = file_size

    try:

        with open(
            save_path,
            "wb"
        ) as output_file:

            while remaining > 0:

                chunk = conn.recv(
                    min(
                        FILE_BUFFER_SIZE,
                        remaining
                    )
                )

                if not chunk:

                    raise ConnectionError(
                        "Upload interrupted"
                    )

                output_file.write(
                    chunk
                )

                remaining -= len(
                    chunk
                )

    except Exception:

        # Delete incomplete upload.
        try:
            if os.path.isfile(
                save_path
            ):
                os.remove(
                    save_path
                )
        except OSError:
            pass

        raise

    print(
        f"Upload completed: "
        f"{filename}"
    )

    send_file_packet(
        conn,
        b"O",
        b"Upload complete"
    )


# ============================================================
# SEND FILE DOWNLOAD
# ============================================================

def send_download(
    conn,
    requested_filename
):

    filename = safe_filename(
        requested_filename
    )

    if not filename:

        send_file_packet(
            conn,
            b"E",
            b"Invalid filename"
        )

        return

    filepath = os.path.join(
        SHARED_DIR,
        filename
    )

    if not os.path.isfile(
        filepath
    ):

        send_file_packet(
            conn,
            b"E",
            b"File not found"
        )

        return

    filename_data = (
        filename.encode(
            "utf-8"
        )
    )

    file_size = os.path.getsize(
        filepath
    )

    print(
        f"Sending download: "
        f"{filename} "
        f"({file_size} bytes)"
    )

    # --------------------------------------------------------
    # DOWNLOAD HEADER
    #
    # D
    # 2 bytes filename length
    # filename bytes
    # 8 bytes file length
    # file bytes
    # --------------------------------------------------------

    conn.sendall(
        b"D"
    )

    conn.sendall(
        struct.pack(
            "!H",
            len(filename_data)
        )
    )

    conn.sendall(
        filename_data
    )

    conn.sendall(
        struct.pack(
            "!Q",
            file_size
        )
    )

    # --------------------------------------------------------
    # STREAM FILE
    # --------------------------------------------------------

    with open(
        filepath,
        "rb"
    ) as input_file:

        while True:

            chunk = input_file.read(
                FILE_BUFFER_SIZE
            )

            if not chunk:
                break

            conn.sendall(
                chunk
            )

    print(
        f"Download completed: "
        f"{filename}"
    )


# ============================================================
# FILE CLIENT HANDLER
# ============================================================

def handle_file_client(
    conn,
    address
):

    print(
        f"File client connected: "
        f"{address}"
    )

    try:

        while True:

            # One-byte command.
            command = file_recv_exact(
                conn,
                1
            )

            # =================================================
            # LIST FILES
            # =================================================

            if command == b"L":

                send_file_list(
                    conn
                )

            # =================================================
            # UPLOAD
            # =================================================

            elif command == b"U":

                receive_upload(
                    conn
                )

            # =================================================
            # DOWNLOAD
            # =================================================

            elif command == b"D":

                # Filename length.
                name_length_data = (
                    file_recv_exact(
                        conn,
                        2
                    )
                )

                name_length = (
                    struct.unpack(
                        "!H",
                        name_length_data
                    )[0]
                )

                if (
                    name_length <= 0
                    or
                    name_length > 255
                ):

                    raise ValueError(
                        "Invalid filename"
                    )

                # Filename.
                name_data = (
                    file_recv_exact(
                        conn,
                        name_length
                    )
                )

                requested_filename = (
                    name_data.decode(
                        "utf-8",
                        errors="replace"
                    )
                )

                send_download(
                    conn,
                    requested_filename
                )

            else:

                raise ValueError(
                    "Unknown file command"
                )

    except (
        OSError,
        ConnectionError,
        ConnectionResetError,
        BrokenPipeError
    ):

        pass

    except ValueError as error:

        print(
            f"File client error "
            f"{address}: "
            f"{error}"
        )

        try:

            send_file_packet(
                conn,
                b"E",
                str(error).encode(
                    "utf-8"
                )
            )

        except OSError:
            pass

    finally:

        try:

            conn.shutdown(
                socket.SHUT_RDWR
            )

        except OSError:
            pass

        try:

            conn.close()

        except OSError:
            pass

        print(
            f"File client disconnected: "
            f"{address}"
        )


# ============================================================
# FILE SERVER MAIN
# ============================================================

def file_server_main():

    file_server_socket = socket.socket(
        socket.AF_INET,
        socket.SOCK_STREAM
    )

    file_server_socket.setsockopt(
        socket.SOL_SOCKET,
        socket.SO_REUSEADDR,
        1
    )

    file_server_socket.bind(
        (
            HOST,
            FILE_PORT
        )
    )

    file_server_socket.listen(
        MAX_CLIENTS
    )

    print(
        f"File server listening "
        f"on port {FILE_PORT}"
    )

    print(
        f"Shared directory: "
        f"{SHARED_DIR}"
    )

    try:

        while True:

            connection, address = (
                file_server_socket.accept()
            )

            connection.setsockopt(
                socket.IPPROTO_TCP,
                socket.TCP_NODELAY,
                1
            )

            thread = threading.Thread(
                target=handle_file_client,
                args=(
                    connection,
                    address
                ),
                daemon=True,
                name=(
                    f"FileClient-"
                    f"{address[0]}"
                )
            )

            thread.start()

    except Exception as error:

        print(
            f"File server stopped: "
            f"{error}"
        )

    finally:

        try:
            file_server_socket.close()
        except OSError:
            pass


# ============================================================
# CHAT / CAMERA SERVER MAIN
# ============================================================

def main():

    global next_client_id

    # --------------------------------------------------------
    # START FILE SERVER
    # --------------------------------------------------------

    file_thread = threading.Thread(
        target=file_server_main,
        daemon=True,
        name="FileServer"
    )

    file_thread.start()

    # --------------------------------------------------------
    # START CHAT/CAMERA SERVER
    # --------------------------------------------------------

    chat_server_socket = socket.socket(
        socket.AF_INET,
        socket.SOCK_STREAM
    )

    chat_server_socket.setsockopt(
        socket.SOL_SOCKET,
        socket.SO_REUSEADDR,
        1
    )

    chat_server_socket.bind(
        (
            HOST,
            CHAT_PORT
        )
    )

    chat_server_socket.listen(
        MAX_CLIENTS
    )

    print("=" * 60)
    print("CamBunches Server")
    print("=" * 60)

    print(
        f"Chat / Camera port: "
        f"{CHAT_PORT}"
    )

    print(
        f"File Server port: "
        f"{FILE_PORT}"
    )

    print(
        f"Maximum users: "
        f"{MAX_CLIENTS}"
    )

    print(
        f"Shared folder: "
        f"{SHARED_DIR}"
    )

    print("=" * 60)

    try:

        while True:

            client_socket, address = (
                chat_server_socket.accept()
            )

            client_socket.setsockopt(
                socket.IPPROTO_TCP,
                socket.TCP_NODELAY,
                1
            )

            # ------------------------------------------------
            # CHECK SERVER CAPACITY
            # ------------------------------------------------

            with clients_lock:

                if (
                    len(clients)
                    >= MAX_CLIENTS
                ):

                    try:

                        client_socket.sendall(
                            pack_packet(
                                b"E",
                                b"Server is full"
                            )
                        )

                    except OSError:
                        pass

                    client_socket.close()

                    print(
                        f"Rejected {address}: "
                        f"server full"
                    )

                    continue

                # --------------------------------------------
                # ASSIGN USER ID
                # --------------------------------------------

                client_id = (
                    next_client_id
                )

                next_client_id += 1

                client = ClientConnection(
                    client_id,
                    client_socket,
                    address
                )

                clients[
                    client_id
                ] = client

            # ------------------------------------------------
            # START CLIENT WRITER
            # ------------------------------------------------

            writer_thread = (
                threading.Thread(
                    target=(
                        client.writer_loop
                    ),
                    daemon=True,
                    name=(
                        f"Writer-"
                        f"{client_id}"
                    )
                )
            )

            # ------------------------------------------------
            # START CLIENT READER
            # ------------------------------------------------

            reader_thread = (
                threading.Thread(
                    target=(
                        handle_chat_client
                    ),
                    args=(client,),
                    daemon=True,
                    name=(
                        f"Reader-"
                        f"{client_id}"
                    )
                )
            )

            writer_thread.start()
            reader_thread.start()

            print(
                f"Camera/chat client "
                f"{client_id} connected "
                f"from {address}"
            )

    except KeyboardInterrupt:

        print(
            "\nStopping CamBunches..."
        )

    finally:

        with clients_lock:
            remaining_ids = list(
                clients.keys()
            )

        for client_id in remaining_ids:

            disconnect_client(
                client_id
            )

        try:

            chat_server_socket.close()

        except OSError:
            pass

        print(
            "CamBunches stopped."
        )


# ============================================================
# START
# ============================================================

if __name__ == "__main__":
    main()
