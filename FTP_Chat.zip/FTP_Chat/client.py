#!/usr/bin/env python3
import base64,io,json,os,queue,socket,struct,threading,time
import tkinter as tk
from tkinter import filedialog,messagebox,simpledialog,ttk
try: from PIL import Image,ImageTk
except ImportError: Image=ImageTk=None
DISCOVERY_PORT=5052;DISCOVERY_QUERY=b'WIFI_TLS_SHARE_DISCOVER_V1';DISCOVERY_REPLY_PREFIX='WIFI_TLS_SHARE_HERE_V1';MAX_PACKET=128*1024*1024;CHUNK_SIZE=1024*1024
def recv_exact(s,n):
 b=bytearray()
 while len(b)<n:
  x=s.recv(n-len(b))
  if not x:raise ConnectionError('connection closed')
  b.extend(x)
 return bytes(b)
def recv_packet(s):
 n=struct.unpack('!I',recv_exact(s,4))[0]
 if n<1 or n>MAX_PACKET:raise ValueError('invalid packet size')
 mode=recv_exact(s,1)
 if mode==b'\x00':return json.loads(recv_exact(s,n-1).decode()),None
 if mode==b'\x01':
  m=recv_exact(s,5);size=struct.unpack('!I',m[:4])[0]
  if size!=n-6:raise ValueError('binary chunk mismatch')
  return {'op':'chunk_data','last':m[4]==1},recv_exact(s,size)
 raise ValueError('unknown protocol framing')
def send_packet(s,o,raw_binary=None):
 if raw_binary is None:
  b=json.dumps(o,ensure_ascii=False).encode();s.sendall(struct.pack('!I',len(b)+1)+b'\x00'+b)
 else:
  h=struct.pack('!I',len(raw_binary))+(b'\x01' if o.get('last') else b'\x00');s.sendall(struct.pack('!I',len(raw_binary)+6)+b'\x01'+h+raw_binary)
def normalize_host(value):
 value=str(value or '').strip()
 while '..' in value:value=value.replace('..','.')
 return value.strip('.')
class App(tk.Tk):
 def __init__(self):
  super().__init__();self.title('Wi-Fi Message File Share + Diagnostics');self.geometry('1000x700');self.sock=None;self.send_lock=threading.Lock();self.events=queue.Queue();self.pending={};self.seq=0;self.remote='';self.icon_data='';self.photos={};self.downloads={};self.active_download=None;self.connecting=False;self.build();self.after(100,self.poll);self.protocol('WM_DELETE_WINDOW',self.close)
 def diag(self,msg):
  line=time.strftime('%H:%M:%S')+' '+msg;print(line,flush=True);self.events.put(('diag',line))
 def build(self):
  f=ttk.LabelFrame(self,text='Connection');f.pack(fill='x',padx=8,pady=8);self.host=tk.StringVar();self.port=tk.StringVar(value='5051');self.user=tk.StringVar(value='admin');self.pw=tk.StringVar()
  for i,(n,v,w) in enumerate([('Server Wi-Fi IP',self.host,18),('Port',self.port,7),('Username',self.user,14),('Password',self.pw,14)]):ttk.Label(f,text=n).grid(row=0,column=i*2,padx=3);ttk.Entry(f,textvariable=v,width=w,show='*' if n=='Password' else '').grid(row=0,column=i*2+1,padx=3)
  ttk.Button(f,text='Find server',command=self.find_server).grid(row=0,column=8);ttk.Button(f,text='Message Ping',command=self.tls_ping).grid(row=0,column=9);ttk.Button(f,text='Connect',command=self.connect).grid(row=0,column=10);ttk.Button(f,text='Disconnect',command=self.disconnect).grid(row=0,column=11)
  n=ttk.Notebook(self);n.pack(fill='both',expand=True,padx=8);files=ttk.Frame(n);chat=ttk.Frame(n);diag=ttk.Frame(n);n.add(files,text='Files');n.add(chat,text='Chat');n.add(diag,text='Diagnostics')
  bar=ttk.Frame(files);bar.pack(fill='x');self.path=ttk.Label(bar,text='/');self.path.pack(side='left')
  for t,c in [('Up',self.up),('Refresh',self.refresh),('Upload',self.upload),('Download',self.download),('New folder',self.mkdir),('Delete',self.delete)]:ttk.Button(bar,text=t,command=c).pack(side='left')
  self.tree=ttk.Treeview(files,columns=('type','size'),show='tree headings');self.tree.heading('#0',text='Name');self.tree.heading('type',text='Type');self.tree.heading('size',text='Size');self.tree.pack(fill='both',expand=True);self.tree.bind('<Double-1>',lambda e:self.open_folder())
  self.log_txt=tk.Text(chat,state='disabled');self.log_txt.pack(fill='both',expand=True);r=ttk.Frame(chat);r.pack(fill='x');self.msg=tk.StringVar();e=ttk.Entry(r,textvariable=self.msg);e.pack(side='left',fill='x',expand=True);e.bind('<Return>',lambda e:self.send_chat());ttk.Button(r,text='Send',command=self.send_chat).pack(side='left');self.roster=tk.Listbox(chat,height=5);self.roster.pack(fill='x')
  self.diag_txt=tk.Text(diag,state='disabled');self.diag_txt.pack(fill='both',expand=True);self.progress=ttk.Progressbar(self,mode='determinate');self.progress.pack(fill='x',padx=8);self.status=tk.StringVar(value='Disconnected');ttk.Label(self,textvariable=self.status).pack(fill='x')
 def local_ipv4_addresses(self):
  out=[]
  def add(ip):
   if ip and not ip.startswith(('127.','169.254.')) and ip not in out:out.append(ip)
  try:
   for x in socket.getaddrinfo(socket.gethostname(),None,socket.AF_INET,socket.SOCK_STREAM):add(x[4][0])
  except:pass
  if os.name=='nt':
   try:
    import re,subprocess
    for ip in re.findall(r'IPv4[^:]*:\s*([0-9]+(?:\.[0-9]+){3})',subprocess.check_output(['ipconfig'],text=True,errors='ignore'),re.I):add(ip)
   except:pass
  return out
 def tls_discovery_probe(self,ip,port,ping_only=False,connect_timeout=3.0):
  sock=None;tcp=False
  try:
   self.diag('[TEST] TCP message connect -> %s:%d'%(ip,port))
   sock=socket.create_connection((ip,port),connect_timeout);tcp=True
   self.diag('[TEST] TCP message connection OK')
   sock.settimeout(8)
   send_packet(sock,{'type':'ping' if ping_only else 'discovery','probe':'wifi_tls_share'})
   self.diag('[TEST] framed message sent')
   reply,b=recv_packet(sock);self.diag('[TEST] RX %r'%reply)
   expected='pong' if ping_only else 'discovery_reply'
   return b is None and isinstance(reply,dict) and reply.get('type')==expected and reply.get('service')=='wifi_tls_share',tcp,None
  except Exception as e:
   self.diag('[TEST] FAIL %s: %s'%(type(e).__name__,e));return False,tcp,'%s: %s'%(type(e).__name__,e)
  finally:
   if sock:
    try:sock.close()
    except:pass
 def find_server(self):
  if self.connecting:return
  self.connecting=True
  local_ips=set(self.local_ipv4_addresses())
  self.status.set('Broadcasting discovery on every LAN adapter...')
  self.diag('[BROADCAST] local adapters: %s'%(', '.join(sorted(local_ips)) or 'none'))
  def work():
   replies=[];replies_lock=threading.Lock();listeners=[]
   def listen_on(local_ip):
    sock=socket.socket(socket.AF_INET,socket.SOCK_DGRAM,socket.IPPROTO_UDP)
    sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
    sock.setsockopt(socket.SOL_SOCKET,socket.SO_BROADCAST,1)
    sock.bind((local_ip,0))
    sock.settimeout(0.5)
    self.diag('[BROADCAST] socket %s:%d'%(local_ip,sock.getsockname()[1]))
    deadline=time.monotonic()+5.0
    targets=[('255.255.255.255',DISCOVERY_PORT),(local_ip.rsplit('.',1)[0]+'.255',DISCOVERY_PORT)]
    for attempt in range(1,4):
     for target in targets:
      try:
       sock.sendto(DISCOVERY_QUERY,target)
       self.diag('[BROADCAST] TX attempt %d from %s -> %s:%d'%(attempt,local_ip,target[0],target[1]))
      except OSError as e:self.diag('[BROADCAST] TX FAIL from %s -> %s: %s'%(local_ip,target[0],e))
     wait_until=min(deadline,time.monotonic()+1.0)
     while time.monotonic()<wait_until:
      try:data,address=sock.recvfrom(2048)
      except socket.timeout:break
      self.diag('[BROADCAST] RX from %s:%d data=%r'%(address[0],address[1],data))
      try:
       prefix,port_text=data.decode('ascii').split('|',1);port=int(port_text)
      except (UnicodeDecodeError,ValueError):continue
      if prefix!=DISCOVERY_REPLY_PREFIX:continue
      if address[0] in local_ips or address[0].startswith('127.'):
       self.diag('[BROADCAST] ignored local reply from %s'%address[0]);continue
      with replies_lock:
       if (address[0],port) not in replies:replies.append((address[0],port))
    sock.close()
   threads=[threading.Thread(target=listen_on,args=(ip,),daemon=True) for ip in sorted(local_ips)]
   if not threads:
    self.connecting=False;self.events.put(('error','No usable LAN IPv4 adapter was detected.'));return
   for t in threads:t.start()
   for t in threads:t.join()
   self.diag('[BROADCAST] replies: %r'%replies)
   verified=None
   for ip,port in replies:
    ok,tcp,error=self.tls_discovery_probe(ip,port,True,connect_timeout=3.0)
    if ok:verified=(ip,port);break
    self.diag('[BROADCAST] reply rejected %s:%d tcp=%s error=%s'%(ip,port,tcp,error))
   self.connecting=False
   if verified:
    ip,port=verified
    self.after(0,lambda value=ip:self.host.set(value))
    self.after(0,lambda value=str(port):self.port.set(value))
    self.events.put(('status','Broadcast found and message-verified remote server at %s:%d'%(ip,port)))
    self.diag('[BROADCAST] VERIFIED %s:%d'%(ip,port))
   else:
    self.events.put(('error','No remote server answered the UDP broadcast or passed TLS verification. Allow inbound UDP 5052 and TCP 5051 on the server.'))
  threading.Thread(target=work,daemon=True).start()
 def tls_ping(self):
  host=normalize_host(self.host.get())
  self.host.set(host)
  try:p=int(self.port.get())
  except:return
  if not host:return messagebox.showwarning('Message Ping','Enter server IP first')
  threading.Thread(target=lambda:self.events.put(('status','Message Ping OK' if self.tls_discovery_probe(host,p,True)[0] else 'TLS Ping failed')),daemon=True).start()
 def connect(self):
  host=normalize_host(self.host.get());self.host.set(host)
  if not host:return self.find_server()
  if host in set(self.local_ipv4_addresses()) or host.startswith('127.'):
   return messagebox.showwarning('Connection','That address belongs to this computer. Enter or discover the network computer instead.')
  try:p=int(self.port.get())
  except:return
  self.connecting=True;threading.Thread(target=self._connect,args=(host,p),daemon=True).start()
 def _connect(self,host,p):
  raw=tls=None
  try:
   self.diag('[LOGIN] TCP -> %s:%d'%(host,p));raw=socket.create_connection((host,p),10);raw.settimeout(15);tls=raw;raw=None;self.diag('[LOGIN] plain TCP message connection OK');send_packet(tls,{'username':self.user.get().strip(),'password':self.pw.get(),'icon':self.icon_data});hello,b=recv_packet(tls);self.diag('[LOGIN] RX %r'%hello)
   if b is not None or not hello.get('ok'):raise RuntimeError(hello.get('error','Login failed'))
   tls.settimeout(None);self.sock=tls;self.events.put(('connected',None));threading.Thread(target=self.reader,args=(tls,),daemon=True).start()
  except Exception as e:self.events.put(('error','%s: %s'%(type(e).__name__,e)))
  finally:self.connecting=False
 def reader(self,s):
  try:
   while True:self.events.put(('packet',recv_packet(s)))
  except Exception as e:self.events.put(('error','Disconnected: '+repr(e)))
 def request(self,op,**kw):
  if not self.sock:return None
  with self.send_lock:self.seq+=1;i=self.seq;q=queue.Queue();self.pending[i]=q;d={'op':op,'id':i};d.update(kw);send_packet(self.sock,d);return q
 def async_request(self,op,callback=None,**kw):
  def w():
   try:
    q=self.request(op,**kw)
    if not q:return
    r=q.get(timeout=60)
    if not r.get('ok'):raise RuntimeError(r.get('error','Request failed'))
    if callback:self.after(0,lambda:callback(r))
   except Exception as e:self.events.put(('error',str(e)))
  threading.Thread(target=w,daemon=True).start()
 def poll(self):
  try:
   while True:
    k,p=self.events.get_nowait()
    if k=='diag':self.diag_txt.config(state='normal');self.diag_txt.insert('end',p+'\n');self.diag_txt.see('end');self.diag_txt.config(state='disabled')
    elif k=='connected':self.status.set('Connected securely');self.remote='';self.refresh()
    elif k=='error':self.status.set(p);messagebox.showerror('Connection',p)
    elif k=='status':self.status.set(p)
    elif k=='progress':self.progress['value']=p
    elif k=='packet':
     d,raw=p
     if d.get('type')=='reply':
      q=self.pending.pop(d.get('id'),None)
      if q:q.put(d)
     elif d.get('type')=='roster':self.roster.delete(0,'end');[self.roster.insert('end',x.get('username','')) for x in d.get('users',[])]
     elif d.get('type')=='download_start':self._start_download(d)
     elif d.get('op')=='chunk_data':self._accept_download_chunk(d,raw)
     else:self.log_txt.config(state='normal');self.log_txt.insert('end',(d.get('username','')+': ' if d.get('type')=='message' else '*** ')+d.get('text','')+'\n');self.log_txt.config(state='disabled')
  except queue.Empty:pass
  self.after(100,self.poll)
 def refresh(self):self.async_request('list',lambda r:self.render(r['rows']),path=self.remote)
 def render(self,rows):
  self.tree.delete(*self.tree.get_children());self.path.config(text='/'+self.remote)
  for x in rows:self.tree.insert('', 'end',text=x['name'],values=('Folder' if x['type']=='dir' else 'File',x['size'] if x['type']=='file' else ''))
 def sel(self):
  s=self.tree.selection()
  if not s:return None
  v=self.tree.item(s[0]);return v['text'],v['values'][0]
 def join(self,n):return (self.remote.rstrip('/')+'/'+n).lstrip('/')
 def open_folder(self):
  x=self.sel()
  if x and x[1]=='Folder':self.remote=self.join(x[0]);self.refresh()
 def up(self):
  if self.remote:self.remote=self.remote.rsplit('/',1)[0] if '/' in self.remote else '';self.refresh()
 def upload(self):
  p=filedialog.askopenfilename()
  if not p:return
  size=os.path.getsize(p)
  def w():
   try:
    q=self.request('upload_start',path=self.join(os.path.basename(p)),size=size);r=q.get(timeout=30)
    if not r.get('ok'):raise RuntimeError(r.get('error'))
    sent=0
    with open(p,'rb') as f:
     while sent<size:
      c=f.read(CHUNK_SIZE)
      if not c:break
      sent+=len(c)
      with self.send_lock:send_packet(self.sock,{'last':sent>=size},c)
      self.events.put(('progress',int(sent/size*100) if size else 100))
    self.after(0,self.refresh)
   except Exception as e:self.events.put(('error','Upload failed: '+str(e)))
   finally:self.events.put(('progress',0))
  threading.Thread(target=w,daemon=True).start()
 def download(self):
  x=self.sel()
  if x and x[1]=='File':
   p=filedialog.asksaveasfilename(initialfile=x[0])
   if p:self.seq+=1;i=self.seq;self.downloads[i]=p;self.pending[i]=queue.Queue();send_packet(self.sock,{'op':'download_req','id':i,'path':self.join(x[0])})
 def _start_download(self,d):
  p=self.downloads.pop(d.get('request_id'),None)
  if p:self.active_download={'file':open(p,'wb'),'size':int(d.get('size',0)),'received':0}
 def _accept_download_chunk(self,m,data):
  st=self.active_download
  if not st:return
  st['file'].write(data or b'');st['received']+=len(data or b'')
  if m.get('last'):st['file'].close();self.active_download=None
 def mkdir(self):
  n=simpledialog.askstring('Folder','Folder name:')
  if n:self.async_request('mkdir',lambda r:self.refresh(),path=self.join(n))
 def delete(self):
  x=self.sel()
  if x and messagebox.askyesno('Delete',x[0]):self.async_request('delete',lambda r:self.refresh(),path=self.join(x[0]))
 def send_chat(self):
  t=self.msg.get().strip()
  if t and self.sock:send_packet(self.sock,{'op':'message','text':t});self.msg.set('')
 def disconnect(self):
  s=self.sock;self.sock=None
  if s:
   try:s.close()
   except:pass
  self.status.set('Disconnected')
 def close(self):self.disconnect();self.destroy()
if __name__=='__main__':App().mainloop()
