from __future__ import annotations
import tkinter as tk
from tkinter import ttk
from PIL import Image, ImageTk

class VideoTile(ttk.Frame):
    def __init__(self, master, index):
        super().__init__(master, relief='solid', borderwidth=1)
        self.index=index; self.photo=None
        self.view=tk.Label(self,bg='#111',fg='white',text='Camera slot\nWaiting...')
        self.view.pack(fill='both',expand=True)
        self.name=tk.StringVar(value=f'Slot {index+1}')
        tk.Label(self,textvariable=self.name,bg='#222',fg='white',anchor='w').place(relx=0,rely=1,anchor='sw',relwidth=1)
    def set_frame(self, image, username=None):
        if username:self.name.set(username)
        if image is None:return
        image=image.copy(); image.thumbnail((220,150),Image.Resampling.LANCZOS)
        self.photo=ImageTk.PhotoImage(image);self.view.config(image=self.photo,text='')
    def clear(self):self.photo=None;self.view.config(image='',text='Camera slot\nWaiting...');self.name.set(f'Slot {self.index+1}')

class VideoGrid(ttk.Frame):
    def __init__(self,master):
        super().__init__(master);self.tiles=[]
        for r in range(5):
            self.rowconfigure(r,weight=1,uniform='camrow')
            for c in range(5):
                self.columnconfigure(c,weight=1,uniform='camcol')
                tile=VideoTile(self,r*5+c);tile.grid(row=r,column=c,sticky='nsew',padx=2,pady=2);self.tiles.append(tile)
    def clear(self):
        for t in self.tiles:t.clear()
