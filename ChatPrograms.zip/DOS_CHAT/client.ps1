param(
    [string]$Server = '',
    [int]$Port = 2323,
    [string]$Name = ''
)

$ErrorActionPreference = 'Stop'
$downloads = Join-Path $PSScriptRoot 'DOWNLOADS'
New-Item -ItemType Directory -Path $downloads -Force | Out-Null
$incoming = [Collections.Queue]::Synchronized((New-Object Collections.Queue))
$files = @{}

function Banner {
    Clear-Host
    Write-Host '+====================================================+' -ForegroundColor Cyan
    Write-Host '|                    DOS CHAT                       |' -ForegroundColor Cyan
    Write-Host '+====================================================+' -ForegroundColor Cyan
}
function Send-Object($obj) {
    $line = $obj | ConvertTo-Json -Compress -Depth 8
    $script:writer.WriteLine($line)
    $script:writer.Flush()
}
function Safe-FileName([string]$value) {
    $name = [IO.Path]::GetFileName($value)
    foreach ($c in [IO.Path]::GetInvalidFileNameChars()) { $name = $name.Replace([string]$c, '_') }
    if ([string]::IsNullOrWhiteSpace($name)) { $name = 'received.bin' }
    return $name
}
function Show-Prompt { Write-Host -NoNewline ("`r{0}> " -f $Name) -ForegroundColor Green }
function Show-Line([string]$text, [ConsoleColor]$color = [ConsoleColor]::Gray) {
    Write-Host "`r$(' ' * [Math]::Max(1,[Console]::WindowWidth-1))`r" -NoNewline
    Write-Host $text -ForegroundColor $color
    Show-Prompt
    if ($script:inputBuffer) { Write-Host -NoNewline $script:inputBuffer }
}
function Process-Incoming {
    while ($incoming.Count -gt 0) {
        $msg = $incoming.Dequeue()
        switch ($msg.type) {
            'welcome' { Show-Line ("[SERVER] {0}" -f $msg.text) Cyan }
            'system'  { Show-Line ("[SERVER] {0}" -f $msg.text) Yellow }
            'chat'    { Show-Line ("[{0}] <{1}> {2}" -f $msg.time,$msg.from,$msg.text) Gray }
            'private' { Show-Line ("[{0}] [PRIVATE:{1}] {2}" -f $msg.time,$msg.from,$msg.text) Magenta }
            'users'   { Show-Line ("[USERS] " + (($msg.users | ForEach-Object { [string]$_ }) -join ', ')) Cyan }
            'file_start' {
                $safe = Safe-FileName ([string]$msg.name)
                $path = Join-Path $downloads $safe
                if (Test-Path $path) {
                    $path = Join-Path $downloads (([IO.Path]::GetFileNameWithoutExtension($safe)) + '_' + (Get-Date -Format yyyyMMdd_HHmmss) + ([IO.Path]::GetExtension($safe)))
                }
                $fs = [IO.File]::Open($path, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
                $files[[string]$msg.id] = [pscustomobject]@{ Stream=$fs; Path=$path; From=$msg.from; Received=[int64]0; Size=[int64]$msg.size }
                Show-Line ("[FILE] Receiving {0} ({1} bytes) from {2}" -f $safe,$msg.size,$msg.from) Yellow
            }
            'file_chunk' {
                $f = $files[[string]$msg.id]
                if ($null -ne $f) {
                    $bytes = [Convert]::FromBase64String([string]$msg.data)
                    $f.Stream.Write($bytes,0,$bytes.Length); $f.Received += $bytes.Length
                }
            }
            'file_end' {
                $key = [string]$msg.id; $f = $files[$key]
                if ($null -ne $f) {
                    $f.Stream.Dispose(); $files.Remove($key)
                    Show-Line ("[FILE] Saved {0} ({1} bytes)" -f $f.Path,$f.Received) Green
                }
            }
        }
    }
}
function Send-File([string]$target, [string]$path) {
    $path = $path.Trim('"')
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { Show-Line '[ERROR] File not found.' Red; return }
    $item = Get-Item -LiteralPath $path
    $id = [guid]::NewGuid().ToString('N')
    Send-Object @{ type='file_start'; target=$target; id=$id; name=$item.Name; size=$item.Length }
    $fs = [IO.File]::OpenRead($item.FullName)
    try {
        $buffer = New-Object byte[] 32768
        $sent = [int64]0
        while (($read = $fs.Read($buffer,0,$buffer.Length)) -gt 0) {
            $block = if ($read -eq $buffer.Length) { $buffer } else { $buffer[0..($read-1)] }
            Send-Object @{ type='file_chunk'; target=$target; id=$id; data=[Convert]::ToBase64String($block) }
            $sent += $read
            $pct = if ($item.Length) { [int](100*$sent/$item.Length) } else { 100 }
            Write-Host ("`rSending {0}: {1}%   " -f $item.Name,$pct) -NoNewline -ForegroundColor Yellow
        }
    } finally { $fs.Dispose() }
    Send-Object @{ type='file_end'; target=$target; id=$id; name=$item.Name }
    Write-Host; Show-Line ("[FILE] Sent {0} to {1}" -f $item.Name,$target) Green
}

Banner
if (-not $Server) { $Server = Read-Host 'Server IP or hostname' }
if (-not $Name) { $Name = Read-Host 'Your name' }
$Name = ($Name -replace '[^A-Za-z0-9_.-]','')
if (-not $Name) { $Name = 'Guest' }
if ($Name.Length -gt 20) { $Name = $Name.Substring(0,20) }

try {
    $tcp = [Net.Sockets.TcpClient]::new()
    $tcp.Connect($Server,$Port)
    $stream = $tcp.GetStream()
    $reader = [IO.StreamReader]::new($stream,[Text.Encoding]::UTF8)
    $script:writer = [IO.StreamWriter]::new($stream,[Text.UTF8Encoding]::new($false)); $writer.AutoFlush=$true
    Send-Object @{ type='hello'; name=$Name }

    $runspace = [RunspaceFactory]::CreateRunspace(); $runspace.Open()
    $ps = [PowerShell]::Create(); $ps.Runspace=$runspace
    $receiveCode = { param($reader,$queue)
        try { while (($line=$reader.ReadLine()) -ne $null) { try { $queue.Enqueue(($line | ConvertFrom-Json)) } catch {} } }
        catch {} finally { $queue.Enqueue([pscustomobject]@{type='system';text='Connection closed.'}) }
    }
    $null=$ps.AddScript($receiveCode).AddArgument($reader).AddArgument($incoming)
    $handle=$ps.BeginInvoke()

    Write-Host ("Connected to {0}:{1} as {2}" -f $Server,$Port,$Name) -ForegroundColor Green
    Write-Host 'Commands: /help  /users  /msg USER TEXT  /send USER FILE  /sendall FILE  /quit' -ForegroundColor DarkGray
    $script:inputBuffer=''; Show-Prompt
    $running=$true
    while ($running -and $tcp.Connected) {
        Process-Incoming
        if ([Console]::KeyAvailable) {
            $key=[Console]::ReadKey($true)
            if ($key.Key -eq 'Enter') {
                Write-Host; $line=$script:inputBuffer; $script:inputBuffer=''
                if ($line) {
                    if ($line -eq '/quit') { Send-Object @{type='quit'}; $running=$false }
                    elseif ($line -eq '/help') { Show-Line 'Commands: /users, /msg USER TEXT, /send USER FILE, /sendall FILE, /quit' Cyan }
                    elseif ($line -eq '/users') { Send-Object @{type='users'} }
                    elseif ($line -match '^/msg\s+(\S+)\s+(.+)$') { Send-Object @{type='private';target=$matches[1];text=$matches[2]} }
                    elseif ($line -match '^/send\s+(\S+)\s+(.+)$') { Send-File $matches[1] $matches[2] }
                    elseif ($line -match '^/sendall\s+(.+)$') { Send-File '*' $matches[1] }
                    elseif ($line.StartsWith('/')) { Show-Line '[ERROR] Unknown command. Use /help.' Red }
                    else { Send-Object @{type='chat';text=$line} }
                }
                if ($running) { Show-Prompt }
            }
            elseif ($key.Key -eq 'Backspace') {
                if ($script:inputBuffer.Length -gt 0) { $script:inputBuffer=$script:inputBuffer.Substring(0,$script:inputBuffer.Length-1); Write-Host "`b `b" -NoNewline }
            }
            elseif (-not [char]::IsControl($key.KeyChar)) { $script:inputBuffer += $key.KeyChar; Write-Host -NoNewline $key.KeyChar }
        } else { Start-Sleep -Milliseconds 40 }
    }
}
catch { Write-Host ("ERROR: {0}" -f $_.Exception.Message) -ForegroundColor Red }
finally {
    foreach ($f in @($files.Values)) { try { $f.Stream.Dispose() } catch {} }
    try { $tcp.Close() } catch {}
    try { $ps.Stop(); $ps.Dispose(); $runspace.Dispose() } catch {}
}
