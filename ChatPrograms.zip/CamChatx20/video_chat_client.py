import cv2
import json
import numpy as np
import pygame
import socket
import threading
import time


# ============================================================
# WINDOW AND SERVER CONFIGURATION
# ============================================================

WIDTH = 1280
HEIGHT = 720

CHAT_WIDTH = 350
CAMERA_AREA_WIDTH = WIDTH - CHAT_WIDTH

SERVER_IP = "192.168.1.72"
SERVER_PORT = 5000

MAX_USERS = 20

GRID_COLUMNS = 5
GRID_ROWS = 4

CAMERA_INDEX = 0

# Small video settings help when many cameras are active.
SEND_WIDTH = 320
SEND_HEIGHT = 180

VIDEO_FPS = 8
JPEG_QUALITY = 35

MAX_MESSAGE_LENGTH = 500


# ============================================================
# PYGAME INITIALIZATION
# ============================================================

pygame.init()

screen = pygame.display.set_mode(
    (WIDTH, HEIGHT)
)

pygame.display.set_caption(
    "CamBunches - 20 Camera Chat"
)

clock = pygame.time.Clock()

font = pygame.font.SysFont(
    "consolas",
    16
)

small_font = pygame.font.SysFont(
    "consolas",
    13
)

large_font = pygame.font.SysFont(
    "consolas",
    22
)


# ============================================================
# THEME
# ============================================================

theme = {
    "bg": (25, 25, 25),
    "panel": (37, 37, 37),
    "border": (70, 70, 70),
    "text": (237, 237, 237),
    "muted": (150, 150, 150),
    "accent": (0, 174, 239),
    "input_bg": (45, 45, 45),
    "input_border": (90, 90, 90),
    "black": (0, 0, 0),
    "error": (255, 90, 90)
}


# ============================================================
# LOCAL USER
# ============================================================

username = "Shawn"
icon_color = (0, 0, 0)

my_id = None


# ============================================================
# SHARED DATA
# ============================================================

users = {}
users_lock = threading.Lock()

chat_log = []
chat_lock = threading.Lock()

current_input = ""

running = True
connected = False

send_lock = threading.Lock()

last_video_send = 0.0


# ============================================================
# CAMERA DETECTION
# ============================================================

def open_camera():
    """
    Try several camera indexes and Windows camera backends.
    """

    camera_backends = [
        ("DirectShow", cv2.CAP_DSHOW),
        ("Media Foundation", cv2.CAP_MSMF),
        ("Automatic", cv2.CAP_ANY)
    ]

    # Start with the configured camera index.
    indexes = [CAMERA_INDEX]

    for index in range(5):
        if index not in indexes:
            indexes.append(index)

    for camera_index in indexes:
        for backend_name, backend in camera_backends:
            print(
                f"Trying camera {camera_index} "
                f"using {backend_name}..."
            )

            test_camera = cv2.VideoCapture(
                camera_index,
                backend
            )

            if not test_camera.isOpened():
                test_camera.release()
                continue

            test_camera.set(
                cv2.CAP_PROP_FRAME_WIDTH,
                SEND_WIDTH
            )

            test_camera.set(
                cv2.CAP_PROP_FRAME_HEIGHT,
                SEND_HEIGHT
            )

            test_camera.set(
                cv2.CAP_PROP_FPS,
                VIDEO_FPS
            )

            test_camera.set(
                cv2.CAP_PROP_BUFFERSIZE,
                1
            )

            # Some webcams need several read attempts.
            for attempt in range(15):
                success, frame = test_camera.read()

                if (
                    success
                    and frame is not None
                    and frame.size > 0
                ):
                    print(
                        f"Camera opened successfully: "
                        f"index={camera_index}, "
                        f"backend={backend_name}"
                    )

                    return test_camera

                time.sleep(0.05)

            test_camera.release()

    print("No working camera was found.")

    return None


# ============================================================
# SOCKET HELPERS
# ============================================================

def recv_exact(sock, size):
    data = bytearray()

    while len(data) < size:
        chunk = sock.recv(
            size - len(data)
        )

        if not chunk:
            raise ConnectionError(
                "Server closed the connection"
            )

        data.extend(chunk)

    return bytes(data)


def send_packet(packet_type, payload=b""):
    global connected

    if not connected:
        return False

    packet = (
        packet_type
        + len(payload).to_bytes(4, "big")
        + payload
    )

    try:
        with send_lock:
            sock.sendall(packet)

        return True

    except (
        OSError,
        ConnectionError,
        ConnectionResetError,
        BrokenPipeError
    ) as error:
        print(f"Send failed: {error}")

        connected = False

        return False


# ============================================================
# SEND DATA
# ============================================================

def send_userinfo():
    info = {
        "username": username,
        "icon_color": list(icon_color)
    }

    payload = json.dumps(
        info
    ).encode("utf-8")

    send_packet(
        b"U",
        payload
    )


def send_text(message):
    message = message.strip()

    if not message:
        return

    message = message[:MAX_MESSAGE_LENGTH]

    send_packet(
        b"T",
        message.encode("utf-8")
    )


def send_video(frame):
    """
    Resize and compress the camera frame before sending it.
    """

    frame = cv2.resize(
        frame,
        (SEND_WIDTH, SEND_HEIGHT),
        interpolation=cv2.INTER_AREA
    )

    encode_options = [
        cv2.IMWRITE_JPEG_QUALITY,
        JPEG_QUALITY
    ]

    success, encoded = cv2.imencode(
        ".jpg",
        frame,
        encode_options
    )

    if not success:
        return

    send_packet(
        b"V",
        encoded.tobytes()
    )


# ============================================================
# USER MANAGEMENT
# ============================================================

def create_default_user(user_id):
    return {
        "username": f"User {user_id}",
        "icon_color": (200, 200, 200),
        "frame": None
    }


def update_user(
    user_id,
    new_username=None,
    new_icon_color=None
):
    with users_lock:
        if user_id not in users:
            users[user_id] = create_default_user(
                user_id
            )

        if new_username is not None:
            users[user_id]["username"] = (
                str(new_username)[:24]
            )

        if new_icon_color is not None:
            try:
                cleaned_color = tuple(
                    max(0, min(255, int(value)))
                    for value
                    in new_icon_color[:3]
                )

                if len(cleaned_color) == 3:
                    users[user_id]["icon_color"] = (
                        cleaned_color
                    )

            except (
                TypeError,
                ValueError
            ):
                pass


def update_user_frame(user_id, frame):
    with users_lock:
        if user_id not in users:
            users[user_id] = create_default_user(
                user_id
            )

        # Only keep the newest decoded frame.
        users[user_id]["frame"] = frame


def remove_user(user_id):
    with users_lock:
        users.pop(
            user_id,
            None
        )


# ============================================================
# CHAT MANAGEMENT
# ============================================================

def add_chat_message(user_id, message):
    with chat_lock:
        chat_log.append(
            (user_id, message)
        )

        if len(chat_log) > 250:
            del chat_log[:-250]


def add_system_message(message):
    add_chat_message(
        0,
        message
    )


# ============================================================
# NETWORK RECEIVER
# ============================================================

def network_loop():
    global my_id
    global connected

    try:
        while connected:
            header = recv_exact(
                sock,
                5
            )

            packet_type = header[:1]

            payload_length = int.from_bytes(
                header[1:5],
                "big"
            )

            if payload_length > 2_000_000:
                raise ValueError(
                    "Server packet is too large"
                )

            payload = recv_exact(
                sock,
                payload_length
            )

            # ------------------------------------------------
            # ASSIGNED CLIENT ID
            # ------------------------------------------------

            if packet_type == b"I":
                my_id = int.from_bytes(
                    payload,
                    "big"
                )

                update_user(
                    my_id,
                    username,
                    icon_color
                )

                print(
                    f"Assigned client ID: {my_id}"
                )

                send_userinfo()

            # ------------------------------------------------
            # ROSTER ENTRY
            # ------------------------------------------------

            elif packet_type == b"J":
                info = json.loads(
                    payload.decode("utf-8")
                )

                user_id = int(
                    info["id"]
                )

                update_user(
                    user_id,
                    info.get(
                        "username",
                        f"User {user_id}"
                    ),
                    info.get(
                        "icon_color",
                        [200, 200, 200]
                    )
                )

            # ------------------------------------------------
            # USER UPDATE
            # ------------------------------------------------

            elif packet_type == b"U":
                if len(payload) < 4:
                    continue

                user_id = int.from_bytes(
                    payload[:4],
                    "big"
                )

                info = json.loads(
                    payload[4:].decode("utf-8")
                )

                update_user(
                    user_id,
                    info.get(
                        "username",
                        f"User {user_id}"
                    ),
                    info.get(
                        "icon_color",
                        [200, 200, 200]
                    )
                )

            # ------------------------------------------------
            # TEXT CHAT
            # ------------------------------------------------

            elif packet_type == b"T":
                if len(payload) < 4:
                    continue

                user_id = int.from_bytes(
                    payload[:4],
                    "big"
                )

                message = payload[4:].decode(
                    "utf-8",
                    errors="replace"
                )

                add_chat_message(
                    user_id,
                    message
                )

            # ------------------------------------------------
            # VIDEO FRAME
            # ------------------------------------------------

            elif packet_type == b"V":
                if len(payload) < 5:
                    continue

                user_id = int.from_bytes(
                    payload[:4],
                    "big"
                )

                jpeg_data = payload[4:]

                jpeg_array = np.frombuffer(
                    jpeg_data,
                    dtype=np.uint8
                )

                frame = cv2.imdecode(
                    jpeg_array,
                    cv2.IMREAD_COLOR
                )

                if frame is not None:
                    update_user_frame(
                        user_id,
                        frame
                    )

            # ------------------------------------------------
            # USER LEFT
            # ------------------------------------------------

            elif packet_type == b"L":
                if len(payload) < 4:
                    continue

                user_id = int.from_bytes(
                    payload[:4],
                    "big"
                )

                with users_lock:
                    departed_name = users.get(
                        user_id,
                        {}
                    ).get(
                        "username",
                        f"User {user_id}"
                    )

                remove_user(user_id)

                add_system_message(
                    f"{departed_name} disconnected"
                )

            # ------------------------------------------------
            # SERVER ERROR
            # ------------------------------------------------

            elif packet_type == b"E":
                error_message = payload.decode(
                    "utf-8",
                    errors="replace"
                )

                add_system_message(
                    error_message
                )

                connected = False

    except (
        OSError,
        ConnectionError,
        ConnectionResetError,
        BrokenPipeError,
        ValueError,
        json.JSONDecodeError
    ) as error:
        print(
            f"Network connection ended: {error}"
        )

    finally:
        if connected:
            add_system_message(
                "Disconnected from server"
            )

        connected = False


# ============================================================
# FRAME CONVERSION
# ============================================================

def frame_to_surface(frame, maximum_width, maximum_height):
    """
    Convert an OpenCV BGR frame into a scaled Pygame surface.
    """

    rgb_frame = cv2.cvtColor(
        frame,
        cv2.COLOR_BGR2RGB
    )

    frame_height, frame_width = (
        rgb_frame.shape[:2]
    )

    scale = min(
        maximum_width / frame_width,
        maximum_height / frame_height
    )

    scaled_width = max(
        1,
        int(frame_width * scale)
    )

    scaled_height = max(
        1,
        int(frame_height * scale)
    )

    resized = cv2.resize(
        rgb_frame,
        (scaled_width, scaled_height),
        interpolation=cv2.INTER_AREA
    )

    # copy() detaches the surface from a temporary NumPy buffer.
    surface = pygame.image.frombuffer(
        resized.tobytes(),
        (scaled_width, scaled_height),
        "RGB"
    ).copy()

    return surface


# ============================================================
# TEXT WRAPPING
# ============================================================

def wrap_text(text, selected_font, maximum_width):
    if not text:
        return [""]

    words = text.split(" ")

    lines = []
    current_line = ""

    for word in words:
        test_line = (
            word
            if not current_line
            else current_line + " " + word
        )

        if (
            selected_font.size(test_line)[0]
            <= maximum_width
        ):
            current_line = test_line

        else:
            if current_line:
                lines.append(current_line)

            # Break extremely long words.
            if (
                selected_font.size(word)[0]
                > maximum_width
            ):
                partial = ""

                for character in word:
                    test_partial = (
                        partial + character
                    )

                    if (
                        selected_font.size(
                            test_partial
                        )[0]
                        <= maximum_width
                    ):
                        partial = test_partial
                    else:
                        if partial:
                            lines.append(partial)

                        partial = character

                current_line = partial

            else:
                current_line = word

    if current_line:
        lines.append(current_line)

    return lines or [""]


# ============================================================
# DRAW CAMERA TILE
# ============================================================

def draw_camera_tile(
    rect,
    user_id,
    user_data
):
    pygame.draw.rect(
        screen,
        theme["panel"],
        rect
    )

    if user_id == my_id:
        border_color = theme["accent"]
        border_width = 2
    else:
        border_color = theme["border"]
        border_width = 1

    pygame.draw.rect(
        screen,
        border_color,
        rect,
        border_width
    )

    video_rect = pygame.Rect(
        rect.x + 3,
        rect.y + 3,
        rect.width - 6,
        rect.height - 29
    )

    frame = user_data.get("frame")

    if frame is not None:
        try:
            camera_surface = frame_to_surface(
                frame,
                video_rect.width,
                video_rect.height
            )

            camera_position = (
                video_rect.centerx
                - camera_surface.get_width() // 2,
                video_rect.centery
                - camera_surface.get_height() // 2
            )

            screen.blit(
                camera_surface,
                camera_position
            )

        except (
            pygame.error,
            cv2.error,
            ValueError
        ):
            frame = None

    if frame is None:
        color = user_data.get(
            "icon_color",
            (200, 200, 200)
        )

        pygame.draw.circle(
            screen,
            color,
            video_rect.center,
            22
        )

        no_camera_surface = small_font.render(
            "No camera",
            True,
            theme["muted"]
        )

        screen.blit(
            no_camera_surface,
            no_camera_surface.get_rect(
                center=(
                    video_rect.centerx,
                    video_rect.centery + 36
                )
            )
        )

    # Username bar.
    name_bar = pygame.Rect(
        rect.x + 1,
        rect.bottom - 25,
        rect.width - 2,
        24
    )

    pygame.draw.rect(
        screen,
        theme["black"],
        name_bar
    )

    name = user_data.get(
        "username",
        f"User {user_id}"
    )

    if user_id == my_id:
        name += " (You)"

    while (
        name
        and small_font.size(name)[0]
        > rect.width - 34
    ):
        name = name[:-1]

    color = user_data.get(
        "icon_color",
        (200, 200, 200)
    )

    pygame.draw.circle(
        screen,
        color,
        (
            rect.x + 11,
            rect.bottom - 13
        ),
        5
    )

    name_surface = small_font.render(
        name,
        True,
        theme["text"]
    )

    screen.blit(
        name_surface,
        (
            rect.x + 21,
            rect.bottom - 21
        )
    )


# ============================================================
# DRAW EMPTY TILE
# ============================================================

def draw_empty_tile(rect, slot_number):
    pygame.draw.rect(
        screen,
        theme["panel"],
        rect
    )

    pygame.draw.rect(
        screen,
        theme["border"],
        rect,
        1
    )

    label = small_font.render(
        f"Empty {slot_number}",
        True,
        theme["muted"]
    )

    screen.blit(
        label,
        label.get_rect(
            center=rect.center
        )
    )


# ============================================================
# DRAW 4 x 5 CAMERA GRID
# ============================================================

def draw_camera_grid(local_frame):
    tile_width = (
        CAMERA_AREA_WIDTH
        // GRID_COLUMNS
    )

    tile_height = (
        HEIGHT
        // GRID_ROWS
    )

    with users_lock:
        snapshot = {
            user_id: dict(user_data)
            for user_id, user_data
            in users.items()
        }

    # Display the local camera before an ID arrives.
    local_display_id = (
        my_id
        if my_id is not None
        else -1
    )

    local_data = snapshot.get(
        local_display_id,
        create_default_user(
            local_display_id
        )
    )

    local_data["username"] = username
    local_data["icon_color"] = icon_color
    local_data["frame"] = local_frame

    snapshot[local_display_id] = local_data

    # Remove temporary local ID once the real ID exists.
    if my_id is not None:
        snapshot.pop(-1, None)

    ordered_users = sorted(
        snapshot.items(),
        key=lambda item: (
            0 if item[0] == my_id else 1,
            item[0]
        )
    )[:MAX_USERS]

    for slot in range(MAX_USERS):
        row = slot // GRID_COLUMNS
        column = slot % GRID_COLUMNS

        tile_x = column * tile_width
        tile_y = row * tile_height

        if column == GRID_COLUMNS - 1:
            current_width = (
                CAMERA_AREA_WIDTH
                - tile_x
            )
        else:
            current_width = tile_width

        if row == GRID_ROWS - 1:
            current_height = (
                HEIGHT
                - tile_y
            )
        else:
            current_height = tile_height

        tile_rect = pygame.Rect(
            tile_x,
            tile_y,
            current_width,
            current_height
        )

        if slot < len(ordered_users):
            user_id, user_data = (
                ordered_users[slot]
            )

            draw_camera_tile(
                tile_rect,
                user_id,
                user_data
            )

        else:
            draw_empty_tile(
                tile_rect,
                slot + 1
            )


# ============================================================
# DRAW CHAT
# ============================================================

def draw_chat():
    panel = pygame.Rect(
        CAMERA_AREA_WIDTH,
        0,
        CHAT_WIDTH,
        HEIGHT
    )

    pygame.draw.rect(
        screen,
        theme["panel"],
        panel
    )

    pygame.draw.line(
        screen,
        theme["border"],
        (panel.x, 0),
        (panel.x, HEIGHT),
        1
    )

    title_surface = large_font.render(
        "CamBunches",
        True,
        theme["text"]
    )

    screen.blit(
        title_surface,
        (panel.x + 10, 8)
    )

    with users_lock:
        remote_count = len(users)

    if my_id is None:
        user_count = remote_count + 1
    else:
        user_count = remote_count

    user_count = min(
        user_count,
        MAX_USERS
    )

    if connected:
        status_text = (
            f"Connected | Users: "
            f"{user_count}/{MAX_USERS}"
        )

        status_color = theme["accent"]

    else:
        status_text = "Disconnected"
        status_color = theme["error"]

    status_surface = small_font.render(
        status_text,
        True,
        status_color
    )

    screen.blit(
        status_surface,
        (panel.x + 10, 38)
    )

    pygame.draw.line(
        screen,
        theme["border"],
        (panel.x + 10, 60),
        (panel.right - 10, 60),
        1
    )

    with users_lock:
        names = {
            user_id: data.get(
                "username",
                f"User {user_id}"
            )
            for user_id, data
            in users.items()
        }

    if my_id is not None:
        names[my_id] = username

    with chat_lock:
        messages = list(chat_log)

    visible_lines = []

    for user_id, message in messages:
        if user_id == 0:
            prefix = "System"
        else:
            prefix = names.get(
                user_id,
                f"User {user_id}"
            )

        complete_message = (
            prefix + ": " + message
        )

        wrapped = wrap_text(
            complete_message,
            small_font,
            CHAT_WIDTH - 20
        )

        # This fixes the previous uninitialized 'i' error.
        for line in wrapped:
            visible_lines.append(
                (user_id, line)
            )

    input_height = 34
    input_y = HEIGHT - input_height - 10

    chat_top = 70
    line_height = 16

    available_height = (
        input_y
        - chat_top
        - 8
    )

    maximum_lines = max(
        1,
        available_height // line_height
    )

    visible_lines = visible_lines[
        -maximum_lines:
    ]

    draw_y = chat_top

    for user_id, line in visible_lines:
        if user_id == 0:
            line_color = theme["muted"]
        else:
            line_color = theme["text"]

        line_surface = small_font.render(
            line,
            True,
            line_color
        )

        screen.blit(
            line_surface,
            (
                panel.x + 10,
                draw_y
            )
        )

        draw_y += line_height

    input_box = pygame.Rect(
        panel.x + 10,
        input_y,
        CHAT_WIDTH - 20,
        input_height
    )

    pygame.draw.rect(
        screen,
        theme["input_bg"],
        input_box
    )

    pygame.draw.rect(
        screen,
        theme["input_border"],
        input_box,
        1
    )

    displayed_input = current_input

    while (
        displayed_input
        and font.size(displayed_input)[0]
        > input_box.width - 16
    ):
        displayed_input = displayed_input[1:]

    input_surface = font.render(
        displayed_input,
        True,
        theme["text"]
    )

    screen.blit(
        input_surface,
        (
            input_box.x + 6,
            input_box.y + 7
        )
    )

    # Blinking cursor.
    if int(time.time() * 2) % 2 == 0:
        cursor_x = (
            input_box.x
            + 6
            + input_surface.get_width()
        )

        pygame.draw.line(
            screen,
            theme["accent"],
            (
                cursor_x,
                input_box.y + 6
            ),
            (
                cursor_x,
                input_box.bottom - 6
            ),
            2
        )


# ============================================================
# DRAW STARTUP WINDOW
# ============================================================

screen.fill(theme["bg"])

startup_surface = large_font.render(
    "Starting CamBunches...",
    True,
    theme["text"]
)

screen.blit(
    startup_surface,
    startup_surface.get_rect(
        center=(
            WIDTH // 2,
            HEIGHT // 2
        )
    )
)

pygame.display.flip()
pygame.event.pump()


# ============================================================
# OPEN CAMERA
# ============================================================

camera = open_camera()


# ============================================================
# CONNECT TO SERVER
# ============================================================

sock = socket.socket(
    socket.AF_INET,
    socket.SOCK_STREAM
)

sock.setsockopt(
    socket.IPPROTO_TCP,
    socket.TCP_NODELAY,
    1
)

# Avoid freezing forever if the server cannot be reached.
sock.settimeout(4.0)

try:
    print(
        f"Connecting to "
        f"{SERVER_IP}:{SERVER_PORT}..."
    )

    sock.connect(
        (SERVER_IP, SERVER_PORT)
    )

    sock.settimeout(None)

    connected = True

    print("Connected to server.")

except (
    socket.timeout,
    OSError
) as error:
    connected = False

    print(
        f"Could not connect: {error}"
    )

    add_system_message(
        f"Connection failed: {error}"
    )


# ============================================================
# START NETWORK THREAD
# ============================================================

if connected:
    receiver = threading.Thread(
        target=network_loop,
        daemon=True,
        name="NetworkReceiver"
    )

    receiver.start()


# ============================================================
# MAIN LOOP
# ============================================================

while running:
    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.KEYDOWN:

            if event.key == pygame.K_ESCAPE:
                running = False

            elif event.key == pygame.K_RETURN:
                message = current_input.strip()

                if message:
                    if connected:
                        send_text(message)
                    else:
                        add_system_message(
                            "Cannot send while disconnected"
                        )

                    current_input = ""

            elif event.key == pygame.K_BACKSPACE:
                current_input = current_input[:-1]

            elif (
                event.unicode
                and event.unicode.isprintable()
                and len(current_input)
                < MAX_MESSAGE_LENGTH
            ):
                current_input += event.unicode

    # --------------------------------------------------------
    # READ LOCAL CAMERA
    # --------------------------------------------------------

    local_frame = None

    if camera is not None:
        success, captured_frame = camera.read()

        if (
            success
            and captured_frame is not None
            and captured_frame.size > 0
        ):
            local_frame = captured_frame

    # --------------------------------------------------------
    # SEND VIDEO AT CONTROLLED RATE
    # --------------------------------------------------------

    current_time = time.monotonic()

    if (
        connected
        and local_frame is not None
        and current_time - last_video_send
        >= 1.0 / VIDEO_FPS
    ):
        send_video(local_frame)

        last_video_send = current_time

    # --------------------------------------------------------
    # DRAW
    # --------------------------------------------------------

    screen.fill(theme["bg"])

    draw_camera_grid(local_frame)
    draw_chat()

    pygame.display.flip()

    clock.tick(30)


# ============================================================
# SHUTDOWN
# ============================================================

connected = False

if camera is not None:
    camera.release()

try:
    sock.shutdown(
        socket.SHUT_RDWR
    )
except OSError:
    pass

try:
    sock.close()
except OSError:
    pass

pygame.quit()
