#!/usr/bin/env python3
import argparse, getpass, json, os, socket, ssl, subprocess, threading
from datetime import datetime, timedelta, timezone
from pathlib import Path

DISCOVERY_PORT = 2122
CHAT_PORT = 2123
DISCOVERY_QUERY = b'WIFI_FTPS_DISCOVER_V1'
DISCOVERY_PREFIX = 'WIFI_FTPS_HERE_V1'
PASSIVE_FIRST = 60000
PASSIVE_LAST = 60049


def log(message):
    print(f"{datetime.now().strftime('%H:%M:%S')} {message}", flush=True)


def lan_ipv4_addresses():
    found = []

    def add(value):
        if value and not value.startswith(('127.', '169.254.')) and value not in found:
            found.append(value)

    try:
        for item in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            add(item[4][0])
    except OSError:
        pass
    if os.name == 'nt':
        try:
            output = subprocess.check_output(['ipconfig'], text=True, errors='ignore')
            import re
            for value in re.findall(r'IPv4[^:]*:\s*([0-9]+(?:\.[0-9]+){3})', output, re.I):
                add(value)
        except Exception:
            pass
    return found


def ensure_firewall(control_port):
    if os.name != 'nt':
        return
    rules = [
        ('WiFi FTPS Control', 'TCP', str(control_port)),
        ('WiFi FTPS Discovery', 'UDP', str(DISCOVERY_PORT)),
        ('WiFi FTPS Chat', 'TCP', str(CHAT_PORT)),
        ('WiFi FTPS Passive', 'TCP', f'{PASSIVE_FIRST}-{PASSIVE_LAST}'),
    ]
    for name, protocol, ports in rules:
        subprocess.run(['netsh', 'advfirewall', 'firewall', 'delete', 'rule', f'name={name}'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        result = subprocess.run([
            'netsh', 'advfirewall', 'firewall', 'add', 'rule', f'name={name}',
            'dir=in', 'action=allow', f'protocol={protocol}', f'localport={ports}',
            'profile=any', 'enable=yes'
        ], capture_output=True, text=True)
        if result.returncode:
            log(f'[FIREWALL] Could not add {name}. Run as Administrator. {(result.stderr or result.stdout).strip()}')
        else:
            log(f'[FIREWALL] Installed {name}')


def create_certificate(cert_file, key_file, host):
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import NameOID
    import ipaddress

    key = rsa.generate_private_key(public_exponent=65537, key_size=3072)
    now = datetime.now(timezone.utc)
    subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, host)])
    sans = [x509.DNSName('localhost')]
    try:
        sans.append(x509.IPAddress(ipaddress.ip_address(host)))
    except ValueError:
        sans.append(x509.DNSName(host))
    cert = (
        x509.CertificateBuilder().subject_name(subject).issuer_name(subject)
        .public_key(key.public_key()).serial_number(x509.random_serial_number())
        .not_valid_before(now - timedelta(minutes=5)).not_valid_after(now + timedelta(days=3650))
        .add_extension(x509.SubjectAlternativeName(sans), False).sign(key, hashes.SHA256())
    )
    Path(key_file).write_bytes(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL, serialization.NoEncryption()))
    Path(cert_file).write_bytes(cert.public_bytes(serialization.Encoding.PEM))


def load_or_create_config(path, cert_file, key_file, host):
    config_path = Path(path)
    if config_path.exists():
        config = json.loads(config_path.read_text(encoding='utf-8'))
    else:
        print('\n=== FIRST RUN FTPS SETUP ===')
        username = input('Username [admin]: ').strip() or 'admin'
        while True:
            password = getpass.getpass('Password: ')
            confirm = getpass.getpass('Confirm password: ')
            if password and password == confirm:
                break
            print('Passwords did not match or were blank.')
        config = {'username': username, 'password': password}
        config_path.write_text(json.dumps(config, indent=2), encoding='utf-8')
    if not Path(cert_file).exists() or not Path(key_file).exists():
        create_certificate(cert_file, key_file, host)
    return config


def discovery_responder(server_ip, control_port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sock.bind(('', DISCOVERY_PORT))
    log(f'[DISCOVERY] UDP listening on 0.0.0.0:{DISCOVERY_PORT}; advertising {server_ip}:{control_port}')
    while True:
        data, address = sock.recvfrom(1024)
        if data == DISCOVERY_QUERY:
            reply = f'{DISCOVERY_PREFIX}|{server_ip}|{control_port}'.encode('ascii')
            sock.sendto(reply, address)
            log(f'[DISCOVERY] Reply sent to {address[0]}:{address[1]}')



class ChatServer:
    def __init__(self, host, port, certfile, keyfile, username, password):
        self.host=host; self.port=port; self.username=username; self.password=password
        self.clients={}; self.lock=threading.Lock()
        self.context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        self.context.load_cert_chain(certfile=certfile, keyfile=keyfile)

    def send_json(self, sock, obj):
        sock.sendall((json.dumps(obj, ensure_ascii=False)+'\n').encode('utf-8'))

    def broadcast(self, obj):
        dead=[]
        data=(json.dumps(obj, ensure_ascii=False)+'\n').encode('utf-8')
        with self.lock:
            for client in list(self.clients):
                try: client.sendall(data)
                except OSError: dead.append(client)
            for client in dead: self.clients.pop(client, None)

    def handle(self, raw, address):
        sock=None; name=None
        try:
            sock=self.context.wrap_socket(raw, server_side=True); sock.settimeout(None)
            file=sock.makefile('r', encoding='utf-8', newline='\n')
            line=file.readline()
            if not line: return
            hello=json.loads(line)
            if hello.get('type')!='login' or hello.get('username')!=self.username or hello.get('password')!=self.password:
                self.send_json(sock, {'type':'login','ok':False,'message':'Invalid username or password'}); return
            name=hello.get('display_name') or hello.get('username')
            self.send_json(sock, {'type':'login','ok':True,'message':'Chat connected'})
            with self.lock: self.clients[sock]=name
            self.broadcast({'type':'system','text':f'{name} joined chat'})
            log(f'[CHAT] {name} connected from {address[0]}:{address[1]}')
            for line in file:
                try: msg=json.loads(line)
                except json.JSONDecodeError: continue
                if msg.get('type')=='chat':
                    text=str(msg.get('text','')).strip()[:4000]
                    if text:
                        self.broadcast({'type':'chat','from':name,'text':text,'time':datetime.now().strftime('%H:%M:%S')})
        except Exception as e:
            log(f'[CHAT] connection error {address[0]}:{address[1]}: {e}')
        finally:
            if sock:
                with self.lock: self.clients.pop(sock, None)
                try: sock.close()
                except OSError: pass
            else:
                try: raw.close()
                except OSError: pass
            if name:
                self.broadcast({'type':'system','text':f'{name} left chat'})
                log(f'[CHAT] {name} disconnected')

    def serve(self):
        listener=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        listener.bind((self.host,self.port)); listener.listen(20)
        log(f'[CHAT] TLS chat listening on {self.host}:{self.port}')
        while True:
            raw,address=listener.accept()
            threading.Thread(target=self.handle,args=(raw,address),daemon=True).start()

def main():
    try:
        from pyftpdlib.authorizers import DummyAuthorizer
        from pyftpdlib.handlers import TLS_FTPHandler
        from pyftpdlib.servers import ThreadedFTPServer
    except ImportError:
        raise SystemExit('Install dependencies: py -m pip install pyftpdlib pyOpenSSL cryptography')

    os.chdir(Path(__file__).resolve().parent)
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', default='', help='LAN address advertised to clients; sockets bind to 0.0.0.0')
    parser.add_argument('--port', type=int, default=2121)
    parser.add_argument('--root', default='ftps_shared')
    parser.add_argument('--config', default='ftps_users.json')
    parser.add_argument('--cert', default='ftps_cert.pem')
    parser.add_argument('--key', default='ftps_key.pem')
    args = parser.parse_args()

    addresses = lan_ipv4_addresses()
    server_ip = args.host or next((ip for ip in addresses if ip.startswith('192.168.1.')), addresses[0] if addresses else '127.0.0.1')
    bind_ip = '0.0.0.0'
    if args.host and args.host not in addresses:
        log(f'[BIND] {args.host} is not assigned locally; using it only as the advertised address')
    log(f'[BIND] Local addresses: {addresses or ["none detected"]}')
    log(f'[BIND] FTPS and chat sockets bind to {bind_ip}; clients use {server_ip}')
    root = Path(args.root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    config = load_or_create_config(args.config, args.cert, args.key, server_ip)
    ensure_firewall(args.port)

    authorizer = DummyAuthorizer()
    authorizer.add_user(config['username'], config['password'], str(root), perm='elradfmwMT')

    class Handler(TLS_FTPHandler):
        def on_connect(self): log(f'[FTPS] TCP connected: {self.remote_ip}:{self.remote_port}')
        def on_login(self, username): log(f'[FTPS] Login accepted: {username}')
        def on_login_failed(self, username, password): log(f'[FTPS] Login rejected: {username}')
        def on_file_sent(self, file): log(f'[FTPS] Download complete: {file}')
        def on_file_received(self, file): log(f'[FTPS] Upload complete: {file}')
        def on_incomplete_file_sent(self, file): log(f'[FTPS] Download incomplete: {file}')
        def on_incomplete_file_received(self, file): log(f'[FTPS] Upload incomplete: {file}')

    Handler.authorizer = authorizer
    Handler.certfile = str(Path(args.cert).resolve())
    Handler.keyfile = str(Path(args.key).resolve())
    Handler.tls_control_required = True
    Handler.tls_data_required = True
    Handler.passive_ports = range(PASSIVE_FIRST, PASSIVE_LAST + 1)
    Handler.masquerade_address = server_ip
    Handler.banner = 'WiFi Explicit FTPS ready.'

    threading.Thread(target=discovery_responder, args=(server_ip, args.port), daemon=True).start()
    chat=ChatServer(bind_ip, CHAT_PORT, str(Path(args.cert).resolve()), str(Path(args.key).resolve()), config['username'], config['password'])
    threading.Thread(target=chat.serve, daemon=True).start()
    server = ThreadedFTPServer((bind_ip, args.port), Handler)
    server.max_cons = 50
    server.max_cons_per_ip = 10
    log(f'[FTPS] Explicit FTPS listening on {bind_ip}:{args.port}; advertised as {server_ip}:{args.port}')
    log(f'[FTPS] Passive ports {PASSIVE_FIRST}-{PASSIVE_LAST}')
    log(f'[CHAT] Port {CHAT_PORT}')
    log(f'[FTPS] Root {root}')
    server.serve_forever()


if __name__ == '__main__':
    main()
