25-camera-grid UI edition

Layout:
- Chat is fixed on the LEFT.
- A 5 x 5 grid of 25 camera tiles fills the RIGHT side.
- Existing secure TLS chat, icons, user list, heartbeat, certificate pinning, and disconnect remain.

Important:
This build implements the requested 25-window camera layout and camera tile renderer. It does NOT yet transmit live webcam video between network clients. Adding real network camera transport is a separate media-streaming layer and should not be faked by sending large image frames through the existing chat JSON socket.

LIVE VIDEO UPDATE
- All 25 camera tiles are video-only/muted. No microphone capture or audio transport is implemented.
- Each connected client publishes webcam 0 at 320x240 and approximately 10 FPS.
- Frames are JPEG encoded and carried over a separate TLS socket on TCP port 5051.
- Server relays encrypted-transport video frames to the other authenticated clients.
- Up to 25 remote usernames are assigned camera tiles.
- Open TCP port 5051 anywhere that port 5050 is permitted through a firewall/NAT.

PER-USER CAMERA CONTROL
- Each client now has its own Camera: ON / Camera: OFF button.
- Turning your camera OFF stops only your local webcam capture and outbound stream.
- Other users keep streaming normally.
- You continue receiving and viewing other users while your own camera is OFF.
- Cameras start OFF by default after connecting. Each user explicitly turns their own camera ON.
