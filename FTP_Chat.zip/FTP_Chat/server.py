#!/usr/bin/env python3
import argparse, getpass, json, os, re, socket, struct, subprocess, threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
import bcrypt

DISCOVERY_PORT=5052; DISCOVERY_QUERY=b'WIFI_TLS_SHARE_DISCOVER_V1'; DISCOVERY_REPLY_PREFIX='WIFI_TLS_SHARE_HERE_V1'
MAX_PACKET=128*1024*1024; CHUNK_SIZE=1024*1024; JSON_MODE=b'\x00'; BINARY_MODE=b'\x01'
def log(tag,msg): print('%s [%s] %s'%(datetime.now().strftime('%H:%M:%S.%f')[:-3],tag,msg),flush=True)
def recv_exact(s,n):
 b=bytearray()
 while len(b)<n:
  x=s.recv(n-len(b))
  if not x: raise ConnectionError('connection closed')
  b.extend(x)
 return bytes(b)
def recv_packet(s):
 n=struct.unpack('!I',recv_exact(s,4))[0]
 if n<1 or n>MAX_PACKET: raise ValueError('invalid packet size: %d'%n)
 mode=recv_exact(s,1); rem=n-1
 if mode==JSON_MODE: return json.loads(recv_exact(s,rem).decode()),None
 if mode==BINARY_MODE:
  if rem<5: raise ValueError('invalid binary packet')
  m=recv_exact(s,5); size=struct.unpack('!I',m[:4])[0]
  if size!=rem-5: raise ValueError('binary chunk length mismatch')
  return {'op':'chunk_data','last':m[4]==1},recv_exact(s,size)
 raise ValueError('unknown packet mode')
def send_packet(s,p,raw_binary=None):
 if raw_binary is None:
  b=json.dumps(p,ensure_ascii=False).encode(); s.sendall(struct.pack('!I',len(b)+1)+JSON_MODE+b); return
 h=struct.pack('!I',len(raw_binary))+(b'\x01' if p.get('last') else b'\x00'); s.sendall(struct.pack('!I',1+len(h)+len(raw_binary))+BINARY_MODE+h+raw_binary)
def safe_path(root,relative):
 r=(root/str(relative or '').replace('\\','/').lstrip('/')).resolve()
 if r!=root and root not in r.parents: raise ValueError('invalid path')
 return r
def load_json_file(path,label):
 p=Path(path)
 try: text=p.read_text(encoding='utf-8-sig')
 except FileNotFoundError: raise RuntimeError('%s is missing: %s'%(label,p))
 if not text.strip(): raise RuntimeError('%s is empty: %s'%(label,p))
 try: return json.loads(text)
 except json.JSONDecodeError as e: raise RuntimeError('%s invalid JSON line %d column %d'%(label,e.lineno,e.colno))
def load_users(path):
 d=load_json_file(path,'whitelist.json'); u={x['username']:x for x in d.get('users',[]) if isinstance(x,dict) and x.get('username') and x.get('password_hash') and x.get('enabled',True)}
 if not u: raise RuntimeError('whitelist.json contains no enabled users')
 return u
def lan_ips():
 found=[]
 def add(ip):
  if ip and not ip.startswith(('127.','169.254.')) and ip!='0.0.0.0' and ip not in found: found.append(ip)
 if os.name=='nt':
  try:
   out=subprocess.check_output(['ipconfig'],text=True,errors='ignore')
   for ip in re.findall(r'(?:IPv4[^:]*|IP Address[^:]*):\s*([0-9]+(?:\.[0-9]+){3})',out,re.I): add(ip)
  except Exception: pass
 try:
  for x in socket.getaddrinfo(socket.gethostname(),None,socket.AF_INET,socket.SOCK_STREAM): add(x[4][0])
 except Exception: pass
 return found
def create_setup(hostname, admin, password, whitelist, cert_path=None, key_path=None):
 ph=bcrypt.hashpw(password.encode('utf-8'),bcrypt.gensalt()).decode('ascii')
 Path(whitelist).write_text(json.dumps({'users':[{'username':admin,'password_hash':ph,'role':'admin','enabled':True}]},indent=2),encoding='utf-8')
 Path('blacklist.json').write_text(json.dumps({'users':[]},indent=2),encoding='utf-8')

def setup_files_are_valid(a):
 try:
  if not Path(a.whitelist).exists() or Path(a.whitelist).stat().st_size==0: return False
  return any(isinstance(u,dict) and u.get('username') and u.get('password_hash') for u in load_json_file(a.whitelist,'whitelist.json').get('users',[]))
 except Exception as e: log('SETUP','invalid existing setup: %s'%e); return False
def first_run_setup(a):
 if setup_files_are_valid(a): return
 print('\n=== FIRST RUN SERVER SETUP ==='); ips=lan_ips(); default=ips[0] if ips else ''
 for i,ip in enumerate(ips,1): print('  %d. %s'%(i,ip))
 host=input('Server Wi-Fi/LAN IPv4 [%s]: '%default).strip() or default
 while not host or host.startswith('127.'): host=input('Server Wi-Fi/LAN IPv4: ').strip()
 admin=input('Admin username [admin]: ').strip() or 'admin'
 while True:
  pw=getpass.getpass('Admin password: '); confirm=getpass.getpass('Confirm password: ')
  if pw and pw==confirm: break
  print('Passwords did not match or were blank.')
 create_setup(host,admin,pw,a.whitelist,a.cert,a.key); print('Setup complete.\n')
def udp_discovery_responder(tcp_port, advertised_ips):
 try:
  s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM); s.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1); s.setsockopt(socket.SOL_SOCKET,socket.SO_BROADCAST,1); s.bind(('',DISCOVERY_PORT)); log('DISCOVERY','UDP listening on ALL IPv4 interfaces, port %d'%DISCOVERY_PORT); log('DISCOVERY','advertising %s'%(', '.join(advertised_ips) or 'no LAN address detected'))
 except Exception as e: log('DISCOVERY','BIND FAILED: %r'%e); return
 while True:
  try:
   data,addr=s.recvfrom(2048); log('DISCOVERY','RX %s:%d data=%r'%(addr[0],addr[1],data))
   if data==DISCOVERY_QUERY:
    reply=('%s|%d'%(DISCOVERY_REPLY_PREFIX,tcp_port)).encode('ascii'); s.sendto(reply,addr); log('DISCOVERY','TX reply -> %s:%d tcp=%d'%(addr[0],addr[1],tcp_port))
  except Exception as e: log('DISCOVERY','ERROR %r'%e)
class Server:
 def __init__(self,a):
  self.args=a; self.root=Path(a.root).resolve(); self.root.mkdir(parents=True,exist_ok=True); self.users=load_users(a.whitelist); self.clients={}; self.clients_lock=threading.RLock()
 def roster(self): return [{'username':v['name'],'icon':v['icon']} for v in self.clients.values()]
 def send_to_client(self,c,p,raw_binary=None):
  with c['send_lock']: send_packet(c['socket'],p,raw_binary)
 def broadcast(self,p):
  with self.clients_lock: clients=list(self.clients.items())
  for sock,c in clients:
   try:self.send_to_client(c,p)
   except Exception:
    with self.clients_lock:self.clients.pop(sock,None)
 def reply(self,c,r,ok=True,**extra): p={'type':'reply','id':r.get('id'),'ok':ok}; p.update(extra); self.send_to_client(c,p)
 def handle_upload_start(self,c,r):
  p=safe_path(self.root,r.get('path','')); p.parent.mkdir(parents=True,exist_ok=True)
  if c.get('upload_file'): c['upload_file'].close()
  c['upload_file']=open(p,'wb'); c['upload_expected']=int(r.get('size',0)); c['upload_received']=0; self.reply(c,r)
 def handle_upload_chunk(self,c,p,data):
  f=c.get('upload_file')
  if f is None: raise RuntimeError('received upload data without upload_start')
  f.write(data); c['upload_received']+=len(data)
  if p.get('last'):
   f.close(); c['upload_file']=None
   if c['upload_expected'] and c['upload_received']!=c['upload_expected']: raise RuntimeError('upload size mismatch')
 def handle_download(self,c,r):
  p=safe_path(self.root,r.get('path',''))
  if not p.is_file(): self.reply(c,r,False,error='File not found'); return
  size=p.stat().st_size; self.reply(c,r); self.send_to_client(c,{'type':'download_start','request_id':r.get('id'),'name':p.name,'size':size}); sent=0
  with open(p,'rb') as f:
   if size==0:self.send_to_client(c,{'last':True},b'');return
   while sent<size:
    chunk=f.read(CHUNK_SIZE)
    if not chunk:break
    sent+=len(chunk); self.send_to_client(c,{'last':sent>=size},chunk)
 def handle(self,raw,address):
  tls=None;c=None;name=None;discovery=False
  try:
   log('TCP','accepted %s:%d'%address); raw.settimeout(30); tls=raw; log('MESSAGE','plain TCP message session ready %s:%d'%address); log('PROTO','waiting first framed packet'); hello,binary=recv_packet(tls); log('PROTO','first packet=%r'%hello)
   if binary is not None: raise ValueError('expected JSON login packet')
   if hello.get('type')=='ping' and hello.get('probe')=='wifi_tls_share': discovery=True; send_packet(tls,{'type':'pong','service':'wifi_tls_share','version':6,'port':self.args.port}); log('PING','pong sent'); return
   if hello.get('type')=='discovery' and hello.get('probe')=='wifi_tls_share': discovery=True; send_packet(tls,{'type':'discovery_reply','service':'wifi_tls_share','version':6,'port':self.args.port}); log('DISCOVERY','TLS discovery reply sent'); return
   name=str(hello.get('username','')).strip(); user=self.users.get(name); pw=str(hello.get('password',''))
   if not user or not bcrypt.checkpw(pw.encode(),user['password_hash'].encode('ascii')): send_packet(tls,{'ok':False,'error':'Invalid username or password'}); log('AUTH','rejected %r'%name); return
   icon=str(hello.get('icon','')); icon='' if len(icon)>500000 else icon; tls.settimeout(None); c={'socket':tls,'send_lock':threading.Lock(),'name':name,'icon':icon,'upload_file':None};
   with self.clients_lock:self.clients[tls]=c
   self.send_to_client(c,{'ok':True,'type':'welcome','username':name}); log('AUTH','accepted %r'%name); self.broadcast({'type':'roster','users':self.roster()}); self.broadcast({'type':'system','text':name+' joined.'})
   while True:
    r,data=recv_packet(tls)
    if data is not None:self.handle_upload_chunk(c,r,data);continue
    op=r.get('op')
    try:
     if op=='list':
      folder=safe_path(self.root,r.get('path','')); rows=[{'name':x.name,'type':'dir' if x.is_dir() else 'file','size':x.stat().st_size if x.is_file() else 0} for x in sorted(folder.iterdir(),key=lambda v:(not v.is_dir(),v.name.lower()))]; self.reply(c,r,rows=rows)
     elif op=='upload_start':self.handle_upload_start(c,r)
     elif op=='download_req':threading.Thread(target=self.handle_download,args=(c,r),daemon=True).start()
     elif op=='mkdir':safe_path(self.root,r.get('path','')).mkdir(parents=True,exist_ok=False);self.reply(c,r)
     elif op=='delete':
      t=safe_path(self.root,r.get('path','')); t.rmdir() if t.is_dir() else t.unlink(); self.reply(c,r)
     elif op=='message':self.broadcast({'type':'message','username':name,'text':str(r.get('text',''))[:2000],'icon':icon})
     else:self.reply(c,r,False,error='Unknown operation: %r'%op)
    except Exception as e:self.reply(c,r,False,error=str(e))
  except Exception as e:
   if not discovery: log('ERROR','%s:%s %s: %s'%(address[0],address[1],type(e).__name__,e))
  finally:
   if c and c.get('upload_file'):
    try:c['upload_file'].close()
    except:pass
   if tls:
    with self.clients_lock:self.clients.pop(tls,None)
    try:tls.shutdown(socket.SHUT_RDWR)
    except:pass
    try:tls.close()
    except:pass
   else:
    try:raw.close()
    except:pass
   if name:self.broadcast({'type':'system','text':name+' left.'});self.broadcast({'type':'roster','users':self.roster()})
 def run(self):
  l=socket.socket(socket.AF_INET,socket.SOCK_STREAM);l.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);l.bind((self.args.host,self.args.port));l.listen(128);log('TCP','listening %s:%d'%(self.args.host or '0.0.0.0',self.args.port))
  for ip in lan_ips():log('INFO','client address %s:%d'%(ip,self.args.port))
  while True:
   raw,addr=l.accept();threading.Thread(target=self.handle,args=(raw,addr),daemon=True).start()
def main():
 os.chdir(str(Path(__file__).resolve().parent)); p=argparse.ArgumentParser();p.add_argument('--host',default='');p.add_argument('--port',type=int,default=5051);p.add_argument('--root',default='shared_files');p.add_argument('--whitelist',default='whitelist.json');p.add_argument('--cert',default='server_cert.pem');p.add_argument('--key',default='server_key.pem');a=p.parse_args();first_run_setup(a);ips=lan_ips();a.host='';log('INFO','TCP/UDP will listen on ALL IPv4 interfaces');[log('INFO','advertised client target %s:%d'%(ip,a.port)) for ip in ips];threading.Thread(target=udp_discovery_responder,args=(a.port,ips),daemon=True).start();Server(a).run()
if __name__=='__main__':main()
