#!/usr/bin/env python3
import argparse,bcrypt,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--admin',default='admin');p.add_argument('--password',required=True);a=p.parse_args();h=bcrypt.hashpw(a.password.encode(),bcrypt.gensalt()).decode();Path('users.json').write_text(json.dumps({'users':[{'username':a.admin,'password_hash':h,'role':'admin','enabled':True}]},indent=2));print('Created users.json with admin:',a.admin)
