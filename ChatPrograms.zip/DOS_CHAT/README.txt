DOS CHAT
========
1. Run SERVER.BAT on the host computer.
2. Allow TCP port 2323 through Windows Firewall if prompted.
3. Run CLIENT.BAT on each computer and enter the server IP.

Optional command-line examples:
  SERVER.BAT -Port 2323
  CLIENT.BAT -Server 192.168.1.10 -Port 2323 -Name Shawn

Client commands:
  /users
  /msg USER message
  /send USER C:\path\file.zip
  /sendall C:\path\file.zip
  /quit

Received files are stored in the DOWNLOADS folder.
Security note: This is intended for trusted LAN use. Traffic and files are not encrypted.
