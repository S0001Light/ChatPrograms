from __future__ import annotations
import base64,io,tkinter as tk
from PIL import Image,ImageTk,ImageDraw
class AvatarFactory:
 def __init__(self):self.images=[]
 def make(self,data,size=38):
  try:im=Image.open(io.BytesIO(base64.b64decode(data,validate=True))).convert('RGBA').resize((size,size),Image.Resampling.LANCZOS)
  except Exception:
   im=Image.new('RGBA',(size,size),(80,110,150,255));d=ImageDraw.Draw(im);d.ellipse((size*.30,size*.12,size*.70,size*.52),fill='white');d.ellipse((size*.16,size*.50,size*.84,size*1.05),fill='white')
  mask=Image.new('L',(size,size));ImageDraw.Draw(mask).ellipse((0,0,size-1,size-1),fill=255);im.putalpha(mask);p=ImageTk.PhotoImage(im);self.images.append(p);return p
class IconChatView(tk.Frame):
 def __init__(self,master,current_username):
  super().__init__(master);self.current_username=current_username;self.avatars=AvatarFactory();self.canvas=tk.Canvas(self,highlightthickness=0,bg='#f4f6f8');self.scroll=tk.Scrollbar(self,command=self.canvas.yview);self.body=tk.Frame(self.canvas,bg='#f4f6f8');self.window=self.canvas.create_window((0,0),window=self.body,anchor='nw');self.canvas.configure(yscrollcommand=self.scroll.set);self.canvas.pack(side='left',fill='both',expand=True);self.scroll.pack(side='right',fill='y');self.body.bind('<Configure>',lambda e:self.canvas.configure(scrollregion=self.canvas.bbox('all')));self.canvas.bind('<Configure>',lambda e:self.canvas.itemconfigure(self.window,width=e.width))
 def message(self,username,text,icon='',role='client'):
  mine=username.casefold()==self.current_username().strip().casefold();row=tk.Frame(self.body,bg='#f4f6f8');row.pack(fill='x',padx=10,pady=5);photo=self.avatars.make(icon);avatar=tk.Label(row,image=photo,bg='#f4f6f8');color='#1877d2' if mine else 'white';fg='white' if mine else '#111';bubble=tk.Frame(row,bg=color);title=username+(' [admin]' if role=='admin' else '');tk.Label(bubble,text=title,font=('Segoe UI',9,'bold'),anchor='w',bg=color,fg=fg).pack(fill='x',padx=10,pady=(6,0));tk.Label(bubble,text=text,wraplength=500,justify='left',anchor='w',bg=color,fg=fg).pack(fill='x',padx=10,pady=(2,8));
  if mine:avatar.pack(side='right',padx=(7,0));bubble.pack(side='right')
  else:avatar.pack(side='left',padx=(0,7));bubble.pack(side='left')
  self.after_idle(lambda:self.canvas.yview_moveto(1.0))
 def system(self,text):tk.Label(self.body,text=text,bg='#f4f6f8',fg='#666',font=('Segoe UI',9,'italic')).pack(pady=5)
 def clear(self):
  for w in self.body.winfo_children():w.destroy()
  self.avatars.images.clear()
class IconRoster(tk.Frame):
 def __init__(self,master):super().__init__(master);self.avatars=AvatarFactory()
 def set_users(self,users):
  for w in self.winfo_children():w.destroy()
  self.avatars.images.clear()
  for u in users:
   row=tk.Frame(self);row.pack(fill='x',pady=3);photo=self.avatars.make(u.get('icon',''),30);tk.Label(row,image=photo).pack(side='left',padx=4);label=u.get('username','?')+(' [admin]' if u.get('role')=='admin' else '');tk.Label(row,text=label,anchor='w').pack(side='left',fill='x')
