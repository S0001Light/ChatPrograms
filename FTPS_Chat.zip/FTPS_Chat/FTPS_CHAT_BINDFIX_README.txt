FTPS + Chat bind fix for Windows error 10049

The server now binds FTPS and TLS chat sockets to 0.0.0.0, which means all local IPv4 interfaces. The --host value is advertised to clients but is never used as the local bind address. This prevents WinError 10049 when the entered address is not presently assigned to the server adapter.

Install:
  py -m pip install pyftpdlib pyOpenSSL cryptography

Start server as Administrator:
  py ftps_chat_server_bindfix.py --host 192.168.1.126

If 192.168.1.126 is not the server's current LAN address, omit --host:
  py ftps_chat_server_bindfix.py

Start client:
  py ftps_chat_client_bindfix.py

Ports:
  TCP 2121 FTPS control
  UDP 2122 discovery
  TCP 2123 TLS chat
  TCP 60000-60049 passive FTPS data
