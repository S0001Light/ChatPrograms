#!/usr/bin/env python3
import argparse,bcrypt,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('username');p.add_argument('--password',required=True);p.add_argument('--role',choices=['client','admin'],default='client');p.add_argument('--disable',action='store_true');a=p.parse_args();path=Path('users.json');data=json.loads(path.read_text());data['users']=[u for u in data['users'] if u['username']!=a.username];data['users'].append({'username':a.username,'password_hash':bcrypt.hashpw(a.password.encode(),bcrypt.gensalt()).decode(),'role':a.role,'enabled':not a.disable});path.write_text(json.dumps(data,indent=2));print('Updated:',a.username)
