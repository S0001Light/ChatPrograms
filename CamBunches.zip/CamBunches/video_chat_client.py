import json
import os
import socket
import struct
import threading
import time
import tkinter as tk
from tkinter import filedialog

import cv2
import numpy as np
import pygame


# ============================================================
# CONFIGURATION
# ============================================================

WIDTH = 1280
HEIGHT = 720

CHAT_WIDTH = 350
CAMERA_AREA_WIDTH = WIDTH - CHAT_WIDTH

SERVER_IP = "192.168.1.72"

CHAT_PORT = 5000
FILE_PORT = 5001

MAX_USERS = 20

GRID_COLUMNS = 5
GRID_ROWS = 4

CAMERA_INDEX = 0

SEND_WIDTH = 320
SEND_HEIGHT = 180

VIDEO_FPS = 8
JPEG_QUALITY = 35

MAX_MESSAGE_LENGTH = 500

FILE_BUFFER_SIZE = 64 * 1024
MAX_FILE_SIZE = 100 * 1024 * 1024


# ============================================================
# LOCAL DIRECTORIES
# ============================================================

BASE_DIR = os.path.dirname(
    os.path.abspath(__file__)
)

DOWNLOAD_DIR = os.path.join(
    BASE_DIR,
    "downloads"
)

os.makedirs(
    DOWNLOAD_DIR,
    exist_ok=True
)


# ============================================================
# PYGAME INITIALIZATION
# ============================================================

pygame.init()

screen = pygame.display.set_mode(
    (WIDTH, HEIGHT)
)

pygame.display.set_caption(
    "CamBunches"
)

clock = pygame.time.Clock()

font = pygame.font.SysFont(
    "consolas",
    16
)

small_font = pygame.font.SysFont(
    "consolas",
    13
)

large_font = pygame.font.SysFont(
    "consolas",
    22
)


# ============================================================
# THEME
# ============================================================

theme = {
    "bg": (25, 25, 25),
    "panel": (37, 37, 37),
    "panel2": (48, 48, 48),

    "border": (70, 70, 70),

    "text": (237, 237, 237),
    "muted": (150, 150, 150),

    "accent": (0, 174, 239),
    "accent_hover": (30, 194, 255),

    "success": (70, 200, 100),
    "error": (255, 90, 90),

    "input_bg": (45, 45, 45),
    "input_border": (90, 90, 90),

    "black": (0, 0, 0)
}


# ============================================================
# LOCAL USER
# ============================================================

username = "Shawn"

icon_color = (
    0,
    200,
    255
)

my_id = None


# ============================================================
# APPLICATION STATE
# ============================================================

running = True
connected = False

mode = "chat"

current_input = ""

last_video_send = 0.0

chat_socket = None

send_lock = threading.Lock()


# ============================================================
# USERS
# ============================================================

users = {}
users_lock = threading.Lock()


# ============================================================
# CHAT
# ============================================================

chat_log = []
chat_lock = threading.Lock()


# ============================================================
# FILE SERVER STATE
# ============================================================

server_files = []
server_files_lock = threading.Lock()

file_status = "Press REFRESH to load shared files."

file_operation_running = False
file_operation_lock = threading.Lock()

file_scroll = 0


# ============================================================
# GENERAL HELPERS
# ============================================================

def recv_exact(sock, size):
    """
    Receive exactly the requested number of bytes from a socket.
    """

    data = bytearray()

    while len(data) < size:
        chunk = sock.recv(
            size - len(data)
        )

        if not chunk:
            raise ConnectionError(
                "Connection closed"
            )

        data.extend(chunk)

    return bytes(data)


def clean_local_filename(filename):
    """
    Remove any directory information from a received filename.
    """

    filename = os.path.basename(
        str(filename)
    )

    filename = filename.replace(
        "\x00",
        ""
    )

    return filename[:255]


def set_file_operation_running(value):
    global file_operation_running

    with file_operation_lock:
        file_operation_running = value


def is_file_operation_running():
    with file_operation_lock:
        return file_operation_running


# ============================================================
# CHAT HELPERS
# ============================================================

def add_chat_message(user_id, message):
    with chat_lock:
        chat_log.append(
            (
                user_id,
                str(message)
            )
        )

        if len(chat_log) > 250:
            del chat_log[:-250]


def add_system_message(message):
    add_chat_message(
        0,
        message
    )


def wrap_text(
    text,
    selected_font,
    maximum_width
):
    if not text:
        return [""]

    words = text.split(" ")

    output = []
    current_line = ""

    for word in words:
        if current_line:
            test_line = (
                current_line
                + " "
                + word
            )
        else:
            test_line = word

        if (
            selected_font.size(
                test_line
            )[0]
            <= maximum_width
        ):
            current_line = test_line

        else:
            if current_line:
                output.append(
                    current_line
                )

            # Break individual words that are too wide.
            if (
                selected_font.size(
                    word
                )[0]
                > maximum_width
            ):
                part = ""

                for character in word:
                    test_part = (
                        part
                        + character
                    )

                    if (
                        selected_font.size(
                            test_part
                        )[0]
                        <= maximum_width
                    ):
                        part = test_part

                    else:
                        if part:
                            output.append(
                                part
                            )

                        part = character

                current_line = part

            else:
                current_line = word

    if current_line:
        output.append(
            current_line
        )

    return output or [""]


# ============================================================
# USER MANAGEMENT
# ============================================================

def create_default_user(user_id):
    return {
        "username": f"User {user_id}",
        "icon_color": (200, 200, 200),
        "frame": None
    }


def update_user(
    user_id,
    new_username=None,
    new_color=None
):
    with users_lock:
        if user_id not in users:
            users[user_id] = (
                create_default_user(
                    user_id
                )
            )

        if new_username is not None:
            users[user_id]["username"] = (
                str(new_username)[:24]
            )

        if new_color is not None:
            try:
                color = tuple(
                    max(
                        0,
                        min(
                            255,
                            int(value)
                        )
                    )
                    for value in new_color[:3]
                )

                if len(color) == 3:
                    users[user_id]["icon_color"] = (
                        color
                    )

            except (
                ValueError,
                TypeError,
                IndexError
            ):
                pass


def update_user_frame(user_id, frame):
    with users_lock:
        if user_id not in users:
            users[user_id] = (
                create_default_user(
                    user_id
                )
            )

        users[user_id]["frame"] = frame


def remove_user(user_id):
    with users_lock:
        users.pop(
            user_id,
            None
        )


# ============================================================
# CHAT SERVER SEND
# ============================================================

def send_packet(packet_type, payload=b""):
    global connected

    if not connected:
        return False

    if chat_socket is None:
        return False

    packet = (
        packet_type
        + len(payload).to_bytes(
            4,
            "big"
        )
        + payload
    )

    try:
        with send_lock:
            chat_socket.sendall(
                packet
            )

        return True

    except (
        OSError,
        ConnectionError,
        ConnectionResetError,
        BrokenPipeError
    ) as error:
        print(
            f"Send error: {error}"
        )

        connected = False

        return False


def send_userinfo():
    information = {
        "username": username,
        "icon_color": list(
            icon_color
        )
    }

    payload = json.dumps(
        information
    ).encode(
        "utf-8"
    )

    send_packet(
        b"U",
        payload
    )


def send_text(message):
    message = message.strip()

    if not message:
        return

    message = message[
        :MAX_MESSAGE_LENGTH
    ]

    send_packet(
        b"T",
        message.encode(
            "utf-8"
        )
    )


def send_video(frame):
    reduced_frame = cv2.resize(
        frame,
        (
            SEND_WIDTH,
            SEND_HEIGHT
        ),
        interpolation=cv2.INTER_AREA
    )

    success, jpeg = cv2.imencode(
        ".jpg",
        reduced_frame,
        [
            cv2.IMWRITE_JPEG_QUALITY,
            JPEG_QUALITY
        ]
    )

    if not success:
        return

    send_packet(
        b"V",
        jpeg.tobytes()
    )


# ============================================================
# CHAT SERVER RECEIVE
# ============================================================

def network_loop():
    global my_id
    global connected

    try:
        while connected:
            header = recv_exact(
                chat_socket,
                5
            )

            packet_type = header[:1]

            payload_length = int.from_bytes(
                header[1:5],
                "big"
            )

            if payload_length > 2_000_000:
                raise ValueError(
                    "Incoming packet is too large"
                )

            payload = recv_exact(
                chat_socket,
                payload_length
            )

            # ------------------------------------------------
            # ASSIGNED CLIENT ID
            # ------------------------------------------------

            if packet_type == b"I":
                my_id = int.from_bytes(
                    payload,
                    "big"
                )

                update_user(
                    my_id,
                    username,
                    icon_color
                )

                send_userinfo()

                print(
                    f"Assigned client ID: {my_id}"
                )

            # ------------------------------------------------
            # ROSTER ENTRY
            # ------------------------------------------------

            elif packet_type == b"J":
                information = json.loads(
                    payload.decode(
                        "utf-8"
                    )
                )

                user_id = int(
                    information["id"]
                )

                update_user(
                    user_id,
                    information.get(
                        "username",
                        f"User {user_id}"
                    ),
                    information.get(
                        "icon_color",
                        [200, 200, 200]
                    )
                )

            # ------------------------------------------------
            # USER INFORMATION UPDATE
            # ------------------------------------------------

            elif packet_type == b"U":
                if len(payload) < 4:
                    continue

                user_id = int.from_bytes(
                    payload[:4],
                    "big"
                )

                information = json.loads(
                    payload[4:].decode(
                        "utf-8"
                    )
                )

                update_user(
                    user_id,
                    information.get(
                        "username",
                        f"User {user_id}"
                    ),
                    information.get(
                        "icon_color",
                        [200, 200, 200]
                    )
                )

            # ------------------------------------------------
            # CHAT MESSAGE
            # ------------------------------------------------

            elif packet_type == b"T":
                if len(payload) < 4:
                    continue

                user_id = int.from_bytes(
                    payload[:4],
                    "big"
                )

                message = payload[4:].decode(
                    "utf-8",
                    errors="replace"
                )

                add_chat_message(
                    user_id,
                    message
                )

            # ------------------------------------------------
            # VIDEO FRAME
            # ------------------------------------------------

            elif packet_type == b"V":
                if len(payload) < 5:
                    continue

                user_id = int.from_bytes(
                    payload[:4],
                    "big"
                )

                jpeg_data = payload[4:]

                jpeg_array = np.frombuffer(
                    jpeg_data,
                    dtype=np.uint8
                )

                frame = cv2.imdecode(
                    jpeg_array,
                    cv2.IMREAD_COLOR
                )

                if frame is not None:
                    update_user_frame(
                        user_id,
                        frame
                    )

            # ------------------------------------------------
            # USER LEFT
            # ------------------------------------------------

            elif packet_type == b"L":
                if len(payload) < 4:
                    continue

                user_id = int.from_bytes(
                    payload[:4],
                    "big"
                )

                with users_lock:
                    departed_name = users.get(
                        user_id,
                        {}
                    ).get(
                        "username",
                        f"User {user_id}"
                    )

                remove_user(
                    user_id
                )

                add_system_message(
                    departed_name
                    + " disconnected"
                )

            # ------------------------------------------------
            # SERVER ERROR
            # ------------------------------------------------

            elif packet_type == b"E":
                message = payload.decode(
                    "utf-8",
                    errors="replace"
                )

                add_system_message(
                    message
                )

                connected = False

    except (
        OSError,
        ConnectionError,
        ConnectionResetError,
        BrokenPipeError,
        ValueError,
        json.JSONDecodeError
    ) as error:
        print(
            f"Network connection ended: {error}"
        )

    finally:
        if connected:
            add_system_message(
                "Disconnected from server"
            )

        connected = False


# ============================================================
# CAMERA OPENING
# ============================================================

def open_camera():
    backends = [
        (
            "DirectShow",
            cv2.CAP_DSHOW
        ),
        (
            "Media Foundation",
            cv2.CAP_MSMF
        ),
        (
            "Automatic",
            cv2.CAP_ANY
        )
    ]

    camera_indexes = [
        CAMERA_INDEX
    ]

    for index in range(5):
        if index not in camera_indexes:
            camera_indexes.append(
                index
            )

    for index in camera_indexes:
        for backend_name, backend in backends:
            print(
                f"Trying camera {index} "
                f"using {backend_name}..."
            )

            candidate = cv2.VideoCapture(
                index,
                backend
            )

            if not candidate.isOpened():
                candidate.release()
                continue

            candidate.set(
                cv2.CAP_PROP_FRAME_WIDTH,
                SEND_WIDTH
            )

            candidate.set(
                cv2.CAP_PROP_FRAME_HEIGHT,
                SEND_HEIGHT
            )

            candidate.set(
                cv2.CAP_PROP_FPS,
                VIDEO_FPS
            )

            candidate.set(
                cv2.CAP_PROP_BUFFERSIZE,
                1
            )

            for attempt in range(12):
                success, frame = (
                    candidate.read()
                )

                if (
                    success
                    and frame is not None
                    and frame.size > 0
                ):
                    print(
                        f"Camera opened: "
                        f"index {index}, "
                        f"{backend_name}"
                    )

                    return candidate

                time.sleep(
                    0.05
                )

            candidate.release()

    print(
        "No working camera was found."
    )

    return None


# ============================================================
# CAMERA FRAME CONVERSION
# ============================================================

def frame_to_surface(
    frame,
    maximum_width,
    maximum_height
):
    rgb = cv2.cvtColor(
        frame,
        cv2.COLOR_BGR2RGB
    )

    frame_height, frame_width = (
        rgb.shape[:2]
    )

    scale = min(
        maximum_width / frame_width,
        maximum_height / frame_height
    )

    new_width = max(
        1,
        int(
            frame_width
            * scale
        )
    )

    new_height = max(
        1,
        int(
            frame_height
            * scale
        )
    )

    resized = cv2.resize(
        rgb,
        (
            new_width,
            new_height
        ),
        interpolation=cv2.INTER_AREA
    )

    return pygame.image.frombuffer(
        resized.tobytes(),
        (
            new_width,
            new_height
        ),
        "RGB"
    ).copy()


# ============================================================
# DRAW BUTTON
# ============================================================

def draw_button(
    rect,
    text,
    color=None,
    disabled=False
):
    if color is None:
        color = theme["panel2"]

    if disabled:
        draw_color = (
            50,
            50,
            50
        )

        text_color = theme["muted"]

    else:
        mouse_position = (
            pygame.mouse.get_pos()
        )

        if rect.collidepoint(
            mouse_position
        ):
            if color == theme["accent"]:
                draw_color = theme[
                    "accent_hover"
                ]

            else:
                draw_color = (
                    60,
                    60,
                    60
                )

        else:
            draw_color = color

        text_color = theme["text"]

    pygame.draw.rect(
        screen,
        draw_color,
        rect
    )

    pygame.draw.rect(
        screen,
        theme["border"],
        rect,
        1
    )

    text_surface = small_font.render(
        text,
        True,
        text_color
    )

    screen.blit(
        text_surface,
        text_surface.get_rect(
            center=rect.center
        )
    )


# ============================================================
# DRAW ONE CAMERA TILE
# ============================================================

def draw_camera_tile(
    rect,
    user_id,
    user_data
):
    pygame.draw.rect(
        screen,
        theme["panel"],
        rect
    )

    if user_id == my_id:
        border_color = theme["accent"]
        border_width = 2

    else:
        border_color = theme["border"]
        border_width = 1

    pygame.draw.rect(
        screen,
        border_color,
        rect,
        border_width
    )

    video_rect = pygame.Rect(
        rect.x + 3,
        rect.y + 3,
        rect.width - 6,
        rect.height - 29
    )

    frame = user_data.get(
        "frame"
    )

    frame_drawn = False

    if frame is not None:
        try:
            surface = frame_to_surface(
                frame,
                video_rect.width,
                video_rect.height
            )

            screen.blit(
                surface,
                (
                    video_rect.centerx
                    - surface.get_width()
                    // 2,

                    video_rect.centery
                    - surface.get_height()
                    // 2
                )
            )

            frame_drawn = True

        except (
            cv2.error,
            pygame.error,
            ValueError
        ):
            frame_drawn = False

    if not frame_drawn:
        color = user_data.get(
            "icon_color",
            (200, 200, 200)
        )

        pygame.draw.circle(
            screen,
            color,
            video_rect.center,
            20
        )

        no_camera_surface = small_font.render(
            "No camera",
            True,
            theme["muted"]
        )

        screen.blit(
            no_camera_surface,
            no_camera_surface.get_rect(
                center=(
                    video_rect.centerx,
                    video_rect.centery + 34
                )
            )
        )

    # --------------------------------------------------------
    # USERNAME BAR
    # --------------------------------------------------------

    name_bar = pygame.Rect(
        rect.x + 1,
        rect.bottom - 25,
        rect.width - 2,
        24
    )

    pygame.draw.rect(
        screen,
        theme["black"],
        name_bar
    )

    name = user_data.get(
        "username",
        f"User {user_id}"
    )

    if user_id == my_id:
        name += " (You)"

    while (
        name
        and small_font.size(name)[0]
        > rect.width - 34
    ):
        name = name[:-1]

    color = user_data.get(
        "icon_color",
        (200, 200, 200)
    )

    pygame.draw.circle(
        screen,
        color,
        (
            rect.x + 11,
            rect.bottom - 13
        ),
        5
    )

    name_surface = small_font.render(
        name,
        True,
        theme["text"]
    )

    screen.blit(
        name_surface,
        (
            rect.x + 21,
            rect.bottom - 21
        )
    )


# ============================================================
# DRAW CAMERA GRID
# ============================================================

def draw_camera_grid(local_frame):
    tile_width = (
        CAMERA_AREA_WIDTH
        // GRID_COLUMNS
    )

    tile_height = (
        HEIGHT
        // GRID_ROWS
    )

    with users_lock:
        snapshot = {
            user_id: dict(user_data)
            for user_id, user_data
            in users.items()
        }

    # Use -1 until the server has assigned a real ID.
    local_id = (
        my_id
        if my_id is not None
        else -1
    )

    if local_id not in snapshot:
        snapshot[local_id] = (
            create_default_user(
                local_id
            )
        )

    snapshot[local_id]["username"] = (
        username
    )

    snapshot[local_id]["icon_color"] = (
        icon_color
    )

    snapshot[local_id]["frame"] = (
        local_frame
    )

    if my_id is not None:
        snapshot.pop(
            -1,
            None
        )

    ordered_users = sorted(
        snapshot.items(),
        key=lambda item: (
            0
            if item[0] == my_id
            else 1,
            item[0]
        )
    )[:MAX_USERS]

    for slot in range(MAX_USERS):
        row = slot // GRID_COLUMNS
        column = slot % GRID_COLUMNS

        tile_x = column * tile_width
        tile_y = row * tile_height

        if column == GRID_COLUMNS - 1:
            current_width = (
                CAMERA_AREA_WIDTH
                - tile_x
            )

        else:
            current_width = tile_width

        if row == GRID_ROWS - 1:
            current_height = (
                HEIGHT
                - tile_y
            )

        else:
            current_height = tile_height

        tile_rect = pygame.Rect(
            tile_x,
            tile_y,
            current_width,
            current_height
        )

        if slot < len(ordered_users):
            user_id, user_data = (
                ordered_users[slot]
            )

            draw_camera_tile(
                tile_rect,
                user_id,
                user_data
            )

        else:
            pygame.draw.rect(
                screen,
                theme["panel"],
                tile_rect
            )

            pygame.draw.rect(
                screen,
                theme["border"],
                tile_rect,
                1
            )

            empty_surface = small_font.render(
                f"Empty {slot + 1}",
                True,
                theme["muted"]
            )

            screen.blit(
                empty_surface,
                empty_surface.get_rect(
                    center=tile_rect.center
                )
            )


# ============================================================
# DRAW CHAT PANEL
# ============================================================

def draw_chat():
    panel = pygame.Rect(
        CAMERA_AREA_WIDTH,
        0,
        CHAT_WIDTH,
        HEIGHT
    )

    pygame.draw.rect(
        screen,
        theme["panel"],
        panel
    )

    pygame.draw.line(
        screen,
        theme["border"],
        (
            panel.x,
            0
        ),
        (
            panel.x,
            HEIGHT
        ),
        1
    )

    title_surface = large_font.render(
        "CamBunches",
        True,
        theme["text"]
    )

    screen.blit(
        title_surface,
        (
            panel.x + 10,
            8
        )
    )

    with users_lock:
        user_count = len(
            users
        )

    if (
        my_id is None
        or my_id not in users
    ):
        user_count += 1

    user_count = min(
        MAX_USERS,
        user_count
    )

    if connected:
        status_text = (
            f"Online | "
            f"{user_count}/{MAX_USERS} users"
        )

        status_color = theme[
            "success"
        ]

    else:
        status_text = "Disconnected"

        status_color = theme[
            "error"
        ]

    status_surface = small_font.render(
        status_text,
        True,
        status_color
    )

    screen.blit(
        status_surface,
        (
            panel.x + 10,
            36
        )
    )

    # --------------------------------------------------------
    # FILE BUTTONS
    # --------------------------------------------------------

    server_files_button = pygame.Rect(
        panel.x + 10,
        62,
        155,
        32
    )

    upload_button = pygame.Rect(
        panel.x + 175,
        62,
        165,
        32
    )

    draw_button(
        server_files_button,
        "SERVER FILES"
    )

    draw_button(
        upload_button,
        "UPLOAD",
        theme["accent"],
        disabled=is_file_operation_running()
    )

    # --------------------------------------------------------
    # CHAT MESSAGES
    # --------------------------------------------------------

    with users_lock:
        names = {
            user_id: data.get(
                "username",
                f"User {user_id}"
            )
            for user_id, data
            in users.items()
        }

    if my_id is not None:
        names[my_id] = username

    with chat_lock:
        messages = list(
            chat_log
        )

    lines = []

    for user_id, message in messages:
        if user_id == 0:
            prefix = "System"

        else:
            prefix = names.get(
                user_id,
                f"User {user_id}"
            )

        complete_message = (
            prefix
            + ": "
            + message
        )

        lines.extend(
            wrap_text(
                complete_message,
                small_font,
                CHAT_WIDTH - 20
            )
        )

    input_box = pygame.Rect(
        panel.x + 10,
        HEIGHT - 42,
        CHAT_WIDTH - 20,
        32
    )

    chat_top = 108
    line_height = 16

    maximum_lines = max(
        1,
        (
            input_box.y
            - chat_top
            - 8
        )
        // line_height
    )

    lines = lines[
        -maximum_lines:
    ]

    draw_y = chat_top

    for line in lines:
        line_surface = small_font.render(
            line,
            True,
            theme["text"]
        )

        screen.blit(
            line_surface,
            (
                panel.x + 10,
                draw_y
            )
        )

        draw_y += line_height

    # --------------------------------------------------------
    # CHAT INPUT
    # --------------------------------------------------------

    pygame.draw.rect(
        screen,
        theme["input_bg"],
        input_box
    )

    pygame.draw.rect(
        screen,
        theme["input_border"],
        input_box,
        1
    )

    displayed_input = current_input

    while (
        displayed_input
        and font.size(
            displayed_input
        )[0]
        > input_box.width - 14
    ):
        displayed_input = (
            displayed_input[1:]
        )

    input_surface = font.render(
        displayed_input,
        True,
        theme["text"]
    )

    screen.blit(
        input_surface,
        (
            input_box.x + 6,
            input_box.y + 6
        )
    )

    if (
        int(
            time.time() * 2
        )
        % 2
        == 0
    ):
        cursor_x = (
            input_box.x
            + 6
            + input_surface.get_width()
        )

        pygame.draw.line(
            screen,
            theme["accent"],
            (
                cursor_x,
                input_box.y + 5
            ),
            (
                cursor_x,
                input_box.bottom - 5
            ),
            2
        )


# ============================================================
# FILE SERVER CONNECTION
# ============================================================

def connect_file_server():
    file_socket = socket.socket(
        socket.AF_INET,
        socket.SOCK_STREAM
    )

    file_socket.setsockopt(
        socket.IPPROTO_TCP,
        socket.TCP_NODELAY,
        1
    )

    file_socket.settimeout(
        5.0
    )

    file_socket.connect(
        (
            SERVER_IP,
            FILE_PORT
        )
    )

    file_socket.settimeout(
        None
    )

    return file_socket


def receive_file_packet(sock):
    packet_type = recv_exact(
        sock,
        1
    )

    payload_size = struct.unpack(
        "!Q",
        recv_exact(
            sock,
            8
        )
    )[0]

    maximum_packet_size = (
        MAX_FILE_SIZE
        + 1024 * 1024
    )

    if payload_size > maximum_packet_size:
        raise ValueError(
            "File-server response is too large"
        )

    payload = recv_exact(
        sock,
        payload_size
    )

    return (
        packet_type,
        payload
    )


# ============================================================
# FILE LIST
# ============================================================

def refresh_file_list_worker():
    global server_files
    global file_status
    global file_scroll

    set_file_operation_running(
        True
    )

    file_status = (
        "Loading server files..."
    )

    file_socket = None

    try:
        file_socket = (
            connect_file_server()
        )

        file_socket.sendall(
            b"L"
        )

        packet_type, payload = (
            receive_file_packet(
                file_socket
            )
        )

        if packet_type == b"L":
            result = json.loads(
                payload.decode(
                    "utf-8"
                )
            )

            if not isinstance(
                result,
                list
            ):
                result = []

            cleaned_files = []

            for item in result:
                if not isinstance(
                    item,
                    dict
                ):
                    continue

                filename = clean_local_filename(
                    item.get(
                        "name",
                        ""
                    )
                )

                try:
                    file_size = int(
                        item.get(
                            "size",
                            0
                        )
                    )

                except (
                    TypeError,
                    ValueError
                ):
                    file_size = 0

                if filename:
                    cleaned_files.append({
                        "name": filename,
                        "size": max(
                            0,
                            file_size
                        )
                    })

            with server_files_lock:
                server_files = (
                    cleaned_files
                )

            file_scroll = 0

            file_status = (
                f"{len(cleaned_files)} "
                f"shared file(s)"
            )

        elif packet_type == b"E":
            file_status = payload.decode(
                "utf-8",
                errors="replace"
            )

        else:
            file_status = (
                "Unexpected file-server response."
            )

    except Exception as error:
        file_status = (
            "File server error: "
            + str(error)
        )

    finally:
        if file_socket is not None:
            try:
                file_socket.close()
            except OSError:
                pass

        set_file_operation_running(
            False
        )


def refresh_file_list():
    global file_status

    if is_file_operation_running():
        file_status = (
            "Another file operation is running."
        )

        return

    threading.Thread(
        target=refresh_file_list_worker,
        daemon=True,
        name="RefreshFileList"
    ).start()


# ============================================================
# UPLOAD FILE SELECTION
# ============================================================

def select_upload_file():
    root = tk.Tk()

    root.withdraw()

    try:
        root.attributes(
            "-topmost",
            True
        )

        root.update()

    except tk.TclError:
        pass

    try:
        selected_path = (
            filedialog.askopenfilename(
                parent=root,
                title="Select file to upload",
                filetypes=[
                    (
                        "All files",
                        "*.*"
                    )
                ]
            )
        )

    finally:
        root.destroy()

    return selected_path


# ============================================================
# FILE UPLOAD
# ============================================================

def upload_file_worker(filepath):
    global file_status

    set_file_operation_running(
        True
    )

    file_socket = None

    try:
        if not os.path.isfile(
            filepath
        ):
            raise ValueError(
                "Selected file does not exist"
            )

        file_size = os.path.getsize(
            filepath
        )

        if file_size > MAX_FILE_SIZE:
            raise ValueError(
                "File exceeds the 100 MB limit"
            )

        filename = clean_local_filename(
            filepath
        )

        filename_data = filename.encode(
            "utf-8"
        )

        if not filename_data:
            raise ValueError(
                "Invalid filename"
            )

        if len(filename_data) > 255:
            raise ValueError(
                "Filename is too long"
            )

        file_socket = (
            connect_file_server()
        )

        file_status = (
            "Uploading "
            + filename
            + "..."
        )

        # Upload protocol:
        #
        # U
        # uint16 filename length
        # filename
        # uint64 file size
        # file data

        file_socket.sendall(
            b"U"
        )

        file_socket.sendall(
            struct.pack(
                "!H",
                len(filename_data)
            )
        )

        file_socket.sendall(
            filename_data
        )

        file_socket.sendall(
            struct.pack(
                "!Q",
                file_size
            )
        )

        bytes_sent = 0

        with open(
            filepath,
            "rb"
        ) as input_file:
            while True:
                chunk = input_file.read(
                    FILE_BUFFER_SIZE
                )

                if not chunk:
                    break

                file_socket.sendall(
                    chunk
                )

                bytes_sent += len(
                    chunk
                )

                if file_size > 0:
                    percentage = int(
                        bytes_sent
                        * 100
                        / file_size
                    )

                    file_status = (
                        f"Uploading "
                        f"{filename}: "
                        f"{percentage}%"
                    )

        packet_type, payload = (
            receive_file_packet(
                file_socket
            )
        )

        if packet_type == b"O":
            file_status = (
                "Uploaded: "
                + filename
            )

            add_system_message(
                username
                + " uploaded "
                + filename
            )

        elif packet_type == b"E":
            raise ValueError(
                payload.decode(
                    "utf-8",
                    errors="replace"
                )
            )

        else:
            raise ValueError(
                "Unexpected upload response"
            )

    except Exception as error:
        file_status = (
            "Upload failed: "
            + str(error)
        )

    finally:
        if file_socket is not None:
            try:
                file_socket.close()
            except OSError:
                pass

        set_file_operation_running(
            False
        )


def start_upload():
    global file_status

    if is_file_operation_running():
        file_status = (
            "Another file operation is running."
        )

        return

    try:
        filepath = (
            select_upload_file()
        )

    except Exception as error:
        file_status = (
            "Could not open file picker: "
            + str(error)
        )

        return

    if not filepath:
        file_status = (
            "Upload cancelled."
        )

        return

    threading.Thread(
        target=upload_file_worker,
        args=(
            filepath,
        ),
        daemon=True,
        name="FileUpload"
    ).start()


# ============================================================
# FILE DOWNLOAD
# ============================================================

def download_file_worker(filename):
    global file_status

    set_file_operation_running(
        True
    )

    file_socket = None
    output_path = None

    try:
        filename = clean_local_filename(
            filename
        )

        filename_data = filename.encode(
            "utf-8"
        )

        if not filename_data:
            raise ValueError(
                "Invalid filename"
            )

        if len(filename_data) > 255:
            raise ValueError(
                "Filename is too long"
            )

        file_socket = (
            connect_file_server()
        )

        file_status = (
            "Downloading "
            + filename
            + "..."
        )

        # Download request:
        #
        # D
        # uint16 filename length
        # filename

        file_socket.sendall(
            b"D"
        )

        file_socket.sendall(
            struct.pack(
                "!H",
                len(filename_data)
            )
        )

        file_socket.sendall(
            filename_data
        )

        response_type = recv_exact(
            file_socket,
            1
        )

        # Standard error packet:
        #
        # E
        # uint64 payload length
        # error message

        if response_type == b"E":
            error_size = struct.unpack(
                "!Q",
                recv_exact(
                    file_socket,
                    8
                )
            )[0]

            error_message = recv_exact(
                file_socket,
                error_size
            ).decode(
                "utf-8",
                errors="replace"
            )

            raise ValueError(
                error_message
            )

        if response_type != b"D":
            raise ValueError(
                "Unexpected download response"
            )

        received_name_length = (
            struct.unpack(
                "!H",
                recv_exact(
                    file_socket,
                    2
                )
            )[0]
        )

        if (
            received_name_length <= 0
            or received_name_length > 255
        ):
            raise ValueError(
                "Invalid downloaded filename"
            )

        received_name = recv_exact(
            file_socket,
            received_name_length
        ).decode(
            "utf-8",
            errors="replace"
        )

        received_name = (
            clean_local_filename(
                received_name
            )
        )

        file_size = struct.unpack(
            "!Q",
            recv_exact(
                file_socket,
                8
            )
        )[0]

        if file_size > MAX_FILE_SIZE:
            raise ValueError(
                "Downloaded file exceeds "
                "the 100 MB limit"
            )

        output_path = os.path.join(
            DOWNLOAD_DIR,
            received_name
        )

        temporary_path = (
            output_path
            + ".part"
        )

        remaining = file_size
        bytes_received = 0

        with open(
            temporary_path,
            "wb"
        ) as output_file:
            while remaining > 0:
                chunk = file_socket.recv(
                    min(
                        FILE_BUFFER_SIZE,
                        remaining
                    )
                )

                if not chunk:
                    raise ConnectionError(
                        "Download was interrupted"
                    )

                output_file.write(
                    chunk
                )

                bytes_received += len(
                    chunk
                )

                remaining -= len(
                    chunk
                )

                if file_size > 0:
                    percentage = int(
                        bytes_received
                        * 100
                        / file_size
                    )

                    file_status = (
                        f"Downloading "
                        f"{received_name}: "
                        f"{percentage}%"
                    )

        os.replace(
            temporary_path,
            output_path
        )

        file_status = (
            "Downloaded: "
            + received_name
        )

        add_system_message(
            "Downloaded "
            + received_name
        )

    except Exception as error:
        file_status = (
            "Download failed: "
            + str(error)
        )

        if output_path:
            temporary_path = (
                output_path
                + ".part"
            )

            if os.path.isfile(
                temporary_path
            ):
                try:
                    os.remove(
                        temporary_path
                    )
                except OSError:
                    pass

    finally:
        if file_socket is not None:
            try:
                file_socket.close()
            except OSError:
                pass

        set_file_operation_running(
            False
        )


def download_file(filename):
    global file_status

    if is_file_operation_running():
        file_status = (
            "Another file operation is running."
        )

        return

    threading.Thread(
        target=download_file_worker,
        args=(
            filename,
        ),
        daemon=True,
        name="FileDownload"
    ).start()


# ============================================================
# FILE SIZE FORMATTING
# ============================================================

def format_file_size(byte_count):
    size = float(
        byte_count
    )

    if size < 1024:
        return f"{int(size)} B"

    size /= 1024

    if size < 1024:
        return f"{size:.1f} KB"

    size /= 1024

    if size < 1024:
        return f"{size:.1f} MB"

    size /= 1024

    return f"{size:.1f} GB"


# ============================================================
# DRAW FILE BROWSER
# ============================================================

def draw_file_browser():
    screen.fill(
        theme["bg"]
    )

    title_surface = large_font.render(
        "Server Shared Files",
        True,
        theme["text"]
    )

    screen.blit(
        title_surface,
        (
            30,
            22
        )
    )

    # There is intentionally no button for opening or browsing
    # the client's local downloads directory.

    refresh_button = pygame.Rect(
        WIDTH - 465,
        20,
        150,
        35
    )

    upload_button = pygame.Rect(
        WIDTH - 300,
        20,
        155,
        35
    )

    back_button = pygame.Rect(
        WIDTH - 130,
        20,
        100,
        35
    )

    operation_running = (
        is_file_operation_running()
    )

    draw_button(
        refresh_button,
        "REFRESH",
        disabled=operation_running
    )

    draw_button(
        upload_button,
        "UPLOAD",
        theme["accent"],
        disabled=operation_running
    )

    draw_button(
        back_button,
        "BACK"
    )

    status_color = (
        theme["accent"]
        if operation_running
        else theme["muted"]
    )

    status_surface = small_font.render(
        file_status,
        True,
        status_color
    )

    screen.blit(
        status_surface,
        (
            30,
            65
        )
    )

    pygame.draw.line(
        screen,
        theme["border"],
        (
            30,
            92
        ),
        (
            WIDTH - 30,
            92
        ),
        1
    )

    screen.blit(
        small_font.render(
            "FILE NAME",
            True,
            theme["muted"]
        ),
        (
            45,
            108
        )
    )

    screen.blit(
        small_font.render(
            "SIZE",
            True,
            theme["muted"]
        ),
        (
            WIDTH - 260,
            108
        )
    )

    screen.blit(
        small_font.render(
            "ACTION",
            True,
            theme["muted"]
        ),
        (
            WIDTH - 145,
            108
        )
    )

    with server_files_lock:
        files = list(
            server_files
        )

    row_height = 42
    start_y = 135

    visible_count = max(
        1,
        (
            HEIGHT
            - start_y
            - 20
        )
        // row_height
    )

    visible_files = files[
        file_scroll:
        file_scroll
        + visible_count
    ]

    for offset, file_information \
            in enumerate(visible_files):

        row_y = (
            start_y
            + offset
            * row_height
        )

        row_rect = pygame.Rect(
            30,
            row_y,
            WIDTH - 60,
            row_height - 4
        )

        pygame.draw.rect(
            screen,
            theme["panel"],
            row_rect
        )

        pygame.draw.rect(
            screen,
            theme["border"],
            row_rect,
            1
        )

        filename = str(
            file_information.get(
                "name",
                "Unknown"
            )
        )

        try:
            file_size = int(
                file_information.get(
                    "size",
                    0
                )
            )

        except (
            TypeError,
            ValueError
        ):
            file_size = 0

        display_name = filename

        while (
            display_name
            and small_font.size(
                display_name
            )[0]
            > WIDTH - 390
        ):
            display_name = (
                display_name[:-1]
            )

        if display_name != filename:
            if len(display_name) > 3:
                display_name = (
                    display_name[:-3]
                    + "..."
                )

        name_surface = small_font.render(
            display_name,
            True,
            theme["text"]
        )

        screen.blit(
            name_surface,
            (
                row_rect.x + 14,
                row_rect.y + 11
            )
        )

        size_surface = small_font.render(
            format_file_size(
                file_size
            ),
            True,
            theme["muted"]
        )

        screen.blit(
            size_surface,
            (
                WIDTH - 260,
                row_rect.y + 11
            )
        )

        download_button = pygame.Rect(
            WIDTH - 145,
            row_rect.y + 5,
            100,
            28
        )

        draw_button(
            download_button,
            "DOWNLOAD",
            theme["accent"],
            disabled=operation_running
        )

    if not files:
        empty_surface = font.render(
            "No shared files.",
            True,
            theme["muted"]
        )

        screen.blit(
            empty_surface,
            empty_surface.get_rect(
                center=(
                    WIDTH // 2,
                    HEIGHT // 2
                )
            )
        )


# ============================================================
# STARTUP DISPLAY
# ============================================================

screen.fill(
    theme["bg"]
)

startup_surface = large_font.render(
    "Starting CamBunches...",
    True,
    theme["text"]
)

screen.blit(
    startup_surface,
    startup_surface.get_rect(
        center=(
            WIDTH // 2,
            HEIGHT // 2
        )
    )
)

pygame.display.flip()
pygame.event.pump()


# ============================================================
# OPEN CAMERA
# ============================================================

camera = open_camera()


# ============================================================
# CONNECT TO CHAT/CAMERA SERVER
# ============================================================

chat_socket = socket.socket(
    socket.AF_INET,
    socket.SOCK_STREAM
)

chat_socket.setsockopt(
    socket.IPPROTO_TCP,
    socket.TCP_NODELAY,
    1
)

chat_socket.settimeout(
    4.0
)

try:
    print(
        f"Connecting chat/video to "
        f"{SERVER_IP}:{CHAT_PORT}..."
    )

    chat_socket.connect(
        (
            SERVER_IP,
            CHAT_PORT
        )
    )

    chat_socket.settimeout(
        None
    )

    connected = True

    print(
        "Chat/video connected."
    )

except (
    socket.timeout,
    OSError
) as error:
    connected = False

    print(
        f"Chat connection failed: {error}"
    )

    add_system_message(
        "Chat connection failed: "
        + str(error)
    )


# ============================================================
# START CHAT RECEIVER
# ============================================================

if connected:
    receiver_thread = threading.Thread(
        target=network_loop,
        daemon=True,
        name="NetworkReceiver"
    )

    receiver_thread.start()


# ============================================================
# MAIN LOOP
# ============================================================

while running:
    for event in pygame.event.get():

        # ----------------------------------------------------
        # WINDOW CLOSE
        # ----------------------------------------------------

        if event.type == pygame.QUIT:
            running = False

        # ----------------------------------------------------
        # KEYBOARD
        # ----------------------------------------------------

        elif event.type == pygame.KEYDOWN:

            if event.key == pygame.K_ESCAPE:
                if mode == "files":
                    mode = "chat"

                else:
                    running = False

            elif (
                mode == "chat"
                and event.key == pygame.K_RETURN
            ):
                message = current_input.strip()

                if message:
                    if connected:
                        send_text(
                            message
                        )

                    else:
                        add_system_message(
                            "Cannot send while disconnected"
                        )

                    current_input = ""

            elif (
                mode == "chat"
                and event.key == pygame.K_BACKSPACE
            ):
                current_input = (
                    current_input[:-1]
                )

            elif mode == "chat":
                if (
                    event.unicode
                    and event.unicode.isprintable()
                    and len(current_input)
                    < MAX_MESSAGE_LENGTH
                ):
                    current_input += (
                        event.unicode
                    )

            elif mode == "files":
                with server_files_lock:
                    file_count = len(
                        server_files
                    )

                visible_count = max(
                    1,
                    (
                        HEIGHT
                        - 135
                        - 20
                    )
                    // 42
                )

                maximum_scroll = max(
                    0,
                    file_count
                    - visible_count
                )

                if event.key == pygame.K_UP:
                    file_scroll = max(
                        0,
                        file_scroll - 1
                    )

                elif event.key == pygame.K_DOWN:
                    file_scroll = min(
                        maximum_scroll,
                        file_scroll + 1
                    )

                elif event.key == pygame.K_PAGEUP:
                    file_scroll = max(
                        0,
                        file_scroll
                        - visible_count
                    )

                elif event.key == pygame.K_PAGEDOWN:
                    file_scroll = min(
                        maximum_scroll,
                        file_scroll
                        + visible_count
                    )

        # ----------------------------------------------------
        # FILE LIST MOUSE WHEEL
        # ----------------------------------------------------

        elif (
            event.type == pygame.MOUSEWHEEL
            and mode == "files"
        ):
            with server_files_lock:
                file_count = len(
                    server_files
                )

            visible_count = max(
                1,
                (
                    HEIGHT
                    - 135
                    - 20
                )
                // 42
            )

            maximum_scroll = max(
                0,
                file_count
                - visible_count
            )

            file_scroll -= event.y

            file_scroll = max(
                0,
                min(
                    maximum_scroll,
                    file_scroll
                )
            )

        # ----------------------------------------------------
        # LEFT MOUSE BUTTON
        # ----------------------------------------------------

        elif (
            event.type == pygame.MOUSEBUTTONDOWN
            and event.button == 1
        ):

            # =================================================
            # CHAT-SCREEN BUTTONS
            # =================================================

            if mode == "chat":
                panel_x = (
                    CAMERA_AREA_WIDTH
                )

                server_files_rect = (
                    pygame.Rect(
                        panel_x + 10,
                        62,
                        155,
                        32
                    )
                )

                upload_rect = pygame.Rect(
                    panel_x + 175,
                    62,
                    165,
                    32
                )

                if server_files_rect.collidepoint(
                    event.pos
                ):
                    mode = "files"

                    if not server_files:
                        refresh_file_list()

                elif upload_rect.collidepoint(
                    event.pos
                ):
                    start_upload()

            # =================================================
            # FILE-SCREEN BUTTONS
            # =================================================

            elif mode == "files":
                refresh_rect = pygame.Rect(
                    WIDTH - 465,
                    20,
                    150,
                    35
                )

                upload_rect = pygame.Rect(
                    WIDTH - 300,
                    20,
                    155,
                    35
                )

                back_rect = pygame.Rect(
                    WIDTH - 130,
                    20,
                    100,
                    35
                )

                if back_rect.collidepoint(
                    event.pos
                ):
                    mode = "chat"

                elif (
                    refresh_rect.collidepoint(
                        event.pos
                    )
                    and not
                    is_file_operation_running()
                ):
                    refresh_file_list()

                elif (
                    upload_rect.collidepoint(
                        event.pos
                    )
                    and not
                    is_file_operation_running()
                ):
                    start_upload()

                elif not is_file_operation_running():
                    with server_files_lock:
                        files_snapshot = list(
                            server_files
                        )

                    row_height = 42
                    start_y = 135

                    visible_count = max(
                        1,
                        (
                            HEIGHT
                            - start_y
                            - 20
                        )
                        // row_height
                    )

                    visible_files = (
                        files_snapshot[
                            file_scroll:
                            file_scroll
                            + visible_count
                        ]
                    )

                    for offset, information \
                            in enumerate(
                                visible_files
                            ):

                        row_y = (
                            start_y
                            + offset
                            * row_height
                        )

                        download_rect = (
                            pygame.Rect(
                                WIDTH - 145,
                                row_y + 5,
                                100,
                                28
                            )
                        )

                        if download_rect.collidepoint(
                            event.pos
                        ):
                            filename = str(
                                information.get(
                                    "name",
                                    ""
                                )
                            )

                            if filename:
                                download_file(
                                    filename
                                )

                            break

    # ========================================================
    # READ LOCAL CAMERA
    # ========================================================

    local_frame = None

    if camera is not None:
        success, captured_frame = (
            camera.read()
        )

        if (
            success
            and captured_frame is not None
            and captured_frame.size > 0
        ):
            local_frame = (
                captured_frame
            )

    # ========================================================
    # SEND LOCAL VIDEO
    # ========================================================

    current_time = time.monotonic()

    if (
        connected
        and local_frame is not None
        and current_time
        - last_video_send
        >= 1.0 / VIDEO_FPS
    ):
        send_video(
            local_frame
        )

        last_video_send = (
            current_time
        )

    # ========================================================
    # DRAW
    # ========================================================

    screen.fill(
        theme["bg"]
    )

    if mode == "chat":
        draw_camera_grid(
            local_frame
        )

        draw_chat()

    elif mode == "files":
        draw_file_browser()

    pygame.display.flip()

    clock.tick(
        30
    )


# ============================================================
# SHUTDOWN
# ============================================================

connected = False

if camera is not None:
    camera.release()

if chat_socket is not None:
    try:
        chat_socket.shutdown(
            socket.SHUT_RDWR
        )
    except OSError:
        pass

    try:
        chat_socket.close()
    except OSError:
        pass

pygame.quit()
