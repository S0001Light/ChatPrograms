# Secure Chat Only

A chat-only edition with TLS 1.2+, automatic self-signed certificate generation, SHA-256 certificate pinning, bcrypt account passwords, user icons on both sides, online-user icons, keepalive, heartbeat, and disconnect support.

## Setup

```bat
py -m pip install -r requirements.txt
py setup_server.py --admin admin --password "StrongPassword"
py server.py
```

Add another allowed user:

```bat
py manage_user.py shawn --password "UserPassword" --role client
```

Start a client with `py client.py`. The first connection pins the server certificate fingerprint. A later unexpected certificate change is blocked. Delete `.secure_chat_pins.json` from the user's home directory only when the server certificate was intentionally regenerated.

Default chat port: `5050`. The server automatically creates `server_cert.pem` and `server_key.pem`. Never distribute the private key.
