#!/usr/bin/env python3
import argparse,bcrypt,json
from pathlib import Path
def load(p,d): return json.loads(p.read_text()) if p.exists() else d
p=argparse.ArgumentParser(); sub=p.add_subparsers(dest='cmd',required=True)
a=sub.add_parser('add');a.add_argument('username');a.add_argument('--password',required=True);a.add_argument('--role',choices=['client','admin'],default='client')
for cmd in ('remove','blacklist','unblacklist'): q=sub.add_parser(cmd);q.add_argument('username')
sub.add_parser('list'); p.add_argument('--whitelist',default='whitelist.json');p.add_argument('--blacklist-file',default='blacklist.json');x=p.parse_args();wp=Path(x.whitelist);bp=Path(x.blacklist_file);w=load(wp,{'users':[]});b=load(bp,{'users':[]})
if x.cmd=='add':
 w['users']=[u for u in w['users'] if u['username'].casefold()!=x.username.casefold()];w['users'].append({'username':x.username,'password_hash':bcrypt.hashpw(x.password.encode(),bcrypt.gensalt()).decode(),'role':x.role,'enabled':True})
elif x.cmd=='remove':w['users']=[u for u in w['users'] if u['username'].casefold()!=x.username.casefold()]
elif x.cmd=='blacklist':
 if x.username.casefold() not in [n.casefold() for n in b['users']]:b['users'].append(x.username)
elif x.cmd=='unblacklist':b['users']=[n for n in b['users'] if n.casefold()!=x.username.casefold()]
elif x.cmd=='list':
 print('WHITELIST');[print(u['username'],u['role'],'enabled='+str(u.get('enabled',True))) for u in w['users']];print('BLACKLIST');[print(n) for n in b['users']]
wp.write_text(json.dumps(w,indent=2));bp.write_text(json.dumps(b,indent=2))
