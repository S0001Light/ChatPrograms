#!/usr/bin/env python3
import argparse, json, logging, socket, ssl, threading
from pathlib import Path
import bcrypt
from pyftpdlib.authorizers import DummyAuthorizer, AuthenticationFailed
from pyftpdlib.handlers import TLS_FTPHandler
from pyftpdlib.servers import ThreadedFTPServer

MAX_LINE = 512 * 1024

def load_json(path, default):
    p=Path(path)
    if not p.exists(): return default
    return json.loads(p.read_text(encoding='utf-8'))

def load_access(white_path, black_path):
    white=load_json(white_path, {'users':[]})
    black=load_json(black_path, {'users':[]})
    blocked=set(str(x).strip().casefold() for x in black.get('users',[]) if str(x).strip())
    users={}
    for u in white.get('users',[]):
        name=str(u.get('username','')).strip()
        if not name or name.casefold() in blocked or not u.get('enabled',True): continue
        if u.get('role') not in ('admin','client'): raise ValueError('Invalid role: '+name)
        users[name]=u
    if not any(u['role']=='admin' for u in users.values()):
        raise ValueError('At least one enabled, non-blacklisted admin is required')
    return users, blocked

def verify(user,password):
    try: return bcrypt.checkpw(password.encode('utf-8'),user['password_hash'].encode('ascii'))
    except Exception: return False

class HashAuthorizer(DummyAuthorizer):
    def validate_authentication(self,username,password,handler):
        if username not in self.user_table: raise AuthenticationFailed('Authentication failed')
        if not bcrypt.checkpw(password.encode('utf-8'),self.user_table[username]['pwd'].encode('ascii')):
            raise AuthenticationFailed('Authentication failed')

class ChatServer(object):
    def __init__(self,host,port,users,context):
        self.host,self.port,self.users,self.context=host,port,users,context
        self.lock=threading.RLock(); self.clients={}
    @staticmethod
    def send(w,p):
        w.write(json.dumps(p,ensure_ascii=False)+'\n'); w.flush()
    def roster(self):
        return [{'username':v[0],'icon':v[2]} for v in self.clients.values()]
    def drop(self,s):
        item=self.clients.pop(s,None)
        try: s.close()
        except Exception: pass
        return item[0] if item else None
    def broadcast(self,p):
        dead=[]
        with self.lock:
            for s,v in list(self.clients.items()):
                try: self.send(v[1],p)
                except Exception: dead.append(s)
            for s in dead: self.drop(s)
    def handle(self,sock,addr):
        name=None
        try:
            r=sock.makefile('r',encoding='utf-8',newline='\n'); w=sock.makefile('w',encoding='utf-8',newline='\n')
            line=r.readline(MAX_LINE)
            if not line: return
            hello=json.loads(line); name=str(hello.get('username','')).strip(); user=self.users.get(name)
            if not user or not verify(user,str(hello.get('password',''))):
                self.send(w,{'type':'error','text':'Not whitelisted, blacklisted, disabled, or invalid password.'}); return
            icon=str(hello.get('icon',''))
            if len(icon)>350000: icon=''
            with self.lock:
                if any(v[0].casefold()==name.casefold() for v in self.clients.values()):
                    self.send(w,{'type':'error','text':'That user is already connected.'}); return
                self.clients[sock]=(name,w,icon)
            self.send(w,{'type':'welcome','text':'Connected as '+name+'.','role':user['role']})
            self.broadcast({'type':'roster','users':self.roster()}); self.broadcast({'type':'system','text':name+' joined.'})
            for line in r:
                if len(line)>MAX_LINE: break
                msg=json.loads(line)
                if msg.get('type')=='message':
                    text=str(msg.get('text','')).strip()[:2000]
                    if text: self.broadcast({'type':'message','username':name,'text':text,'icon':icon})
        except Exception as e: logging.debug('chat ended: %s',e)
        finally:
            with self.lock: left=self.drop(sock)
            if left:
                self.broadcast({'type':'system','text':left+' left.'}); self.broadcast({'type':'roster','users':self.roster()})
    def start(self):
        ls=socket.socket(); ls.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1); ls.bind((self.host,self.port)); ls.listen(50)
        print('TLS chat listening on %s:%d'%(self.host,self.port))
        while True:
            raw,addr=ls.accept()
            try: sock=self.context.wrap_socket(raw,server_side=True)
            except Exception: raw.close(); continue
            threading.Thread(target=self.handle,args=(sock,addr),daemon=True).start()

def build_ftp(a,users):
    root=Path(a.root).resolve(); uploads=root/'uploads'; uploads.mkdir(parents=True,exist_ok=True)
    auth=HashAuthorizer()
    for name,u in users.items():
        perms='elradfmwMT' if u['role']=='admin' else 'elr'
        auth.add_user(name,u['password_hash'],str(root),perm=perms)
        if u['role']=='client': auth.override_perm(name,str(uploads),perm='elrw',recursive=False)
    class Handler(TLS_FTPHandler): pass
    Handler.authorizer=auth; Handler.certfile=a.cert; Handler.keyfile=a.key
    Handler.tls_control_required=True; Handler.tls_data_required=True
    Handler.passive_ports=range(a.passive_start,a.passive_end+1)
    return ThreadedFTPServer((a.host,a.ftps_port),Handler)

def main():
    p=argparse.ArgumentParser(); p.add_argument('--host',default='0.0.0.0'); p.add_argument('--ftps-port',type=int,default=2121); p.add_argument('--chat-port',type=int,default=5050)
    p.add_argument('--root',default='shared_files'); p.add_argument('--whitelist',default='whitelist.json'); p.add_argument('--blacklist',default='blacklist.json'); p.add_argument('--cert',default='server_cert.pem'); p.add_argument('--key',default='server_key.pem'); p.add_argument('--passive-start',type=int,default=50000); p.add_argument('--passive-end',type=int,default=50049); p.add_argument('--legacy-tls',action='store_true')
    a=p.parse_args(); users,_=load_access(a.whitelist,a.blacklist)
    ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); ctx.minimum_version=ssl.TLSVersion.TLSv1 if a.legacy_tls else ssl.TLSVersion.TLSv1_2; ctx.load_cert_chain(a.cert,a.key)
    ftp=build_ftp(a,users); threading.Thread(target=ChatServer(a.host,a.chat_port,users,ctx).start,daemon=True).start()
    print('FTPS server listening on %s:%d'%(a.host,a.ftps_port)); ftp.serve_forever()
if __name__=='__main__': main()
