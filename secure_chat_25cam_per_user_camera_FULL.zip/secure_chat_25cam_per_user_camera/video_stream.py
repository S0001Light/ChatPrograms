from __future__ import annotations
import json, socket, ssl, struct, threading, time
import cv2, numpy as np
from PIL import Image
class MutedVideoClient:
 def __init__(self,app):self.app=app;self.sock=None;self.running=False;self.cap=None;self.slots={};self.camera_enabled=False;self.sender_thread=None;self.receiver_thread=None
 @staticmethod
 def recv_exact(sock,n):
  b=bytearray()
  while len(b)<n:
   c=sock.recv(n-len(b))
   if not c:raise ConnectionError
   b.extend(c)
  return bytes(b)
 def start(self):
  if self.running:return
  try:
   raw=socket.create_connection((self.app.host.get().strip(),5051),timeout=15);sock=self.app.context().wrap_socket(raw,server_hostname=self.app.host.get().strip());self.app.pin(sock);sock.settimeout(None)
   hello=json.dumps({'username':self.app.user.get().strip(),'password':self.app.password.get()}).encode();sock.sendall(struct.pack('!I',len(hello))+hello);self.sock=sock;self.running=True
   self.receiver_thread=threading.Thread(target=self.recv_loop,daemon=True);self.receiver_thread.start()
   if self.camera_enabled:self._open_camera()
  except Exception as e:self.app.events.put(('video_error',str(e)))

 def _open_camera(self):
  if not self.running or self.cap is not None:return
  cap=cv2.VideoCapture(0);cap.set(cv2.CAP_PROP_FRAME_WIDTH,320);cap.set(cv2.CAP_PROP_FRAME_HEIGHT,240)
  if not cap.isOpened():
   cap.release();self.app.events.put(('video_error','Unable to open webcam'));return
  self.cap=cap;self.camera_enabled=True;self.app.after(0,self.app.update_camera_button)
  self.sender_thread=threading.Thread(target=self.send_loop,daemon=True);self.sender_thread.start()
 def set_camera(self,enabled):
  self.camera_enabled=bool(enabled)
  if self.camera_enabled:
   self._open_camera()
  else:
   cap,self.cap=self.cap,None
   if cap:
    try:cap.release()
    except:pass
   self.app.after(0,self.app.update_camera_button)
 def toggle_camera(self):self.set_camera(not self.camera_enabled)

 def send_loop(self):
  while self.running and self.camera_enabled and self.cap and self.cap.isOpened():
   ok,frame=self.cap.read()
   if not ok:time.sleep(.2);continue
   frame=cv2.resize(frame,(320,240));ok,buf=cv2.imencode('.jpg',frame,[cv2.IMWRITE_JPEG_QUALITY,55])
   if ok:
    data=buf.tobytes()
    try:self.sock.sendall(struct.pack('!I',len(data))+data)
    except Exception:break
   time.sleep(.10)
  cap,self.cap=self.cap,None
  if cap:
   try:cap.release()
   except:pass
  self.app.after(0,self.app.update_camera_button)
 def recv_loop(self):
  try:
   while self.running:
    n=struct.unpack('!I',self.recv_exact(self.sock,4))[0];packet=self.recv_exact(self.sock,n);meta,frame=packet.split(b'\n',1);name=json.loads(meta.decode())['username'];arr=np.frombuffer(frame,np.uint8);img=cv2.imdecode(arr,cv2.IMREAD_COLOR)
    if img is not None:self.app.after(0,self.show,name,img)
  except Exception:pass
  self.stop()
 def show(self,name,bgr):
  if name not in self.slots:
   used=set(self.slots.values());self.slots[name]=next((i for i in range(25) if i not in used),None)
  i=self.slots.get(name)
  if i is None:return
  rgb=cv2.cvtColor(bgr,cv2.COLOR_BGR2RGB);self.app.video_grid.tiles[i].set_frame(Image.fromarray(rgb),name+' [muted]')
 def stop(self):
  self.running=False;self.camera_enabled=False
  if self.cap:
   try:self.cap.release()
   except:pass
   self.cap=None
  if self.sock:
   try:self.sock.close()
   except:pass
   self.sock=None
