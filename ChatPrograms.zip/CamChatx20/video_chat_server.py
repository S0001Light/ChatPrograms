import json
import queue
import socket
import threading


# ============================================================
# CONFIGURATION
# ============================================================

HOST = "192.168.1.72"
PORT = 5000

MAX_CLIENTS = 20

MAX_PACKET_SIZE = 2_000_000
MAX_USERNAME_LENGTH = 24
MAX_CHAT_LENGTH = 500

OUTBOX_SIZE = 128


# ============================================================
# GLOBAL STATE
# ============================================================

clients = {}
clients_lock = threading.Lock()

next_client_id = 1


# ============================================================
# PACKET HELPERS
# ============================================================

def recv_exact(sock, size):
    """
    Receive exactly 'size' bytes from a TCP socket.
    """

    data = bytearray()

    while len(data) < size:
        chunk = sock.recv(size - len(data))

        if not chunk:
            raise ConnectionError("Socket was closed")

        data.extend(chunk)

    return bytes(data)


def pack_packet(packet_type, payload=b""):
    """
    Packet format:

        1 byte  packet type
        4 bytes payload size
        N bytes payload
    """

    return (
        packet_type
        + len(payload).to_bytes(4, "big")
        + payload
    )


# ============================================================
# CLIENT CONNECTION
# ============================================================

class ClientConnection:
    def __init__(self, client_id, client_socket, address):
        self.id = client_id
        self.socket = client_socket
        self.address = address

        self.username = f"User {client_id}"
        self.icon_color = [200, 200, 200]

        self.alive = True

        # Each client has its own outgoing packet queue.
        self.outbox = queue.Queue(
            maxsize=OUTBOX_SIZE
        )

    def enqueue(self, packet, is_video=False):
        """
        Add a packet to this client's sending queue.

        Video packets can be dropped if the client is too slow.
        Chat and user-information packets are preserved whenever
        possible.
        """

        if not self.alive:
            return

        try:
            self.outbox.put_nowait(packet)
            return

        except queue.Full:
            pass

        if is_video:
            # Dropping a video frame is better than building
            # several seconds of video delay.
            return

        # For an important packet, try removing an older packet.
        try:
            self.outbox.get_nowait()
        except queue.Empty:
            pass

        try:
            self.outbox.put_nowait(packet)
        except queue.Full:
            pass

    def writer_loop(self):
        """
        Dedicated sending thread for this client.
        """

        try:
            while self.alive:
                packet = self.outbox.get()

                if packet is None:
                    break

                self.socket.sendall(packet)

        except (
            OSError,
            ConnectionError,
            ConnectionResetError,
            BrokenPipeError
        ):
            pass

        finally:
            disconnect_client(self.id)


# ============================================================
# BROADCAST HELPERS
# ============================================================

def broadcast_raw(
    packet,
    exclude_client_id=None,
    is_video=False
):
    """
    Broadcast an already packed packet.
    """

    with clients_lock:
        targets = list(clients.values())

    for client in targets:
        if (
            exclude_client_id is not None
            and client.id == exclude_client_id
        ):
            continue

        client.enqueue(
            packet,
            is_video=is_video
        )


def broadcast_from_sender(
    packet_type,
    sender_id,
    payload,
    exclude_client_id=None,
    is_video=False
):
    """
    Server-to-client sender packet payload:

        4 bytes sender/client ID
        N bytes original payload
    """

    full_payload = (
        sender_id.to_bytes(4, "big")
        + payload
    )

    packet = pack_packet(
        packet_type,
        full_payload
    )

    broadcast_raw(
        packet,
        exclude_client_id=exclude_client_id,
        is_video=is_video
    )


# ============================================================
# USER INFORMATION
# ============================================================

def clean_username(value, fallback):
    value = str(value).strip()

    if not value:
        return fallback

    return value[:MAX_USERNAME_LENGTH]


def clean_icon_color(value):
    if not isinstance(value, (list, tuple)):
        return [200, 200, 200]

    if len(value) < 3:
        return [200, 200, 200]

    cleaned = []

    for component in value[:3]:
        try:
            component = int(component)
        except (TypeError, ValueError):
            component = 200

        component = max(
            0,
            min(255, component)
        )

        cleaned.append(component)

    return cleaned


def make_roster_payload(client):
    info = {
        "id": client.id,
        "username": client.username,
        "icon_color": client.icon_color
    }

    return json.dumps(info).encode("utf-8")


def send_roster(destination):
    """
    Send all connected users to a newly connected client.
    """

    with clients_lock:
        roster = list(clients.values())

    for client in roster:
        destination.enqueue(
            pack_packet(
                b"J",
                make_roster_payload(client)
            )
        )


def broadcast_userinfo(client):
    info = {
        "username": client.username,
        "icon_color": client.icon_color
    }

    payload = json.dumps(info).encode("utf-8")

    broadcast_from_sender(
        b"U",
        client.id,
        payload
    )


# ============================================================
# DISCONNECT
# ============================================================

def disconnect_client(client_id):
    with clients_lock:
        client = clients.pop(
            client_id,
            None
        )

    if client is None:
        return

    client.alive = False

    try:
        client.outbox.put_nowait(None)
    except queue.Full:
        pass

    try:
        client.socket.shutdown(
            socket.SHUT_RDWR
        )
    except OSError:
        pass

    try:
        client.socket.close()
    except OSError:
        pass

    # Tell remaining clients to remove this client.
    leave_packet = pack_packet(
        b"L",
        client_id.to_bytes(4, "big")
    )

    broadcast_raw(leave_packet)

    print(
        f"Disconnected client {client.id}: "
        f"{client.username} from {client.address}"
    )


# ============================================================
# CLIENT READER LOOP
# ============================================================

def handle_client(client):
    try:
        # Assign a unique ID.
        client.enqueue(
            pack_packet(
                b"I",
                client.id.to_bytes(4, "big")
            )
        )

        # Send currently connected users.
        send_roster(client)

        # Announce this user.
        broadcast_userinfo(client)

        while client.alive:
            header = recv_exact(
                client.socket,
                5
            )

            packet_type = header[:1]

            payload_length = int.from_bytes(
                header[1:5],
                "big"
            )

            if payload_length > MAX_PACKET_SIZE:
                raise ValueError(
                    f"Packet too large: {payload_length}"
                )

            payload = recv_exact(
                client.socket,
                payload_length
            )

            # ------------------------------------------------
            # USER INFORMATION
            # ------------------------------------------------

            if packet_type == b"U":
                info = json.loads(
                    payload.decode("utf-8")
                )

                client.username = clean_username(
                    info.get("username"),
                    client.username
                )

                client.icon_color = clean_icon_color(
                    info.get("icon_color")
                )

                broadcast_userinfo(client)

                print(
                    f"User {client.id} updated: "
                    f"{client.username}"
                )

            # ------------------------------------------------
            # TEXT CHAT
            # ------------------------------------------------

            elif packet_type == b"T":
                message = payload.decode(
                    "utf-8",
                    errors="replace"
                ).strip()

                if not message:
                    continue

                message = message[:MAX_CHAT_LENGTH]

                broadcast_from_sender(
                    b"T",
                    client.id,
                    message.encode("utf-8")
                )

                print(
                    f"[{client.id}] "
                    f"{client.username}: {message}"
                )

            # ------------------------------------------------
            # VIDEO
            # ------------------------------------------------

            elif packet_type == b"V":
                # The sender already displays its local camera,
                # so do not send its frame back to itself.
                broadcast_from_sender(
                    b"V",
                    client.id,
                    payload,
                    exclude_client_id=client.id,
                    is_video=True
                )

            else:
                print(
                    f"Unknown packet type from "
                    f"client {client.id}: {packet_type!r}"
                )

    except (
        OSError,
        ConnectionError,
        ConnectionResetError,
        BrokenPipeError,
        ValueError,
        json.JSONDecodeError
    ) as error:
        print(
            f"Client {client.id} connection ended: "
            f"{error}"
        )

    except Exception as error:
        print(
            f"Unexpected client {client.id} error: "
            f"{error}"
        )

    finally:
        disconnect_client(client.id)


# ============================================================
# MAIN SERVER
# ============================================================

def main():
    global next_client_id

    server_socket = socket.socket(
        socket.AF_INET,
        socket.SOCK_STREAM
    )

    server_socket.setsockopt(
        socket.SOL_SOCKET,
        socket.SO_REUSEADDR,
        1
    )

    server_socket.bind(
        (HOST, PORT)
    )

    server_socket.listen(
        MAX_CLIENTS
    )

    print("=" * 60)
    print("CamBunches Camera Server")
    print(f"Listening on {HOST}:{PORT}")
    print(f"Maximum clients: {MAX_CLIENTS}")
    print("=" * 60)

    try:
        while True:
            client_socket, address = (
                server_socket.accept()
            )

            client_socket.setsockopt(
                socket.IPPROTO_TCP,
                socket.TCP_NODELAY,
                1
            )

            with clients_lock:
                if len(clients) >= MAX_CLIENTS:
                    try:
                        client_socket.sendall(
                            pack_packet(
                                b"E",
                                b"Server is full"
                            )
                        )
                    except OSError:
                        pass

                    client_socket.close()

                    print(
                        f"Rejected {address}: "
                        f"server is full"
                    )

                    continue

                client_id = next_client_id
                next_client_id += 1

                client = ClientConnection(
                    client_id,
                    client_socket,
                    address
                )

                clients[client_id] = client

            writer_thread = threading.Thread(
                target=client.writer_loop,
                daemon=True,
                name=f"Writer-{client_id}"
            )

            reader_thread = threading.Thread(
                target=handle_client,
                args=(client,),
                daemon=True,
                name=f"Reader-{client_id}"
            )

            writer_thread.start()
            reader_thread.start()

            print(
                f"Connected client {client_id} "
                f"from {address}"
            )

    except KeyboardInterrupt:
        print("\nStopping server...")

    finally:
        with clients_lock:
            client_ids = list(
                clients.keys()
            )

        for client_id in client_ids:
            disconnect_client(client_id)

        try:
            server_socket.close()
        except OSError:
            pass

        print("Server stopped.")


if __name__ == "__main__":
    main()
