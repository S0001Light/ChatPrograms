Plain TCP message build

Server:
  py server_message_tcp.py --host 192.168.1.126

Client:
  py client_message_tcp.py

Changes:
- TLS and certificates removed.
- Uses length-prefixed JSON control messages and binary chunk messages over plain TCP.
- UDP broadcast discovery remains available.
- Message Ping verifies TCP plus framed ping/pong.
- Existing bcrypt username/password login remains.

Security: traffic and passwords are not encrypted. Use only on a trusted private LAN.
