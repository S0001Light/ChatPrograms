SECURE FTPS + TLS CHAT

Recommended design: run server.py on a currently supported OS/Python. Run client.py on client PCs.

Setup:
1. python -m pip install -r requirements-server.txt
2. python make_cert.py --hostname YOUR_SERVER_NAME --password CHANGE_ME
3. python manage_users.py add alice --password SECRET --role client
4. Optional: python manage_users.py blacklist alice
5. python server.py
6. Copy client.py and server_cert.pem to each client folder. Install Pillow only if icons are wanted.

Compatibility reality:
- Windows 10/11: use a current supported Python.
- Windows 7: use Python 3.8.x or a frozen executable built specifically for Windows 7.
- Windows Vista/XP/2000: the source syntax is intentionally old-friendly, but Python/OpenSSL/Pillow availability and TLS support depend on the exact legacy runtime. Do not expose these obsolete systems to the public Internet.
- --legacy-tls lowers the server TLS minimum and is intentionally opt-in. It may still fail if the server OpenSSL build disables old protocols. It is not recommended.

Whitelist wins only when the user is not also in blacklist.json. Blacklist matching is case-insensitive. Restart server.py after editing either JSON file.

LEGACY COMPATIBILITY MODE
- Client UI now has a Legacy compatibility checkbox.
- Legacy mode avoids MLSD and uses NLST/CWD/SIZE directory probing for older FTP stacks.
- If MLSD fails, client automatically switches to legacy listing mode.
- Server --legacy-tls lowers the chat TLS minimum where the installed OpenSSL permits it.
- This does NOT magically make current Python packages run on Windows 2000/XP/Vista. Use an OS-appropriate Python/runtime and test its SSL support.
- Keep certificate verification enabled whenever the legacy runtime can load the supplied server_cert.pem.

CHAT ICONS
- client.py, client_modern.py, and client_legacy.py now render the sender icon inline beside each chat message when Pillow is installed.
- The server already broadcasts the icon with each message and roster update.
