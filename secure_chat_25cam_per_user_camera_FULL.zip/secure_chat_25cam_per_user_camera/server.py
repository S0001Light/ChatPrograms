#!/usr/bin/env python3
from __future__ import annotations
import argparse, ipaddress, json, logging, socket, ssl, threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
import bcrypt
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

MAX_LINE=512*1024
MAX_ICON=350000

def ensure_certificate(cert_name,key_name):
    cert,key=Path(cert_name),Path(key_name)
    if cert.exists() and key.exists(): return
    if cert.exists()!=key.exists(): raise RuntimeError('Delete the remaining PEM file so the certificate pair can be regenerated.')
    hostname=socket.gethostname() or 'localhost'
    sans=[x509.DNSName(hostname),x509.DNSName('localhost'),x509.IPAddress(ipaddress.ip_address('127.0.0.1'))]
    try:
        for info in socket.getaddrinfo(hostname,None):
            try:
                item=x509.IPAddress(ipaddress.ip_address(info[4][0]))
                if item not in sans:sans.append(item)
            except ValueError:pass
    except OSError:pass
    private=rsa.generate_private_key(public_exponent=65537,key_size=3072)
    name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,hostname)])
    now=datetime.now(timezone.utc)
    crt=(x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(private.public_key())
         .serial_number(x509.random_serial_number()).not_valid_before(now-timedelta(minutes=5))
         .not_valid_after(now+timedelta(days=3650)).add_extension(x509.SubjectAlternativeName(sans),False)
         .sign(private,hashes.SHA256()))
    key.write_bytes(private.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.TraditionalOpenSSL,serialization.NoEncryption()))
    cert.write_bytes(crt.public_bytes(serialization.Encoding.PEM))
    print('Generated automatic TLS certificate:',cert)

def load_users(path):
    data=json.loads(Path(path).read_text(encoding='utf-8'))
    return {u['username']:u for u in data.get('users',[]) if u.get('enabled',True)}

def verify(user,password):
    try:return bcrypt.checkpw(password.encode(),user['password_hash'].encode())
    except Exception:return False

def configure_keepalive(sock):
    sock.setsockopt(socket.SOL_SOCKET,socket.SO_KEEPALIVE,1)
    if hasattr(socket,'SIO_KEEPALIVE_VALS'):
        try:sock.ioctl(socket.SIO_KEEPALIVE_VALS,(1,30000,10000))
        except OSError:pass
    for name,value in (('TCP_KEEPIDLE',30),('TCP_KEEPINTVL',10),('TCP_KEEPCNT',5)):
        if hasattr(socket,name):
            try:sock.setsockopt(socket.IPPROTO_TCP,getattr(socket,name),value)
            except OSError:pass

class ChatServer:
    def __init__(self,host,port,users,context):
        self.host,self.port,self.users,self.context=host,port,users,context
        self.lock=threading.RLock();self.clients={}
    @staticmethod
    def send(writer,obj):writer.write(json.dumps(obj,ensure_ascii=False)+'\n');writer.flush()
    def roster(self):return [{'username':n,'icon':icon,'role':role} for n,w,icon,role in self.clients.values()]
    def broadcast(self,obj):
        dead=[]
        with self.lock:
            for sock,(name,writer,icon,role) in list(self.clients.items()):
                try:self.send(writer,obj)
                except Exception:dead.append(sock)
            for sock in dead:self.drop(sock)
    def drop(self,sock):
        item=self.clients.pop(sock,None)
        try:sock.close()
        except OSError:pass
        return item[0] if item else None
    def start(self):
        listener=socket.socket();listener.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);listener.bind((self.host,self.port));listener.listen(50)
        print(f'Secure TLS chat listening on {self.host}:{self.port}')
        while True:
            raw,addr=listener.accept()
            try:
                raw.settimeout(15);sock=self.context.wrap_socket(raw,server_side=True);sock.settimeout(None);configure_keepalive(sock)
            except Exception as exc:
                logging.warning('TLS handshake failed from %s: %s',addr,exc);raw.close();continue
            threading.Thread(target=self.handle,args=(sock,addr),daemon=True).start()
    def handle(self,sock,addr):
        name=None
        try:
            reader=sock.makefile('r',encoding='utf-8',newline='\n');writer=sock.makefile('w',encoding='utf-8',newline='\n')
            first=reader.readline(MAX_LINE)
            if not first:return
            hello=json.loads(first);name=str(hello.get('username','')).strip()[:30];user=self.users.get(name)
            if not user or not verify(user,str(hello.get('password',''))):self.send(writer,{'type':'error','text':'Invalid or disabled account.'});return
            icon=str(hello.get('icon',''))
            if len(icon)>MAX_ICON:icon=''
            role=user.get('role','client')
            with self.lock:
                if any(n.casefold()==name.casefold() for n,w,i,r in self.clients.values()):self.send(writer,{'type':'error','text':'That account is already connected.'});return
                self.clients[sock]=(name,writer,icon,role)
            self.send(writer,{'type':'welcome','text':f'Connected as {name}.','role':role})
            self.broadcast({'type':'roster','users':self.roster()});self.broadcast({'type':'system','text':f'{name} joined the chat.'})
            for line in reader:
                if len(line)>=MAX_LINE:continue
                msg=json.loads(line)
                if msg.get('type')=='ping':self.send(writer,{'type':'pong'});continue
                if msg.get('type')=='message':
                    text=str(msg.get('text','')).strip()[:2000]
                    if text:self.broadcast({'type':'message','username':name,'text':text,'icon':icon,'role':role})
        except Exception as exc:logging.debug('Client ended: %s',exc)
        finally:
            with self.lock:left=self.drop(sock)
            if left:self.broadcast({'type':'system','text':f'{left} left the chat.'});self.broadcast({'type':'roster','users':self.roster()})

class VideoRelay:
    def __init__(self, host, port, users, context):
        self.host,self.port,self.users,self.context=host,port,users,context
        self.lock=threading.RLock(); self.clients={}
    def start(self):
        ls=socket.socket();ls.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);ls.bind((self.host,self.port));ls.listen(50)
        print(f'Encrypted muted-video relay listening on {self.host}:{self.port}')
        while True:
            raw,addr=ls.accept()
            try: raw.settimeout(15); sock=self.context.wrap_socket(raw,server_side=True); sock.settimeout(None); configure_keepalive(sock)
            except Exception: raw.close(); continue
            threading.Thread(target=self.handle,args=(sock,),daemon=True).start()
    @staticmethod
    def recv_exact(sock,n):
        b=bytearray()
        while len(b)<n:
            c=sock.recv(n-len(b))
            if not c: raise ConnectionError('video socket closed')
            b.extend(c)
        return bytes(b)
    def handle(self,sock):
        import struct
        name=None
        try:
            n=struct.unpack('!I',self.recv_exact(sock,4))[0]
            hello=json.loads(self.recv_exact(sock,n).decode())
            name=str(hello.get('username','')).strip()[:30];u=self.users.get(name)
            if not u or not verify(u,str(hello.get('password',''))): return
            with self.lock:self.clients[sock]=name
            while True:
                size=struct.unpack('!I',self.recv_exact(sock,4))[0]
                if size<=0 or size>500000: raise ValueError('invalid video frame')
                frame=self.recv_exact(sock,size); packet=json.dumps({'username':name}).encode()+b'\n'+frame; wire=struct.pack('!I',len(packet))+packet
                dead=[]
                with self.lock:
                    for peer in self.clients:
                        if peer is sock: continue
                        try: peer.sendall(wire)
                        except Exception: dead.append(peer)
                    for peer in dead:
                        self.clients.pop(peer,None)
                        try:peer.close()
                        except:pass
        except Exception:pass
        finally:
            with self.lock:self.clients.pop(sock,None)
            try:sock.close()
            except:pass

def main():
    p=argparse.ArgumentParser(description='Secure TLS chat server');p.add_argument('--host',default='0.0.0.0');p.add_argument('--port',type=int,default=5050);p.add_argument('--video-port',type=int,default=5051);p.add_argument('--users',default='users.json');p.add_argument('--cert',default='server_cert.pem');p.add_argument('--key',default='server_key.pem');a=p.parse_args()
    ensure_certificate(a.cert,a.key);users=load_users(a.users)
    ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);ctx.minimum_version=ssl.TLSVersion.TLSv1_2;ctx.load_cert_chain(a.cert,a.key)
    threading.Thread(target=VideoRelay(a.host,a.video_port,users,ctx).start,daemon=True).start();ChatServer(a.host,a.port,users,ctx).start()
if __name__=='__main__':main()
