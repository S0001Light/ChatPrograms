import json
import os
import socket
import struct
import threading
import time
import tkinter as tk
from tkinter import filedialog

import cv2
import numpy as np
import pygame


# ============================================================
# CONFIGURATION
# ============================================================

WIDTH = 1280
HEIGHT = 720

CHAT_WIDTH = 350
CAMERA_AREA_WIDTH = WIDTH - CHAT_WIDTH

SERVER_IP = "0.0.0.0"

CHAT_PORT = 5000
FILE_PORT = 5001

MAX_USERS = 2

CAMERA_INDEX = 0

SEND_WIDTH = 320
SEND_HEIGHT = 180

VIDEO_FPS = 8
JPEG_QUALITY = 35

MAX_MESSAGE_LENGTH = 500

FILE_BUFFER_SIZE = 64 * 1024
MAX_FILE_SIZE = 100 * 1024 * 1024


# ============================================================
# DIRECTORIES
# ============================================================

BASE_DIR = os.path.dirname(
    os.path.abspath(__file__)
)

DOWNLOAD_DIR = os.path.join(
    BASE_DIR,
    "downloads"
)

os.makedirs(
    DOWNLOAD_DIR,
    exist_ok=True
)


# ============================================================
# PYGAME
# ============================================================

pygame.init()

screen = pygame.display.set_mode(
    (WIDTH, HEIGHT)
)

pygame.display.set_caption(
    "camChat"
)

clock = pygame.time.Clock()

font = pygame.font.SysFont(
    "consolas",
    16
)

small_font = pygame.font.SysFont(
    "consolas",
    13
)

large_font = pygame.font.SysFont(
    "consolas",
    22
)


# ============================================================
# THEME
# ============================================================

theme = {
    "bg": (25, 25, 25),
    "panel": (37, 37, 37),
    "panel2": (48, 48, 48),

    "border": (70, 70, 70),

    "text": (237, 237, 237),
    "muted": (150, 150, 150),

    "accent": (0, 174, 239),
    "accent_hover": (30, 194, 255),

    "green": (70, 200, 100),
    "red": (255, 90, 90),

    "input_bg": (45, 45, 45),
    "input_border": (90, 90, 90),

    "black": (0, 0, 0)
}


# ============================================================
# LOCAL USER
# ============================================================

username = "Shawn"

icon_color = (
    0,
    200,
    255
)

my_id = None


# ============================================================
# APPLICATION STATE
# ============================================================

running = True
connected = False

mode = "chat"

current_input = ""

last_video_send = 0.0

chat_socket = None

send_lock = threading.Lock()


# ============================================================
# USERS
# ============================================================

users = {}
users_lock = threading.Lock()


# ============================================================
# CHAT
# ============================================================

chat_log = []
chat_lock = threading.Lock()


# ============================================================
# FILE SERVER STATE
# ============================================================

server_files = []
server_files_lock = threading.Lock()

file_status = "Press REFRESH to load files."

file_operation_running = False
file_operation_lock = threading.Lock()

file_scroll = 0


# ============================================================
# GENERAL HELPERS
# ============================================================

def recv_exact(sock, size):
    data = bytearray()

    while len(data) < size:
        chunk = sock.recv(
            size - len(data)
        )

        if not chunk:
            raise ConnectionError(
                "Connection closed"
            )

        data.extend(chunk)

    return bytes(data)


def safe_filename(filename):
    filename = os.path.basename(
        str(filename)
    )

    filename = filename.replace(
        "\x00",
        ""
    )

    return filename[:255]


def set_file_operation(value):
    global file_operation_running

    with file_operation_lock:
        file_operation_running = value


def file_operation_active():
    with file_operation_lock:
        return file_operation_running


# ============================================================
# CHAT HELPERS
# ============================================================

def add_chat_message(user_id, message):
    with chat_lock:
        chat_log.append(
            (
                user_id,
                str(message)
            )
        )

        if len(chat_log) > 250:
            del chat_log[:-250]


def add_system_message(message):
    add_chat_message(
        0,
        message
    )


def wrap_text(
    text,
    selected_font,
    maximum_width
):
    if not text:
        return [""]

    words = text.split(" ")

    lines = []
    current_line = ""

    for word in words:
        if current_line:
            test_line = (
                current_line
                + " "
                + word
            )
        else:
            test_line = word

        if (
            selected_font.size(
                test_line
            )[0]
            <= maximum_width
        ):
            current_line = test_line

        else:
            if current_line:
                lines.append(
                    current_line
                )

            if (
                selected_font.size(
                    word
                )[0]
                > maximum_width
            ):
                partial = ""

                for character in word:
                    test_partial = (
                        partial
                        + character
                    )

                    if (
                        selected_font.size(
                            test_partial
                        )[0]
                        <= maximum_width
                    ):
                        partial = test_partial

                    else:
                        if partial:
                            lines.append(
                                partial
                            )

                        partial = character

                current_line = partial

            else:
                current_line = word

    if current_line:
        lines.append(
            current_line
        )

    return lines or [""]


# ============================================================
# USER MANAGEMENT
# ============================================================

def create_default_user(user_id):
    return {
        "username": f"User {user_id}",
        "icon_color": (200, 200, 200),
        "frame": None
    }


def update_user(
    user_id,
    new_username=None,
    new_color=None
):
    with users_lock:
        if user_id not in users:
            users[user_id] = (
                create_default_user(
                    user_id
                )
            )

        if new_username is not None:
            users[user_id]["username"] = (
                str(new_username)[:24]
            )

        if new_color is not None:
            try:
                color = tuple(
                    max(
                        0,
                        min(
                            255,
                            int(value)
                        )
                    )
                    for value in new_color[:3]
                )

                if len(color) == 3:
                    users[user_id]["icon_color"] = (
                        color
                    )

            except (
                TypeError,
                ValueError,
                IndexError
            ):
                pass


def update_user_frame(user_id, frame):
    with users_lock:
        if user_id not in users:
            users[user_id] = (
                create_default_user(
                    user_id
                )
            )

        users[user_id]["frame"] = frame


def remove_user(user_id):
    with users_lock:
        users.pop(
            user_id,
            None
        )


# ============================================================
# CHAT NETWORK SEND
# ============================================================

def send_packet(packet_type, payload=b""):
    global connected

    if not connected:
        return False

    if chat_socket is None:
        return False

    packet = (
        packet_type
        + len(payload).to_bytes(
            4,
            "big"
        )
        + payload
    )

    try:
        with send_lock:
            chat_socket.sendall(
                packet
            )

        return True

    except (
        OSError,
        ConnectionError,
        ConnectionResetError,
        BrokenPipeError
    ) as error:
        print(
            f"Send error: {error}"
        )

        connected = False

        return False


def send_userinfo():
    information = {
        "username": username,
        "icon_color": list(
            icon_color
        )
    }

    payload = json.dumps(
        information
    ).encode(
        "utf-8"
    )

    send_packet(
        b"U",
        payload
    )


def send_text(message):
    message = message.strip()

    if not message:
        return

    message = message[
        :MAX_MESSAGE_LENGTH
    ]

    send_packet(
        b"T",
        message.encode(
            "utf-8"
        )
    )


def send_video(frame):
    reduced_frame = cv2.resize(
        frame,
        (
            SEND_WIDTH,
            SEND_HEIGHT
        ),
        interpolation=cv2.INTER_AREA
    )

    success, jpeg = cv2.imencode(
        ".jpg",
        reduced_frame,
        [
            cv2.IMWRITE_JPEG_QUALITY,
            JPEG_QUALITY
        ]
    )

    if not success:
        return

    send_packet(
        b"V",
        jpeg.tobytes()
    )


# ============================================================
# CHAT NETWORK RECEIVE
# ============================================================

def network_loop():
    global my_id
    global connected

    try:
        while connected:
            header = recv_exact(
                chat_socket,
                5
            )

            packet_type = header[:1]

            payload_length = int.from_bytes(
                header[1:5],
                "big"
            )

            if payload_length > 2_000_000:
                raise ValueError(
                    "Incoming packet is too large"
                )

            payload = recv_exact(
                chat_socket,
                payload_length
            )

            # ------------------------------------------------
            # CLIENT ID
            # ------------------------------------------------

            if packet_type == b"I":
                my_id = int.from_bytes(
                    payload,
                    "big"
                )

                update_user(
                    my_id,
                    username,
                    icon_color
                )

                send_userinfo()

                print(
                    f"Assigned client ID: {my_id}"
                )

            # ------------------------------------------------
            # ROSTER
            # ------------------------------------------------

            elif packet_type == b"J":
                information = json.loads(
                    payload.decode(
                        "utf-8"
                    )
                )

                user_id = int(
                    information["id"]
                )

                update_user(
                    user_id,
                    information.get(
                        "username",
                        f"User {user_id}"
                    ),
                    information.get(
                        "icon_color",
                        [200, 200, 200]
                    )
                )

            # ------------------------------------------------
            # USER INFORMATION
            # ------------------------------------------------

            elif packet_type == b"U":
                if len(payload) < 4:
                    continue

                user_id = int.from_bytes(
                    payload[:4],
                    "big"
                )

                information = json.loads(
                    payload[4:].decode(
                        "utf-8"
                    )
                )

                update_user(
                    user_id,
                    information.get(
                        "username",
                        f"User {user_id}"
                    ),
                    information.get(
                        "icon_color",
                        [200, 200, 200]
                    )
                )

            # ------------------------------------------------
            # CHAT
            # ------------------------------------------------

            elif packet_type == b"T":
                if len(payload) < 4:
                    continue

                user_id = int.from_bytes(
                    payload[:4],
                    "big"
                )

                message = payload[4:].decode(
                    "utf-8",
                    errors="replace"
                )

                add_chat_message(
                    user_id,
                    message
                )

            # ------------------------------------------------
            # VIDEO
            # ------------------------------------------------

            elif packet_type == b"V":
                if len(payload) < 5:
                    continue

                user_id = int.from_bytes(
                    payload[:4],
                    "big"
                )

                jpeg_data = payload[4:]

                jpeg_array = np.frombuffer(
                    jpeg_data,
                    dtype=np.uint8
                )

                frame = cv2.imdecode(
                    jpeg_array,
                    cv2.IMREAD_COLOR
                )

                if frame is not None:
                    update_user_frame(
                        user_id,
                        frame
                    )

            # ------------------------------------------------
            # USER LEFT
            # ------------------------------------------------

            elif packet_type == b"L":
                if len(payload) < 4:
                    continue

                user_id = int.from_bytes(
                    payload[:4],
                    "big"
                )

                with users_lock:
                    old_name = users.get(
                        user_id,
                        {}
                    ).get(
                        "username",
                        f"User {user_id}"
                    )

                remove_user(
                    user_id
                )

                add_system_message(
                    old_name
                    + " disconnected"
                )

            # ------------------------------------------------
            # ERROR
            # ------------------------------------------------

            elif packet_type == b"E":
                message = payload.decode(
                    "utf-8",
                    errors="replace"
                )

                add_system_message(
                    message
                )

                connected = False

    except (
        OSError,
        ConnectionError,
        ConnectionResetError,
        BrokenPipeError,
        ValueError,
        json.JSONDecodeError
    ) as error:
        print(
            f"Network ended: {error}"
        )

    finally:
        if connected:
            add_system_message(
                "Disconnected from server"
            )

        connected = False


# ============================================================
# CAMERA OPENING
# ============================================================

def open_camera():
    backends = [
        (
            "DirectShow",
            cv2.CAP_DSHOW
        ),
        (
            "Media Foundation",
            cv2.CAP_MSMF
        ),
        (
            "Automatic",
            cv2.CAP_ANY
        )
    ]

    camera_indexes = [
        CAMERA_INDEX
    ]

    for index in range(5):
        if index not in camera_indexes:
            camera_indexes.append(
                index
            )

    for index in camera_indexes:
        for backend_name, backend in backends:
            print(
                f"Trying camera {index} "
                f"using {backend_name}..."
            )

            candidate = cv2.VideoCapture(
                index,
                backend
            )

            if not candidate.isOpened():
                candidate.release()
                continue

            candidate.set(
                cv2.CAP_PROP_FRAME_WIDTH,
                SEND_WIDTH
            )

            candidate.set(
                cv2.CAP_PROP_FRAME_HEIGHT,
                SEND_HEIGHT
            )

            candidate.set(
                cv2.CAP_PROP_FPS,
                VIDEO_FPS
            )

            candidate.set(
                cv2.CAP_PROP_BUFFERSIZE,
                1
            )

            for attempt in range(12):
                success, frame = (
                    candidate.read()
                )

                if (
                    success
                    and frame is not None
                    and frame.size > 0
                ):
                    print(
                        f"Camera opened: "
                        f"index {index}, "
                        f"{backend_name}"
                    )

                    return candidate

                time.sleep(
                    0.05
                )

            candidate.release()

    print(
        "No working camera was found."
    )

    return None


# ============================================================
# FRAME CONVERSION
# ============================================================

def frame_to_surface(
    frame,
    maximum_width,
    maximum_height
):
    rgb = cv2.cvtColor(
        frame,
        cv2.COLOR_BGR2RGB
    )

    frame_height, frame_width = (
        rgb.shape[:2]
    )

    scale = min(
        maximum_width / frame_width,
        maximum_height / frame_height
    )

    new_width = max(
        1,
        int(
            frame_width
            * scale
        )
    )

    new_height = max(
        1,
        int(
            frame_height
            * scale
        )
    )

    resized = cv2.resize(
        rgb,
        (
            new_width,
            new_height
        ),
        interpolation=cv2.INTER_AREA
    )

    return pygame.image.frombuffer(
        resized.tobytes(),
        (
            new_width,
            new_height
        ),
        "RGB"
    ).copy()


# ============================================================
# DRAW BUTTON
# ============================================================

def draw_button(
    rect,
    text,
    color=None,
    disabled=False
):
    if color is None:
        color = theme["panel2"]

    if disabled:
        draw_color = (
            50,
            50,
            50
        )

        text_color = theme["muted"]

    else:
        mouse_position = (
            pygame.mouse.get_pos()
        )

        if rect.collidepoint(
            mouse_position
        ):
            if color == theme["accent"]:
                draw_color = theme[
                    "accent_hover"
                ]

            else:
                draw_color = (
                    60,
                    60,
                    60
                )

        else:
            draw_color = color

        text_color = theme["text"]

    pygame.draw.rect(
        screen,
        draw_color,
        rect
    )

    pygame.draw.rect(
        screen,
        theme["border"],
        rect,
        1
    )

    text_surface = small_font.render(
        text,
        True,
        text_color
    )

    screen.blit(
        text_surface,
        text_surface.get_rect(
            center=rect.center
        )
    )


# ============================================================
# DRAW CAMERA TILE
# ============================================================

def draw_camera_tile(
    rect,
    user_id,
    user_data
):
    pygame.draw.rect(
        screen,
        theme["panel"],
        rect
    )

    if user_id == my_id:
        border_color = theme["accent"]
        border_width = 2

    else:
        border_color = theme["border"]
        border_width = 1

    pygame.draw.rect(
        screen,
        border_color,
        rect,
        border_width
    )

    video_rect = pygame.Rect(
        rect.x + 3,
        rect.y + 3,
        rect.width - 6,
        rect.height - 29
    )

    frame = user_data.get(
        "frame"
    )

    frame_drawn = False

    if frame is not None:
        try:
            surface = frame_to_surface(
                frame,
                video_rect.width,
                video_rect.height
            )

            screen.blit(
                surface,
                (
                    video_rect.centerx
                    - surface.get_width()
                    // 2,

                    video_rect.centery
                    - surface.get_height()
                    // 2
                )
            )

            frame_drawn = True

        except (
            cv2.error,
            pygame.error,
            ValueError
        ):
            frame_drawn = False

    if not frame_drawn:
        color = user_data.get(
            "icon_color",
            (200, 200, 200)
        )

        pygame.draw.circle(
            screen,
            color,
            video_rect.center,
            22
        )

        no_camera = small_font.render(
            "No camera",
            True,
            theme["muted"]
        )

        screen.blit(
            no_camera,
            no_camera.get_rect(
                center=(
                    video_rect.centerx,
                    video_rect.centery + 38
                )
            )
        )

    name_bar = pygame.Rect(
        rect.x + 1,
        rect.bottom - 25,
        rect.width - 2,
        24
    )

    pygame.draw.rect(
        screen,
        theme["black"],
        name_bar
    )

    name = user_data.get(
        "username",
        f"User {user_id}"
    )

    if user_id == my_id:
        name += " (You)"

    while (
        name
        and small_font.size(name)[0]
        > rect.width - 34
    ):
        name = name[:-1]

    color = user_data.get(
        "icon_color",
        (200, 200, 200)
    )

    pygame.draw.circle(
        screen,
        color,
        (
            rect.x + 11,
            rect.bottom - 13
        ),
        5
    )

    name_surface = small_font.render(
        name,
        True,
        theme["text"]
    )

    screen.blit(
        name_surface,
        (
            rect.x + 21,
            rect.bottom - 21
        )
    )


# ============================================================
# DRAW CAMERAS
#
# Remote camera = top
# Local camera  = bottom
# ============================================================

def draw_camera_grid(local_frame):
    tile_width = CAMERA_AREA_WIDTH
    tile_height = HEIGHT // 2

    # This snapshot must remain inside this function.
    with users_lock:
        snapshot = {
            user_id: dict(user_data)
            for user_id, user_data
            in users.items()
        }

    # --------------------------------------------------------
    # LOCAL DATA
    # --------------------------------------------------------

    local_id = (
        my_id
        if my_id is not None
        else -1
    )

    if local_id not in snapshot:
        snapshot[local_id] = (
            create_default_user(
                local_id
            )
        )

    snapshot[local_id]["username"] = (
        username
    )

    snapshot[local_id]["icon_color"] = (
        icon_color
    )

    snapshot[local_id]["frame"] = (
        local_frame
    )

    if my_id is not None:
        snapshot.pop(
            -1,
            None
        )

    # --------------------------------------------------------
    # REMOTE DATA
    # --------------------------------------------------------

    remote_user = None

    for user_id, user_data in snapshot.items():
        if user_id != local_id:
            remote_user = (
                user_id,
                user_data
            )

            break

    # --------------------------------------------------------
    # TOP HALF: REMOTE CAMERA
    # --------------------------------------------------------

    remote_rect = pygame.Rect(
        0,
        0,
        tile_width,
        tile_height
    )

    if remote_user is not None:
        remote_id, remote_data = (
            remote_user
        )

        draw_camera_tile(
            remote_rect,
            remote_id,
            remote_data
        )

    else:
        pygame.draw.rect(
            screen,
            theme["panel"],
            remote_rect
        )

        pygame.draw.rect(
            screen,
            theme["border"],
            remote_rect,
            1
        )

        waiting_surface = large_font.render(
            "Waiting for remote user...",
            True,
            theme["muted"]
        )

        screen.blit(
            waiting_surface,
            waiting_surface.get_rect(
                center=remote_rect.center
            )
        )

    # --------------------------------------------------------
    # BOTTOM HALF: LOCAL CAMERA
    # --------------------------------------------------------

    local_rect = pygame.Rect(
        0,
        tile_height,
        tile_width,
        HEIGHT - tile_height
    )

    draw_camera_tile(
        local_rect,
        local_id,
        snapshot[local_id]
    )


# ============================================================
# DRAW CHAT
# ============================================================

def draw_chat():
    panel = pygame.Rect(
        CAMERA_AREA_WIDTH,
        0,
        CHAT_WIDTH,
        HEIGHT
    )

    pygame.draw.rect(
        screen,
        theme["panel"],
        panel
    )

    pygame.draw.line(
        screen,
        theme["border"],
        (
            panel.x,
            0
        ),
        (
            panel.x,
            HEIGHT
        ),
        1
    )

    title_surface = large_font.render(
        "camChat",
        True,
        theme["text"]
    )

    screen.blit(
        title_surface,
        (
            panel.x + 10,
            8
        )
    )

    with users_lock:
        user_count = len(
            users
        )

    if (
        my_id is None
        or my_id not in users
    ):
        user_count += 1

    user_count = min(
        user_count,
        MAX_USERS
    )

    if connected:
        status_text = (
            f"Private | "
            f"{user_count}/{MAX_USERS} users"
        )

        status_color = theme[
            "green"
        ]

    else:
        status_text = "Disconnected"

        status_color = theme[
            "red"
        ]

    status_surface = small_font.render(
        status_text,
        True,
        status_color
    )

    screen.blit(
        status_surface,
        (
            panel.x + 10,
            36
        )
    )

    # --------------------------------------------------------
    # FILE BUTTONS
    # --------------------------------------------------------

    server_files_button = pygame.Rect(
        panel.x + 10,
        62,
        155,
        32
    )

    upload_button = pygame.Rect(
        panel.x + 175,
        62,
        165,
        32
    )

    draw_button(
        server_files_button,
        "SERVER FILES"
    )

    draw_button(
        upload_button,
        "UPLOAD",
        theme["accent"],
        disabled=file_operation_active()
    )

    # --------------------------------------------------------
    # CHAT MESSAGES
    # --------------------------------------------------------

    with users_lock:
        names = {
            user_id: user_data.get(
                "username",
                f"User {user_id}"
            )
            for user_id, user_data
            in users.items()
        }

    if my_id is not None:
        names[my_id] = username

    with chat_lock:
        messages = list(
            chat_log
        )

    lines = []

    for user_id, message in messages:
        if user_id == 0:
            prefix = "System"

        else:
            prefix = names.get(
                user_id,
                f"User {user_id}"
            )

        complete_message = (
            prefix
            + ": "
            + message
        )

        lines.extend(
            wrap_text(
                complete_message,
                small_font,
                CHAT_WIDTH - 20
            )
        )

    input_box = pygame.Rect(
        panel.x + 10,
        HEIGHT - 42,
        CHAT_WIDTH - 20,
        32
    )

    chat_top = 108
    line_height = 16

    maximum_lines = max(
        1,
        (
            input_box.y
            - chat_top
            - 8
        )
        // line_height
    )

    lines = lines[
        -maximum_lines:
    ]

    draw_y = chat_top

    for line in lines:
        line_surface = small_font.render(
            line,
            True,
            theme["text"]
        )

        screen.blit(
            line_surface,
            (
                panel.x + 10,
                draw_y
            )
        )

        draw_y += line_height

    # --------------------------------------------------------
    # INPUT BOX
    # --------------------------------------------------------

    pygame.draw.rect(
        screen,
        theme["input_bg"],
        input_box
    )

    pygame.draw.rect(
        screen,
        theme["input_border"],
        input_box,
        1
    )

    displayed_input = current_input

    while (
        displayed_input
        and font.size(
            displayed_input
        )[0]
        > input_box.width - 14
    ):
        displayed_input = (
            displayed_input[1:]
        )

    input_surface = font.render(
        displayed_input,
        True,
        theme["text"]
    )

    screen.blit(
        input_surface,
        (
            input_box.x + 6,
            input_box.y + 6
        )
    )

    if (
        int(
            time.time() * 2
        )
        % 2
        == 0
    ):
        cursor_x = (
            input_box.x
            + 6
            + input_surface.get_width()
        )

        pygame.draw.line(
            screen,
            theme["accent"],
            (
                cursor_x,
                input_box.y + 5
            ),
            (
                cursor_x,
                input_box.bottom - 5
            ),
            2
        )


# ============================================================
# FILE SERVER CONNECTION
# ============================================================

def connect_file_server():
    file_socket = socket.socket(
        socket.AF_INET,
        socket.SOCK_STREAM
    )

    file_socket.setsockopt(
        socket.IPPROTO_TCP,
        socket.TCP_NODELAY,
        1
    )

    file_socket.settimeout(
        5.0
    )

    file_socket.connect(
        (
            SERVER_IP,
            FILE_PORT
        )
    )

    file_socket.settimeout(
        None
    )

    return file_socket


def receive_file_packet(file_socket):
    packet_type = recv_exact(
        file_socket,
        1
    )

    payload_size = struct.unpack(
        "!Q",
        recv_exact(
            file_socket,
            8
        )
    )[0]

    if payload_size > (
        MAX_FILE_SIZE
        + 1024 * 1024
    ):
        raise ValueError(
            "File-server response is too large"
        )

    payload = recv_exact(
        file_socket,
        payload_size
    )

    return (
        packet_type,
        payload
    )


# ============================================================
# REFRESH FILE LIST
# ============================================================

def refresh_file_list_worker():
    global server_files
    global file_status
    global file_scroll

    set_file_operation(
        True
    )

    file_status = (
        "Loading server files..."
    )

    file_socket = None

    try:
        file_socket = (
            connect_file_server()
        )

        file_socket.sendall(
            b"L"
        )

        packet_type, payload = (
            receive_file_packet(
                file_socket
            )
        )

        if packet_type == b"L":
            result = json.loads(
                payload.decode(
                    "utf-8"
                )
            )

            if not isinstance(
                result,
                list
            ):
                result = []

            cleaned_files = []

            for item in result:
                if not isinstance(
                    item,
                    dict
                ):
                    continue

                filename = safe_filename(
                    item.get(
                        "name",
                        ""
                    )
                )

                try:
                    file_size = int(
                        item.get(
                            "size",
                            0
                        )
                    )

                except (
                    TypeError,
                    ValueError
                ):
                    file_size = 0

                if filename:
                    cleaned_files.append({
                        "name": filename,
                        "size": max(
                            0,
                            file_size
                        )
                    })

            with server_files_lock:
                server_files = (
                    cleaned_files
                )

            file_scroll = 0

            file_status = (
                f"{len(cleaned_files)} "
                f"shared file(s)"
            )

        elif packet_type == b"E":
            file_status = payload.decode(
                "utf-8",
                errors="replace"
            )

        else:
            file_status = (
                "Unexpected file-server response."
            )

    except Exception as error:
        file_status = (
            "File server error: "
            + str(error)
        )

    finally:
        if file_socket is not None:
            try:
                file_socket.close()
            except OSError:
                pass

        set_file_operation(
            False
        )


def refresh_file_list():
    global file_status

    if file_operation_active():
        file_status = (
            "Another file operation is running."
        )

        return

    threading.Thread(
        target=refresh_file_list_worker,
        daemon=True,
        name="RefreshFileList"
    ).start()


# ============================================================
# SELECT UPLOAD
# ============================================================

def select_upload_file():
    root = tk.Tk()

    root.withdraw()

    try:
        root.attributes(
            "-topmost",
            True
        )

        root.update()

    except tk.TclError:
        pass

    try:
        filepath = (
            filedialog.askopenfilename(
                parent=root,
                title="Select file to upload",
                filetypes=[
                    (
                        "All files",
                        "*.*"
                    )
                ]
            )
        )

    finally:
        root.destroy()

    return filepath


# ============================================================
# UPLOAD
# ============================================================

def upload_file_worker(filepath):
    global file_status

    set_file_operation(
        True
    )

    file_socket = None

    try:
        if not os.path.isfile(
            filepath
        ):
            raise ValueError(
                "Selected file does not exist"
            )

        file_size = os.path.getsize(
            filepath
        )

        if file_size > MAX_FILE_SIZE:
            raise ValueError(
                "File exceeds the 100 MB limit"
            )

        filename = safe_filename(
            filepath
        )

        filename_data = filename.encode(
            "utf-8"
        )

        if not filename_data:
            raise ValueError(
                "Invalid filename"
            )

        if len(filename_data) > 255:
            raise ValueError(
                "Filename is too long"
            )

        file_socket = (
            connect_file_server()
        )

        file_status = (
            "Uploading "
            + filename
            + "..."
        )

        file_socket.sendall(
            b"U"
        )

        file_socket.sendall(
            struct.pack(
                "!H",
                len(filename_data)
            )
        )

        file_socket.sendall(
            filename_data
        )

        file_socket.sendall(
            struct.pack(
                "!Q",
                file_size
            )
        )

        bytes_sent = 0

        with open(
            filepath,
            "rb"
        ) as input_file:
            while True:
                chunk = input_file.read(
                    FILE_BUFFER_SIZE
                )

                if not chunk:
                    break

                file_socket.sendall(
                    chunk
                )

                bytes_sent += len(
                    chunk
                )

                if file_size > 0:
                    percentage = int(
                        bytes_sent
                        * 100
                        / file_size
                    )

                    file_status = (
                        f"Uploading "
                        f"{filename}: "
                        f"{percentage}%"
                    )

        packet_type, payload = (
            receive_file_packet(
                file_socket
            )
        )

        if packet_type == b"O":
            file_status = (
                "Uploaded: "
                + filename
            )

            add_system_message(
                username
                + " uploaded "
                + filename
            )

        elif packet_type == b"E":
            raise ValueError(
                payload.decode(
                    "utf-8",
                    errors="replace"
                )
            )

        else:
            raise ValueError(
                "Unexpected upload response"
            )

    except Exception as error:
        file_status = (
            "Upload failed: "
            + str(error)
        )

    finally:
        if file_socket is not None:
            try:
                file_socket.close()
            except OSError:
                pass

        set_file_operation(
            False
        )


def start_upload():
    global file_status

    if file_operation_active():
        file_status = (
            "Another file operation is running."
        )

        return

    try:
        filepath = (
            select_upload_file()
        )

    except Exception as error:
        file_status = (
            "Could not open file picker: "
            + str(error)
        )

        return

    if not filepath:
        file_status = (
            "Upload cancelled."
        )

        return

    threading.Thread(
        target=upload_file_worker,
        args=(
            filepath,
        ),
        daemon=True,
        name="FileUpload"
    ).start()


# ============================================================
# DOWNLOAD
# ============================================================

def download_file_worker(filename):
    global file_status

    set_file_operation(
        True
    )

    file_socket = None
    temporary_path = None

    try:
        filename = safe_filename(
            filename
        )

        filename_data = filename.encode(
            "utf-8"
        )

        if not filename_data:
            raise ValueError(
                "Invalid filename"
            )

        if len(filename_data) > 255:
            raise ValueError(
                "Filename is too long"
            )

        file_socket = (
            connect_file_server()
        )

        file_status = (
            "Downloading "
            + filename
            + "..."
        )

        file_socket.sendall(
            b"D"
        )

        file_socket.sendall(
            struct.pack(
                "!H",
                len(filename_data)
            )
        )

        file_socket.sendall(
            filename_data
        )

        response_type = recv_exact(
            file_socket,
            1
        )

        if response_type == b"E":
            error_size = struct.unpack(
                "!Q",
                recv_exact(
                    file_socket,
                    8
                )
            )[0]

            error_message = recv_exact(
                file_socket,
                error_size
            ).decode(
                "utf-8",
                errors="replace"
            )

            raise ValueError(
                error_message
            )

        if response_type != b"D":
            raise ValueError(
                "Unexpected download response"
            )

        name_length = struct.unpack(
            "!H",
            recv_exact(
                file_socket,
                2
            )
        )[0]

        if (
            name_length <= 0
            or name_length > 255
        ):
            raise ValueError(
                "Invalid downloaded filename"
            )

        received_name = recv_exact(
            file_socket,
            name_length
        ).decode(
            "utf-8",
            errors="replace"
        )

        received_name = safe_filename(
            received_name
        )

        file_size = struct.unpack(
            "!Q",
            recv_exact(
                file_socket,
                8
            )
        )[0]

        if file_size > MAX_FILE_SIZE:
            raise ValueError(
                "Downloaded file exceeds "
                "the 100 MB limit"
            )

        output_path = os.path.join(
            DOWNLOAD_DIR,
            received_name
        )

        temporary_path = (
            output_path
            + ".part"
        )

        remaining = file_size
        bytes_received = 0

        with open(
            temporary_path,
            "wb"
        ) as output_file:
            while remaining > 0:
                chunk = file_socket.recv(
                    min(
                        FILE_BUFFER_SIZE,
                        remaining
                    )
                )

                if not chunk:
                    raise ConnectionError(
                        "Download was interrupted"
                    )

                output_file.write(
                    chunk
                )

                bytes_received += len(
                    chunk
                )

                remaining -= len(
                    chunk
                )

                if file_size > 0:
                    percentage = int(
                        bytes_received
                        * 100
                        / file_size
                    )

                    file_status = (
                        f"Downloading "
                        f"{received_name}: "
                        f"{percentage}%"
                    )

        os.replace(
            temporary_path,
            output_path
        )

        temporary_path = None

        file_status = (
            "Downloaded: "
            + received_name
        )

        add_system_message(
            "Downloaded "
            + received_name
        )

    except Exception as error:
        file_status = (
            "Download failed: "
            + str(error)
        )

        if (
            temporary_path
            and os.path.isfile(
                temporary_path
            )
        ):
            try:
                os.remove(
                    temporary_path
                )
            except OSError:
                pass

    finally:
        if file_socket is not None:
            try:
                file_socket.close()
            except OSError:
                pass

        set_file_operation(
            False
        )


def download_file(filename):
    global file_status

    if file_operation_active():
        file_status = (
            "Another file operation is running."
        )

        return

    threading.Thread(
        target=download_file_worker,
        args=(
            filename,
        ),
        daemon=True,
        name="FileDownload"
    ).start()


# ============================================================
# FILE SIZE FORMAT
# ============================================================

def format_file_size(byte_count):
    size = float(
        byte_count
    )

    if size < 1024:
        return f"{int(size)} B"

    size /= 1024

    if size < 1024:
        return f"{size:.1f} KB"

    size /= 1024

    if size < 1024:
        return f"{size:.1f} MB"

    size /= 1024

    return f"{size:.1f} GB"


# ============================================================
# DRAW FILE BROWSER
# ============================================================

def draw_file_browser():
    screen.fill(
        theme["bg"]
    )

    title_surface = large_font.render(
        "camChat Shared Files",
        True,
        theme["text"]
    )

    screen.blit(
        title_surface,
        (
            30,
            22
        )
    )

    # No button opens or browses the local downloads directory.

    refresh_button = pygame.Rect(
        WIDTH - 465,
        20,
        150,
        35
    )

    upload_button = pygame.Rect(
        WIDTH - 300,
        20,
        155,
        35
    )

    back_button = pygame.Rect(
        WIDTH - 130,
        20,
        100,
        35
    )

    operation_running = (
        file_operation_active()
    )

    draw_button(
        refresh_button,
        "REFRESH",
        disabled=operation_running
    )

    draw_button(
        upload_button,
        "UPLOAD",
        theme["accent"],
        disabled=operation_running
    )

    draw_button(
        back_button,
        "BACK"
    )

    status_surface = small_font.render(
        file_status,
        True,
        (
            theme["accent"]
            if operation_running
            else theme["muted"]
        )
    )

    screen.blit(
        status_surface,
        (
            30,
            65
        )
    )

    pygame.draw.line(
        screen,
        theme["border"],
        (
            30,
            92
        ),
        (
            WIDTH - 30,
            92
        ),
        1
    )

    screen.blit(
        small_font.render(
            "FILE NAME",
            True,
            theme["muted"]
        ),
        (
            45,
            108
        )
    )

    screen.blit(
        small_font.render(
            "SIZE",
            True,
            theme["muted"]
        ),
        (
            WIDTH - 260,
            108
        )
    )

    screen.blit(
        small_font.render(
            "ACTION",
            True,
            theme["muted"]
        ),
        (
            WIDTH - 145,
            108
        )
    )

    with server_files_lock:
        files = list(
            server_files
        )

    row_height = 42
    start_y = 135

    visible_count = max(
        1,
        (
            HEIGHT
            - start_y
            - 20
        )
        // row_height
    )

    visible_files = files[
        file_scroll:
        file_scroll
        + visible_count
    ]

    for offset, file_information \
            in enumerate(visible_files):

        row_y = (
            start_y
            + offset
            * row_height
        )

        row_rect = pygame.Rect(
            30,
            row_y,
            WIDTH - 60,
            row_height - 4
        )

        pygame.draw.rect(
            screen,
            theme["panel"],
            row_rect
        )

        pygame.draw.rect(
            screen,
            theme["border"],
            row_rect,
            1
        )

        filename = str(
            file_information.get(
                "name",
                "Unknown"
            )
        )

        try:
            file_size = int(
                file_information.get(
                    "size",
                    0
                )
            )

        except (
            TypeError,
            ValueError
        ):
            file_size = 0

        display_name = filename

        while (
            display_name
            and small_font.size(
                display_name
            )[0]
            > WIDTH - 390
        ):
            display_name = (
                display_name[:-1]
            )

        name_surface = small_font.render(
            display_name,
            True,
            theme["text"]
        )

        screen.blit(
            name_surface,
            (
                row_rect.x + 14,
                row_rect.y + 11
            )
        )

        size_surface = small_font.render(
            format_file_size(
                file_size
            ),
            True,
            theme["muted"]
        )

        screen.blit(
            size_surface,
            (
                WIDTH - 260,
                row_rect.y + 11
            )
        )

        download_button = pygame.Rect(
            WIDTH - 145,
            row_rect.y + 5,
            100,
            28
        )

        draw_button(
            download_button,
            "DOWNLOAD",
            theme["accent"],
            disabled=operation_running
        )

    if not files:
        empty_surface = font.render(
            "No shared files.",
            True,
            theme["muted"]
        )

        screen.blit(
            empty_surface,
            empty_surface.get_rect(
                center=(
                    WIDTH // 2,
                    HEIGHT // 2
                )
            )
        )


# ============================================================
# STARTUP DISPLAY
# ============================================================

screen.fill(
    theme["bg"]
)

startup_surface = large_font.render(
    "Starting camChat...",
    True,
    theme["text"]
)

screen.blit(
    startup_surface,
    startup_surface.get_rect(
        center=(
            WIDTH // 2,
            HEIGHT // 2
        )
    )
)

pygame.display.flip()
pygame.event.pump()


# ============================================================
# OPEN CAMERA
# ============================================================

camera = open_camera()


# ============================================================
# CONNECT CHAT SERVER
# ============================================================

chat_socket = socket.socket(
    socket.AF_INET,
    socket.SOCK_STREAM
)

chat_socket.setsockopt(
    socket.IPPROTO_TCP,
    socket.TCP_NODELAY,
    1
)

chat_socket.settimeout(
    4.0
)

try:
    print(
        f"Connecting chat/video to "
        f"{SERVER_IP}:{CHAT_PORT}..."
    )

    chat_socket.connect(
        (
            SERVER_IP,
            CHAT_PORT
        )
    )

    chat_socket.settimeout(
        None
    )

    connected = True

    print(
        "camChat connected."
    )

except (
    socket.timeout,
    OSError
) as error:
    connected = False

    print(
        f"Connection failed: {error}"
    )

    add_system_message(
        "Connection failed: "
        + str(error)
    )


# ============================================================
# RECEIVE THREAD
# ============================================================

if connected:
    receiver_thread = threading.Thread(
        target=network_loop,
        daemon=True,
        name="NetworkReceiver"
    )

    receiver_thread.start()


# ============================================================
# MAIN LOOP
# ============================================================

while running:
    for event in pygame.event.get():

        # ----------------------------------------------------
        # QUIT
        # ----------------------------------------------------

        if event.type == pygame.QUIT:
            running = False

        # ----------------------------------------------------
        # KEYBOARD
        # ----------------------------------------------------

        elif event.type == pygame.KEYDOWN:

            if event.key == pygame.K_ESCAPE:
                if mode == "files":
                    mode = "chat"

                else:
                    running = False

            elif (
                mode == "chat"
                and event.key == pygame.K_RETURN
            ):
                message = current_input.strip()

                if message:
                    if connected:
                        send_text(
                            message
                        )

                    else:
                        add_system_message(
                            "Cannot send while disconnected"
                        )

                    current_input = ""

            elif (
                mode == "chat"
                and event.key == pygame.K_BACKSPACE
            ):
                current_input = (
                    current_input[:-1]
                )

            elif mode == "chat":
                if (
                    event.unicode
                    and event.unicode.isprintable()
                    and len(current_input)
                    < MAX_MESSAGE_LENGTH
                ):
                    current_input += (
                        event.unicode
                    )

            elif mode == "files":
                with server_files_lock:
                    file_count = len(
                        server_files
                    )

                visible_count = max(
                    1,
                    (
                        HEIGHT
                        - 135
                        - 20
                    )
                    // 42
                )

                maximum_scroll = max(
                    0,
                    file_count
                    - visible_count
                )

                if event.key == pygame.K_UP:
                    file_scroll = max(
                        0,
                        file_scroll - 1
                    )

                elif event.key == pygame.K_DOWN:
                    file_scroll = min(
                        maximum_scroll,
                        file_scroll + 1
                    )

                elif event.key == pygame.K_PAGEUP:
                    file_scroll = max(
                        0,
                        file_scroll
                        - visible_count
                    )

                elif event.key == pygame.K_PAGEDOWN:
                    file_scroll = min(
                        maximum_scroll,
                        file_scroll
                        + visible_count
                    )

        # ----------------------------------------------------
        # MOUSE WHEEL
        # ----------------------------------------------------

        elif (
            event.type == pygame.MOUSEWHEEL
            and mode == "files"
        ):
            with server_files_lock:
                file_count = len(
                    server_files
                )

            visible_count = max(
                1,
                (
                    HEIGHT
                    - 135
                    - 20
                )
                // 42
            )

            maximum_scroll = max(
                0,
                file_count
                - visible_count
            )

            file_scroll -= event.y

            file_scroll = max(
                0,
                min(
                    maximum_scroll,
                    file_scroll
                )
            )

        # ----------------------------------------------------
        # LEFT MOUSE CLICK
        # ----------------------------------------------------

        elif (
            event.type == pygame.MOUSEBUTTONDOWN
            and event.button == 1
        ):

            # =================================================
            # CHAT BUTTONS
            # =================================================

            if mode == "chat":
                panel_x = (
                    CAMERA_AREA_WIDTH
                )

                server_files_rect = (
                    pygame.Rect(
                        panel_x + 10,
                        62,
                        155,
                        32
                    )
                )

                upload_rect = pygame.Rect(
                    panel_x + 175,
                    62,
                    165,
                    32
                )

                if server_files_rect.collidepoint(
                    event.pos
                ):
                    mode = "files"

                    if not server_files:
                        refresh_file_list()

                elif (
                    upload_rect.collidepoint(
                        event.pos
                    )
                    and not file_operation_active()
                ):
                    start_upload()

            # =================================================
            # FILE BROWSER BUTTONS
            # =================================================

            elif mode == "files":
                refresh_rect = pygame.Rect(
                    WIDTH - 465,
                    20,
                    150,
                    35
                )

                upload_rect = pygame.Rect(
                    WIDTH - 300,
                    20,
                    155,
                    35
                )

                back_rect = pygame.Rect(
                    WIDTH - 130,
                    20,
                    100,
                    35
                )

                if back_rect.collidepoint(
                    event.pos
                ):
                    mode = "chat"

                elif (
                    refresh_rect.collidepoint(
                        event.pos
                    )
                    and not file_operation_active()
                ):
                    refresh_file_list()

                elif (
                    upload_rect.collidepoint(
                        event.pos
                    )
                    and not file_operation_active()
                ):
                    start_upload()

                elif not file_operation_active():
                    with server_files_lock:
                        files_snapshot = list(
                            server_files
                        )

                    row_height = 42
                    start_y = 135

                    visible_count = max(
                        1,
                        (
                            HEIGHT
                            - start_y
                            - 20
                        )
                        // row_height
                    )

                    visible_files = (
                        files_snapshot[
                            file_scroll:
                            file_scroll
                            + visible_count
                        ]
                    )

                    for offset, information \
                            in enumerate(
                                visible_files
                            ):

                        row_y = (
                            start_y
                            + offset
                            * row_height
                        )

                        download_rect = (
                            pygame.Rect(
                                WIDTH - 145,
                                row_y + 5,
                                100,
                                28
                            )
                        )

                        if download_rect.collidepoint(
                            event.pos
                        ):
                            filename = str(
                                information.get(
                                    "name",
                                    ""
                                )
                            )

                            if filename:
                                download_file(
                                    filename
                                )

                            break

    # ========================================================
    # READ LOCAL CAMERA
    # ========================================================

    local_frame = None

    if camera is not None:
        success, captured_frame = (
            camera.read()
        )

        if (
            success
            and captured_frame is not None
            and captured_frame.size > 0
        ):
            local_frame = captured_frame

    # ========================================================
    # SEND LOCAL VIDEO
    # ========================================================

    current_time = time.monotonic()

    if (
        connected
        and local_frame is not None
        and current_time
        - last_video_send
        >= 1.0 / VIDEO_FPS
    ):
        send_video(
            local_frame
        )

        last_video_send = (
            current_time
        )

    # ========================================================
    # DRAW
    # ========================================================

    screen.fill(
        theme["bg"]
    )

    if mode == "chat":
        draw_camera_grid(
            local_frame
        )

        draw_chat()

    elif mode == "files":
        draw_file_browser()

    pygame.display.flip()

    clock.tick(
        30
    )


# ============================================================
# SHUTDOWN
# ============================================================

connected = False

if camera is not None:
    camera.release()

if chat_socket is not None:
    try:
        chat_socket.shutdown(
            socket.SHUT_RDWR
        )
    except OSError:
        pass

    try:
        chat_socket.close()
    except OSError:
        pass

pygame.quit()
