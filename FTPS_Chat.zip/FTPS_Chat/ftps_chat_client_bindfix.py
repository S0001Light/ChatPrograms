#!/usr/bin/env python3
import ftplib, json, os, queue, socket, ssl, threading, time
import tkinter as tk
from pathlib import PurePosixPath
from tkinter import filedialog, messagebox, simpledialog, ttk

DISCOVERY_PORT = 2122
CHAT_PORT = 2123
DISCOVERY_QUERY = b'WIFI_FTPS_DISCOVER_V1'
DISCOVERY_PREFIX = 'WIFI_FTPS_HERE_V1'


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('WiFi Explicit FTPS Client')
        self.geometry('960x680')
        self.ftp = None
        self.current = '/'
        self.events = queue.Queue()
        self.busy = False
        self.chat_sock = None
        self.chat_file = None
        self.chat_lock = threading.Lock()
        self.build()
        self.after(100, self.poll)
        self.protocol('WM_DELETE_WINDOW', self.close)

    def build(self):
        top = ttk.LabelFrame(self, text='Explicit FTPS connection')
        top.pack(fill='x', padx=8, pady=8)
        self.host = tk.StringVar()
        self.port = tk.StringVar(value='2121')
        self.user = tk.StringVar(value='admin')
        self.password = tk.StringVar()
        fields = [('Server IP', self.host, 18, ''), ('Port', self.port, 7, ''), ('Username', self.user, 14, ''), ('Password', self.password, 14, '*')]
        for i, (label, variable, width, show) in enumerate(fields):
            ttk.Label(top, text=label).grid(row=0, column=i * 2, padx=3)
            ttk.Entry(top, textvariable=variable, width=width, show=show).grid(row=0, column=i * 2 + 1, padx=3)
        ttk.Button(top, text='Find server', command=self.find_server).grid(row=0, column=8, padx=3)
        ttk.Button(top, text='Connect FTPS', command=self.connect_ftps).grid(row=0, column=9, padx=3)
        ttk.Button(top, text='Disconnect', command=self.disconnect).grid(row=0, column=10, padx=3)

        buttons = ttk.Frame(self)
        buttons.pack(fill='x', padx=8)
        self.path_label = ttk.Label(buttons, text='/')
        self.path_label.pack(side='left', padx=4)
        for label, command in [('Up', self.up), ('Refresh', self.refresh), ('Upload', self.upload), ('Download', self.download), ('New folder', self.mkdir), ('Delete', self.delete)]:
            ttk.Button(buttons, text=label, command=command).pack(side='left', padx=2)

        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill='both', expand=True, padx=8, pady=6)
        files_tab = ttk.Frame(self.tabs); chat_tab = ttk.Frame(self.tabs)
        self.tabs.add(files_tab, text='Files'); self.tabs.add(chat_tab, text='Chat')

        self.tree = ttk.Treeview(files_tab, columns=('type', 'size', 'modified'), show='tree headings')
        self.tree.heading('#0', text='Name')
        self.tree.heading('type', text='Type')
        self.tree.heading('size', text='Size')
        self.tree.heading('modified', text='Modified')
        self.tree.pack(fill='both', expand=True)
        self.tree.bind('<Double-1>', lambda event: self.open_selected())

        chat_buttons=ttk.Frame(chat_tab); chat_buttons.pack(fill='x', pady=(0,4))
        ttk.Button(chat_buttons,text='Connect chat',command=self.connect_chat).pack(side='left',padx=2)
        ttk.Button(chat_buttons,text='Disconnect chat',command=self.disconnect_chat).pack(side='left',padx=2)
        self.chat_status=tk.StringVar(value='Chat disconnected')
        ttk.Label(chat_buttons,textvariable=self.chat_status).pack(side='left',padx=8)
        self.chat_view=tk.Text(chat_tab,state='disabled',wrap='word')
        self.chat_view.pack(fill='both',expand=True)
        compose=ttk.Frame(chat_tab);compose.pack(fill='x',pady=(4,0))
        self.chat_entry=ttk.Entry(compose);self.chat_entry.pack(side='left',fill='x',expand=True)
        self.chat_entry.bind('<Return>',lambda e:self.send_chat())
        ttk.Button(compose,text='Send',command=self.send_chat).pack(side='left',padx=(4,0))

        self.progress = ttk.Progressbar(self, maximum=100)
        self.progress.pack(fill='x', padx=8)
        self.status = tk.StringVar(value='Disconnected')
        ttk.Label(self, textvariable=self.status).pack(fill='x', padx=8, pady=4)
        self.logbox = tk.Text(self, height=8, state='disabled')
        self.logbox.pack(fill='x', padx=8, pady=(0, 8))

    def log(self, text):
        self.events.put(('log', f"{time.strftime('%H:%M:%S')} {text}"))

    def local_ipv4(self):
        values = []
        try:
            for item in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
                ip = item[4][0]
                if not ip.startswith(('127.', '169.254.')) and ip not in values:
                    values.append(ip)
        except OSError:
            pass
        return values

    def find_server(self):
        if self.busy:
            return
        self.busy = True
        self.status.set('Broadcasting FTPS discovery...')

        def work():
            replies = []
            local = self.local_ipv4()
            for source_ip in local:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                sock.bind((source_ip, 0))
                sock.settimeout(1.0)
                targets = [('255.255.255.255', DISCOVERY_PORT), (source_ip.rsplit('.', 1)[0] + '.255', DISCOVERY_PORT)]
                for target in targets:
                    try:
                        sock.sendto(DISCOVERY_QUERY, target)
                        self.log(f'[DISCOVERY] Sent from {source_ip} to {target[0]}:{target[1]}')
                    except OSError as error:
                        self.log(f'[DISCOVERY] Send error: {error}')
                deadline = time.monotonic() + 3
                while time.monotonic() < deadline:
                    try:
                        data, address = sock.recvfrom(1024)
                    except socket.timeout:
                        break
                    try:
                        prefix, server_ip, port = data.decode('ascii').split('|')
                        item = (server_ip, int(port))
                    except (ValueError, UnicodeDecodeError):
                        continue
                    if prefix == DISCOVERY_PREFIX and item not in replies and server_ip not in local:
                        replies.append(item)
                        self.log(f'[DISCOVERY] Reply from {address[0]}, advertised {server_ip}:{port}')
                sock.close()
            self.busy = False
            if replies:
                host, port = replies[0]
                self.after(0, lambda: self.host.set(host))
                self.after(0, lambda: self.port.set(str(port)))
                self.events.put(('status', f'Found FTPS server at {host}:{port}'))
            else:
                self.events.put(('error', 'No FTPS discovery reply. Enter the server IP manually and connect.'))

        threading.Thread(target=work, daemon=True).start()

    def make_ftps(self):
        context = ssl.create_default_context()
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
        ftp = ftplib.FTP_TLS(context=context, timeout=15, encoding='utf-8')
        host = self.host.get().strip()
        port = int(self.port.get())
        self.log(f'[FTPS] TCP connect {host}:{port}')
        ftp.connect(host, port)
        self.log('[FTPS] AUTH TLS and login')
        ftp.login(self.user.get().strip(), self.password.get())
        ftp.prot_p()
        ftp.set_pasv(True)
        self.log(f'[FTPS] Secure control/data enabled: {ftp.sock.version()}')
        return ftp

    def connect_ftps(self):
        if self.busy:
            return
        if not self.host.get().strip():
            return self.find_server()
        self.busy = True
        self.status.set('Connecting with explicit FTPS...')

        def work():
            try:
                self.disconnect(silent=True)
                self.ftp = self.make_ftps()
                self.current = '/'
                self.events.put(('connected', None))
            except Exception as error:
                self.ftp = None
                self.events.put(('error', f'{type(error).__name__}: {error}'))
            finally:
                self.busy = False

        threading.Thread(target=work, daemon=True).start()

    def require_connection(self):
        if not self.ftp:
            messagebox.showwarning('FTPS', 'Connect first.')
            return False
        return True

    def refresh(self):
        if not self.require_connection() or self.busy:
            return
        self.busy = True

        def work():
            try:
                self.ftp.cwd(self.current)
                rows = []
                for name, facts in self.ftp.mlsd():
                    if name in ('.', '..'):
                        continue
                    rows.append((name, facts.get('type', ''), int(facts.get('size', 0) or 0), facts.get('modify', '')))
                rows.sort(key=lambda row: (row[1] != 'dir', row[0].lower()))
                self.events.put(('listing', rows))
            except Exception as error:
                self.events.put(('error', f'Refresh failed: {error}'))
            finally:
                self.busy = False

        threading.Thread(target=work, daemon=True).start()

    def selected(self):
        selection = self.tree.selection()
        if not selection:
            return None
        item = self.tree.item(selection[0])
        return item['text'], item['values'][0]

    def remote_join(self, name):
        return str(PurePosixPath(self.current) / name)

    def open_selected(self):
        selected = self.selected()
        if selected and selected[1] == 'dir':
            self.current = self.remote_join(selected[0])
            self.refresh()

    def up(self):
        if self.current != '/':
            parent = str(PurePosixPath(self.current).parent)
            self.current = parent if parent.startswith('/') else '/' + parent
            self.refresh()

    def upload(self):
        if not self.require_connection() or self.busy:
            return
        local_path = filedialog.askopenfilename()
        if not local_path:
            return
        remote_name = os.path.basename(local_path)
        self.busy = True

        def work():
            try:
                total = os.path.getsize(local_path)
                sent = 0
                def callback(block):
                    nonlocal sent
                    sent += len(block)
                    self.events.put(('progress', int(sent * 100 / total) if total else 100))
                with open(local_path, 'rb') as source:
                    self.ftp.storbinary(f'STOR {remote_name}', source, blocksize=262144, callback=callback)
                self.events.put(('status', f'Uploaded {remote_name}'))
                self.events.put(('refresh', None))
            except Exception as error:
                self.events.put(('error', f'Upload failed: {error}'))
            finally:
                self.events.put(('progress', 0))
                self.busy = False

        threading.Thread(target=work, daemon=True).start()

    def download(self):
        if not self.require_connection() or self.busy:
            return
        selected = self.selected()
        if not selected or selected[1] != 'file':
            return
        name = selected[0]
        target = filedialog.asksaveasfilename(initialfile=name)
        if not target:
            return
        self.busy = True

        def work():
            try:
                total = self.ftp.size(name) or 0
                received = 0
                with open(target, 'wb') as output:
                    def callback(block):
                        nonlocal received
                        output.write(block)
                        received += len(block)
                        self.events.put(('progress', int(received * 100 / total) if total else 0))
                    self.ftp.retrbinary(f'RETR {name}', callback, blocksize=262144)
                self.events.put(('status', f'Downloaded {name}'))
            except Exception as error:
                self.events.put(('error', f'Download failed: {error}'))
            finally:
                self.events.put(('progress', 0))
                self.busy = False

        threading.Thread(target=work, daemon=True).start()

    def mkdir(self):
        if not self.require_connection() or self.busy:
            return
        name = simpledialog.askstring('New folder', 'Folder name:')
        if not name:
            return
        try:
            self.ftp.mkd(name)
            self.refresh()
        except Exception as error:
            messagebox.showerror('FTPS', str(error))

    def delete(self):
        if not self.require_connection() or self.busy:
            return
        selected = self.selected()
        if not selected or not messagebox.askyesno('Delete', selected[0]):
            return
        try:
            self.ftp.rmd(selected[0]) if selected[1] == 'dir' else self.ftp.delete(selected[0])
            self.refresh()
        except Exception as error:
            messagebox.showerror('FTPS', str(error))

    def chat_append(self, text):
        self.chat_view.config(state='normal'); self.chat_view.insert('end', text+'\n'); self.chat_view.see('end'); self.chat_view.config(state='disabled')

    def connect_chat(self):
        if self.chat_sock: return
        host=self.host.get().strip()
        if not host:
            return messagebox.showwarning('Chat','Find or enter the server IP first.')
        username=self.user.get().strip(); password=self.password.get()
        self.chat_status.set('Connecting chat...')
        def work():
            try:
                context=ssl.create_default_context(); context.check_hostname=False; context.verify_mode=ssl.CERT_NONE
                raw=socket.create_connection((host,CHAT_PORT),10)
                sock=context.wrap_socket(raw,server_hostname=None); file=sock.makefile('r',encoding='utf-8',newline='\n')
                sock.sendall((json.dumps({'type':'login','username':username,'password':password,'display_name':username})+'\n').encode())
                reply=json.loads(file.readline())
                if not reply.get('ok'): raise RuntimeError(reply.get('message','Chat login failed'))
                self.chat_sock=sock; self.chat_file=file
                self.events.put(('chat_status','Chat connected'))
                self.events.put(('chat',reply.get('message','Chat connected')))
                for line in file:
                    try: msg=json.loads(line)
                    except json.JSONDecodeError: continue
                    if msg.get('type')=='chat': self.events.put(('chat',f"[{msg.get('time','')}] {msg.get('from','')}: {msg.get('text','')}"))
                    elif msg.get('type')=='system': self.events.put(('chat',f"* {msg.get('text','')}"))
            except Exception as error:
                self.events.put(('chat_status','Chat disconnected'))
                self.events.put(('error',f'Chat: {type(error).__name__}: {error}'))
            finally:
                if self.chat_sock:
                    try: self.chat_sock.close()
                    except OSError: pass
                self.chat_sock=None; self.chat_file=None
        threading.Thread(target=work,daemon=True).start()

    def send_chat(self):
        text=self.chat_entry.get().strip()
        if not text: return
        if not self.chat_sock:
            return messagebox.showwarning('Chat','Connect chat first.')
        try:
            data=(json.dumps({'type':'chat','text':text},ensure_ascii=False)+'\n').encode('utf-8')
            with self.chat_lock: self.chat_sock.sendall(data)
            self.chat_entry.delete(0,'end')
        except OSError as error:
            messagebox.showerror('Chat',str(error))

    def disconnect_chat(self):
        sock,self.chat_sock=self.chat_sock,None
        self.chat_file=None
        if sock:
            try: sock.shutdown(socket.SHUT_RDWR)
            except OSError: pass
            try: sock.close()
            except OSError: pass
        self.chat_status.set('Chat disconnected')

    def disconnect(self, silent=False):
        ftp, self.ftp = self.ftp, None
        if ftp:
            try:
                ftp.quit()
            except Exception:
                try: ftp.close()
                except Exception: pass
        if not silent:
            self.status.set('Disconnected')

    def poll(self):
        try:
            while True:
                kind, payload = self.events.get_nowait()
                if kind == 'log':
                    self.logbox.config(state='normal')
                    self.logbox.insert('end', payload + '\n')
                    self.logbox.see('end')
                    self.logbox.config(state='disabled')
                elif kind == 'status':
                    self.status.set(payload)
                elif kind == 'error':
                    self.status.set(payload)
                    messagebox.showerror('FTPS', payload)
                elif kind == 'connected':
                    self.status.set('Explicit FTPS connected; control and data protection enabled')
                    self.refresh()
                elif kind == 'listing':
                    self.tree.delete(*self.tree.get_children())
                    self.path_label.config(text=self.current)
                    for name, item_type, size, modified in payload:
                        self.tree.insert('', 'end', text=name, values=(item_type, size if item_type == 'file' else '', modified))
                elif kind == 'chat':
                    self.chat_append(payload)
                elif kind == 'chat_status':
                    self.chat_status.set(payload)
                elif kind == 'progress':
                    self.progress['value'] = payload
                elif kind == 'refresh':
                    self.after(0, self.refresh)
        except queue.Empty:
            pass
        self.after(100, self.poll)

    def close(self):
        self.disconnect_chat()
        self.disconnect(silent=True)
        self.destroy()


if __name__ == '__main__':
    App().mainloop()
