#!/usr/bin/env python3
# Modern client.
import base64, ftplib, io, json, queue, socket, ssl, threading
try:
    import tkinter as tk
    from tkinter import filedialog,messagebox,ttk
except ImportError:
    import Tkinter as tk
    import tkFileDialog as filedialog
    import tkMessageBox as messagebox
    import ttk
try:
    from PIL import Image,ImageTk
except ImportError:
    Image=ImageTk=None

class App(tk.Tk):
    def __init__(self):
        tk.Tk.__init__(self); self.title('FTPS + TLS Chat'); self.geometry('980x650')
        self.events=queue.Queue(); self.ftp=self.sock=self.writer=None; self.remote='/'; self.icon_data=''; self.photos={}; self.legacy=tk.BooleanVar(value=False); self.build(); self.after(100,self.poll); self.protocol('WM_DELETE_WINDOW',self.close)
    def build(self):
        f=ttk.LabelFrame(self,text='Connection'); f.pack(fill='x',padx=8,pady=8)
        self.host=tk.StringVar(value='127.0.0.1'); self.fp=tk.StringVar(value='2121'); self.cp=tk.StringVar(value='5050'); self.user=tk.StringVar(); self.pw=tk.StringVar()
        vals=[('Host',self.host,16),('FTPS',self.fp,6),('Chat TLS',self.cp,6),('Username',self.user,14),('Password',self.pw,14)]
        for i,item in enumerate(vals):
            ttk.Label(f,text=item[0]).grid(row=0,column=i*2,padx=3); ttk.Entry(f,textvariable=item[1],width=item[2],show='*' if item[0]=='Password' else '').grid(row=0,column=i*2+1,padx=3)
        ttk.Button(f,text='Icon',command=self.pick_icon).grid(row=1,column=0); ttk.Checkbutton(f,text='Legacy compatibility',variable=self.legacy).grid(row=1,column=2,columnspan=2,sticky='w'); ttk.Button(f,text='Connect',command=self.connect).grid(row=1,column=8); ttk.Button(f,text='Disconnect',command=self.disconnect_ui).grid(row=1,column=9)
        n=ttk.Notebook(self); n.pack(fill='both',expand=True,padx=8); files=ttk.Frame(n); chat=ttk.Frame(n); n.add(files,text='Files'); n.add(chat,text='Chat')
        bar=ttk.Frame(files); bar.pack(fill='x'); self.path=ttk.Label(bar,text='/'); self.path.pack(side='left')
        for name,cmd in [('Up',self.up),('Refresh',self.refresh),('Upload',self.upload),('Download',self.download),('New folder',self.mkdir),('Delete',self.delete)]: ttk.Button(bar,text=name,command=cmd).pack(side='left')
        self.tree=ttk.Treeview(files,columns=('type','size'),show='tree headings'); self.tree.heading('#0',text='Name'); self.tree.heading('type',text='Type'); self.tree.heading('size',text='Size'); self.tree.pack(fill='both',expand=True); self.tree.bind('<Double-1>',lambda e:self.open_folder())
        self.log=tk.Text(chat,state='disabled',wrap='word'); self.log.pack(fill='both',expand=True); row=ttk.Frame(chat); row.pack(fill='x'); self.msg=tk.StringVar(); e=ttk.Entry(row,textvariable=self.msg); e.pack(side='left',fill='x',expand=True); e.bind('<Return>',lambda e:self.send()); ttk.Button(row,text='Send',command=self.send).pack(side='left')
        self.roster=tk.Listbox(chat,height=5); self.roster.pack(fill='x'); self.status=tk.StringVar(value='Disconnected'); ttk.Label(self,textvariable=self.status).pack(fill='x')
    def tls_context(self):
        cert='server_cert.pem'
        if hasattr(ssl,'create_default_context'):
            if __import__('os').path.exists(cert):
                c=ssl.create_default_context(cafile=cert); c.check_hostname=False; return c
            return ssl._create_unverified_context()
        return ssl.SSLContext(ssl.PROTOCOL_TLSv1)
    def pick_icon(self):
        if Image is None: return messagebox.showwarning('Icon','Install Pillow to use icons.')
        p=filedialog.askopenfilename(filetypes=[('Images','*.png *.jpg *.jpeg')])
        if p:
            im=Image.open(p).convert('RGBA'); im.thumbnail((64,64)); b=io.BytesIO(); im.save(b,'PNG'); self.icon_data=base64.b64encode(b.getvalue()).decode('ascii')
    def connect(self):
        threading.Thread(target=self._connect,args=(self.host.get().strip(),int(self.fp.get()),int(self.cp.get()),self.user.get().strip(),self.pw.get()),daemon=True).start()
    def _connect(self,h,fp,cp,u,pw):
        try:
            self.disconnect(); ctx=self.tls_context(); ftp=ftplib.FTP_TLS(context=ctx); ftp.connect(h,fp,timeout=15); ftp.login(u,pw); ftp.prot_p(); ftp.set_pasv(True)
            raw=socket.create_connection((h,cp),15); sock=ctx.wrap_socket(raw,server_hostname=h if getattr(ctx,'check_hostname',False) else None); w=sock.makefile('w',encoding='utf-8',newline='\n'); w.write(json.dumps({'username':u,'password':pw,'icon':self.icon_data})+'\n'); w.flush(); self.ftp,self.sock,self.writer=ftp,sock,w; self.events.put(('connected',None)); threading.Thread(target=self.reader,args=(sock,),daemon=True).start()
        except Exception as e: self.disconnect(); self.events.put(('error',str(e)))
    def reader(self,s):
        try:
            for line in s.makefile('r',encoding='utf-8'):
                try:self.events.put(('chat',json.loads(line)))
                except Exception:pass
        except Exception as e:self.events.put(('status','Chat disconnected: '+str(e)))
    def poll(self):
        try:
            while True:
                k,d=self.events.get_nowait()
                if k=='connected': self.status.set('Connected with TLS'); self.remote='/'; self.refresh()
                elif k=='error': self.status.set('Disconnected'); messagebox.showerror('Connection',d)
                elif k=='status': self.status.set(d)
                else:self.show_chat(d)
        except queue.Empty:pass
        self.after(100,self.poll)
    def photo(self,data,key):
        if not data or Image is None or ImageTk is None:return None
        try:
            raw=base64.b64decode(data); im=Image.open(io.BytesIO(raw)).convert('RGBA'); im.thumbnail((32,32)); ph=ImageTk.PhotoImage(im); self.photos[key]=ph; return ph
        except Exception:return None
    def show_chat(self,m):
        if m.get('type')=='roster':
            self.roster.delete(0,'end')
            for x in m.get('users',[]): self.roster.insert('end',('[icon] ' if x.get('icon') else '')+x.get('username',''))
            return
        self.log.config(state='normal')
        if m.get('type')=='message':
            key=str(m.get('username',''))+':'+str(len(self.photos)); ph=self.photo(m.get('icon',''),key)
            if ph:self.log.image_create('end',image=ph);self.log.insert('end',' ')
            self.log.insert('end',str(m.get('username',''))+': '+str(m.get('text',''))+'\n')
        else:self.log.insert('end','*** '+str(m.get('text',''))+'\n')
        self.log.see('end'); self.log.config(state='disabled')
    def task(self,fn):
        if not self.ftp:return messagebox.showwarning('FTPS','Connect first')
        def run():
            try:fn()
            except Exception as e:self.events.put(('error',str(e)))
        threading.Thread(target=run,daemon=True).start()
    def refresh(self):
        def work():
            self.ftp.cwd(self.remote); rows=[]
            if not self.legacy.get():
                try:
                    for n,f in self.ftp.mlsd():
                        if n not in ('.','..'):rows.append((n,f.get('type','file'),f.get('size','')))
                except Exception:
                    self.legacy.set(True)
            if self.legacy.get() and not rows:
                names=self.ftp.nlst()
                for n in names:
                    if n in ('.','..'): continue
                    isdir=False; size=''
                    here=self.ftp.pwd()
                    try: self.ftp.cwd(n); isdir=True; self.ftp.cwd(here)
                    except Exception:
                        try: size=str(self.ftp.size(n) or '')
                        except Exception: pass
                    rows.append((n,'dir' if isdir else 'file',size))
            self.after(0,lambda:self.render(rows))
        self.task(work)
    def render(self,rows):
        self.tree.delete(*self.tree.get_children()); self.path.config(text=self.remote)
        for n,t,s in sorted(rows,key=lambda x:(x[1]!='dir',x[0].lower())):self.tree.insert('', 'end',text=n,values=('Folder' if t=='dir' else 'File',s if t!='dir' else ''))
    def sel(self):
        x=self.tree.selection()
        if not x:return None
        v=self.tree.item(x[0]); return v['text'],v['values'][0]
    def open_folder(self):
        x=self.sel()
        if x and x[1]=='Folder': self.remote=(self.remote.rstrip('/')+'/'+x[0]); self.refresh()
    def up(self):
        if self.remote!='/': self.remote=self.remote.rsplit('/',1)[0] or '/'; self.refresh()
    def upload(self):
        p=filedialog.askopenfilename()
        if p:
            def work():
                self.ftp.cwd(self.remote)
                with open(p,'rb') as f:self.ftp.storbinary('STOR '+p.replace('\\','/').split('/')[-1],f)
                self.after(0,self.refresh)
            self.task(work)
    def download(self):
        x=self.sel()
        if x and x[1]=='File':
            p=filedialog.asksaveasfilename(initialfile=x[0])
            if p:
                def work():
                    self.ftp.cwd(self.remote)
                    with open(p,'wb') as f:self.ftp.retrbinary('RETR '+x[0],f.write)
                self.task(work)
    def mkdir(self):
        try: from tkinter import simpledialog
        except ImportError: import tkSimpleDialog as simpledialog
        n=simpledialog.askstring('Folder','Folder name:')
        if n:self.task(lambda:(self.ftp.cwd(self.remote),self.ftp.mkd(n),self.after(0,self.refresh)))
    def delete(self):
        x=self.sel()
        if x and messagebox.askyesno('Delete',x[0]):self.task(lambda:(self.ftp.cwd(self.remote),self.ftp.rmd(x[0]) if x[1]=='Folder' else self.ftp.delete(x[0]),self.after(0,self.refresh)))
    def send(self):
        t=self.msg.get().strip()
        if t and self.writer:self.writer.write(json.dumps({'type':'message','text':t})+'\n'); self.writer.flush(); self.msg.set('')
    def disconnect_ui(self):self.disconnect();self.status.set('Disconnected')
    def disconnect(self):
        for x in (self.writer,self.sock,self.ftp):
            try:
                if x:x.close()
            except Exception:pass
        self.writer=self.sock=self.ftp=None
    def close(self):self.disconnect();self.destroy()
if __name__=='__main__':App().mainloop()
