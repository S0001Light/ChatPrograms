import socket
import threading


# ============================================================
# CONFIGURATION
# ============================================================

SERVER_HOST = "0.0.0.0"
SERVER_PORT = 5000

# This client layout supports one local and one remote camera.
MAX_CLIENTS = 2

MAX_PACKET_SIZE = 2_000_000


# ============================================================
# CLIENT STORAGE
# ============================================================

clients = []
clients_lock = threading.Lock()

# Multiple client threads might try sending to the same socket.
# Each client socket gets its own sending lock.
client_send_locks = {}


# ============================================================
# NETWORK HELPERS
# ============================================================

def recv_exact(connection, byte_count):
    """
    Receive exactly byte_count bytes.

    TCP recv() may return fewer bytes than requested, so this
    function continues reading until the whole packet section
    has arrived.
    """

    data = bytearray()

    while len(data) < byte_count:
        chunk = connection.recv(
            byte_count - len(data)
        )

        if not chunk:
            raise ConnectionError(
                "Connection closed"
            )

        data.extend(chunk)

    return bytes(data)


def make_packet(packet_type, payload):
    return (
        packet_type
        + len(payload).to_bytes(4, "big")
        + payload
    )


# ============================================================
# BROADCASTING
# ============================================================

def broadcast(packet, sender):
    """
    Send a complete packet to every client except the sender.
    """

    dead_clients = []

    with clients_lock:
        target_clients = list(clients)

    for target in target_clients:
        if target is sender:
            continue

        send_lock = client_send_locks.get(target)

        if send_lock is None:
            continue

        try:
            with send_lock:
                target.sendall(packet)

        except (
            OSError,
            ConnectionError,
            ConnectionResetError,
            BrokenPipeError
        ):
            dead_clients.append(target)

    for target in dead_clients:
        remove_client(target)


# ============================================================
# CLIENT REMOVAL
# ============================================================

def remove_client(connection):
    removed = False

    with clients_lock:
        if connection in clients:
            clients.remove(connection)
            removed = True

        client_send_locks.pop(
            connection,
            None
        )

    try:
        connection.shutdown(
            socket.SHUT_RDWR
        )
    except OSError:
        pass

    try:
        connection.close()
    except OSError:
        pass

    if removed:
        print(
            "Client disconnected. "
            f"Connected clients: {client_count()}"
        )


def client_count():
    with clients_lock:
        return len(clients)


# ============================================================
# CLIENT THREAD
# ============================================================

def handle_client(connection, address):
    print(
        f"Client connected: {address}"
    )

    try:
        while True:
            # Packet header:
            # 1 byte packet type
            # 4 bytes payload length
            header = recv_exact(
                connection,
                5
            )

            packet_type = header[:1]

            payload_length = int.from_bytes(
                header[1:5],
                "big"
            )

            if payload_length < 0:
                raise ValueError(
                    "Invalid packet size"
                )

            if payload_length > MAX_PACKET_SIZE:
                raise ValueError(
                    f"Packet too large: {payload_length}"
                )

            payload = recv_exact(
                connection,
                payload_length
            )

            # Accept only supported packet types.
            if packet_type not in (
                b"T",
                b"V",
                b"U"
            ):
                print(
                    f"Unknown packet type "
                    f"from {address}: {packet_type!r}"
                )

                continue

            packet = make_packet(
                packet_type,
                payload
            )

            broadcast(
                packet,
                connection
            )

    except (
        OSError,
        ConnectionError,
        ConnectionResetError,
        BrokenPipeError
    ):
        pass

    except ValueError as error:
        print(
            f"Invalid packet from "
            f"{address}: {error}"
        )

    except Exception as error:
        print(
            f"Unexpected client error "
            f"from {address}: {error}"
        )

    finally:
        remove_client(connection)


# ============================================================
# MAIN SERVER
# ============================================================

def main():
    server_socket = socket.socket(
        socket.AF_INET,
        socket.SOCK_STREAM
    )

    server_socket.setsockopt(
        socket.SOL_SOCKET,
        socket.SO_REUSEADDR,
        1
    )

    server_socket.bind(
        (SERVER_HOST, SERVER_PORT)
    )

    server_socket.listen(
        MAX_CLIENTS
    )

    print("=" * 55)
    print("Pygame Video Chat Server")
    print(
        f"Listening on "
        f"{SERVER_HOST}:{SERVER_PORT}"
    )
    print(
        f"Maximum clients: {MAX_CLIENTS}"
    )
    print("=" * 55)

    try:
        while True:
            connection, address = (
                server_socket.accept()
            )

            connection.setsockopt(
                socket.IPPROTO_TCP,
                socket.TCP_NODELAY,
                1
            )

            with clients_lock:
                if len(clients) >= MAX_CLIENTS:
                    try:
                        message = (
                            b"Server is full. "
                            b"Maximum two clients."
                        )

                        connection.sendall(
                            make_packet(
                                b"E",
                                message
                            )
                        )

                    except OSError:
                        pass

                    connection.close()

                    print(
                        f"Rejected {address}: "
                        f"server is full"
                    )

                    continue

                clients.append(connection)

                client_send_locks[
                    connection
                ] = threading.Lock()

            thread = threading.Thread(
                target=handle_client,
                args=(
                    connection,
                    address
                ),
                daemon=True
            )

            thread.start()

    except KeyboardInterrupt:
        print(
            "\nStopping server..."
        )

    finally:
        with clients_lock:
            remaining_clients = list(
                clients
            )

        for connection in remaining_clients:
            remove_client(connection)

        try:
            server_socket.close()
        except OSError:
            pass

        print("Server stopped.")


if __name__ == "__main__":
    main()
