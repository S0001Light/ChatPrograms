param(
    [int]$Port = 2323
)

$ErrorActionPreference = 'Stop'
$clients = [hashtable]::Synchronized(@{})
$workers = New-Object System.Collections.ArrayList
$listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Any, $Port)

function Show-Banner {
    Clear-Host
    Write-Host '+====================================================+' -ForegroundColor Cyan
    Write-Host '|                 DOS CHAT SERVER                  |' -ForegroundColor Cyan
    Write-Host '+====================================================+' -ForegroundColor Cyan
    Write-Host (" Listening on TCP port {0}" -f $Port) -ForegroundColor Green
    Write-Host ' Press Ctrl+C to stop.' -ForegroundColor DarkGray
    Write-Host
}

$workerCode = {
    param($tcp, $clients)

    function Send-JsonLine($entry, $object) {
        $line = $object | ConvertTo-Json -Compress -Depth 8
        [Threading.Monitor]::Enter($entry.Sync)
        try { $entry.Writer.WriteLine($line); $entry.Writer.Flush() }
        finally { [Threading.Monitor]::Exit($entry.Sync) }
    }

    function Send-ToAll($object, $exceptId = $null) {
        foreach ($key in @($clients.Keys)) {
            if ($key -eq $exceptId) { continue }
            $entry = $clients[$key]
            if ($null -ne $entry) {
                try { Send-JsonLine $entry $object } catch { }
            }
        }
    }

    function Send-ToTarget($object, $target, $senderId) {
        if ([string]::IsNullOrWhiteSpace($target) -or $target -eq '*') {
            Send-ToAll $object $senderId
            return
        }
        foreach ($key in @($clients.Keys)) {
            $entry = $clients[$key]
            if ($null -ne $entry -and $entry.Name -ieq $target) {
                try { Send-JsonLine $entry $object } catch { }
                return
            }
        }
        $sender = $clients[$senderId]
        if ($null -ne $sender) {
            Send-JsonLine $sender @{ type='system'; text=("User not found: {0}" -f $target) }
        }
    }

    $id = [guid]::NewGuid().ToString('N')
    $stream = $tcp.GetStream()
    $reader = [IO.StreamReader]::new($stream, [Text.Encoding]::UTF8)
    $writer = [IO.StreamWriter]::new($stream, [Text.UTF8Encoding]::new($false))
    $writer.AutoFlush = $true
    $entry = [pscustomobject]@{ Name=('Guest-' + $id.Substring(0,4)); Writer=$writer; Sync=(New-Object object) }
    $clients[$id] = $entry

    try {
        Send-JsonLine $entry @{ type='welcome'; id=$id; text='Connected to DOS CHAT. Use /help for commands.' }
        while ($tcp.Connected) {
            $line = $reader.ReadLine()
            if ($null -eq $line) { break }
            try { $msg = $line | ConvertFrom-Json } catch { continue }

            switch ($msg.type) {
                'hello' {
                    $wanted = ([string]$msg.name -replace '[^A-Za-z0-9_.-]','').Trim()
                    if ([string]::IsNullOrWhiteSpace($wanted)) { $wanted = $entry.Name }
                    $old = $entry.Name
                    $entry.Name = $wanted.Substring(0, [Math]::Min(20, $wanted.Length))
                    Send-ToAll @{ type='system'; text=("{0} joined the chat." -f $entry.Name) } $null
                }
                'chat' {
                    $text = [string]$msg.text
                    if ($text.Length -gt 2000) { $text = $text.Substring(0,2000) }
                    Send-ToAll @{ type='chat'; from=$entry.Name; text=$text; time=(Get-Date).ToString('HH:mm:ss') } $null
                }
                'private' {
                    Send-ToTarget @{ type='private'; from=$entry.Name; text=[string]$msg.text; time=(Get-Date).ToString('HH:mm:ss') } ([string]$msg.target) $id
                }
                'users' {
                    $names = @($clients.Values | ForEach-Object { $_.Name } | Sort-Object)
                    Send-JsonLine $entry @{ type='users'; users=$names }
                }
                'file_start' {
                    Send-ToTarget @{ type='file_start'; from=$entry.Name; target=$msg.target; id=$msg.id; name=$msg.name; size=$msg.size } ([string]$msg.target) $id
                }
                'file_chunk' {
                    Send-ToTarget @{ type='file_chunk'; from=$entry.Name; target=$msg.target; id=$msg.id; data=$msg.data } ([string]$msg.target) $id
                }
                'file_end' {
                    Send-ToTarget @{ type='file_end'; from=$entry.Name; target=$msg.target; id=$msg.id; name=$msg.name } ([string]$msg.target) $id
                }
                'quit' { break }
            }
            if ($msg.type -eq 'quit') { break }
        }
    }
    catch { }
    finally {
        $name = $entry.Name
        $null = $clients.Remove($id)
        try { $reader.Dispose() } catch { }
        try { $writer.Dispose() } catch { }
        try { $tcp.Close() } catch { }
        Send-ToAll @{ type='system'; text=("{0} left the chat." -f $name) } $null
    }
}

Show-Banner
try {
    $listener.Start()
    while ($true) {
        while ($listener.Pending()) {
            $tcp = $listener.AcceptTcpClient()
            $runspace = [RunspaceFactory]::CreateRunspace()
            $runspace.Open()
            $ps = [PowerShell]::Create()
            $ps.Runspace = $runspace
            $null = $ps.AddScript($workerCode).AddArgument($tcp).AddArgument($clients)
            $handle = $ps.BeginInvoke()
            $null = $workers.Add([pscustomobject]@{ PowerShell=$ps; Runspace=$runspace; Handle=$handle })
            Write-Host ("[{0}] Connection from {1}" -f (Get-Date -Format HH:mm:ss), $tcp.Client.RemoteEndPoint) -ForegroundColor Yellow
        }

        foreach ($w in @($workers)) {
            if ($w.Handle.IsCompleted) {
                try { $w.PowerShell.EndInvoke($w.Handle) } catch { }
                $w.PowerShell.Dispose(); $w.Runspace.Dispose()
                $workers.Remove($w)
            }
        }
        Start-Sleep -Milliseconds 100
    }
}
finally {
    $listener.Stop()
    foreach ($w in @($workers)) { try { $w.PowerShell.Stop(); $w.PowerShell.Dispose(); $w.Runspace.Dispose() } catch { } }
}
