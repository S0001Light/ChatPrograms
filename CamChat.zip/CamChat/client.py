import json
import socket
import threading
import time

import cv2
import numpy as np
import pygame


# ============================================================
# CONFIGURATION
# ============================================================

WIDTH = 1280
HEIGHT = 720

SERVER_IP = "192.168.1.72"
SERVER_PORT = 5000

CAMERA_INDEX = 0

# Display size for each camera.
CAMERA_DISPLAY_WIDTH = 160
CAMERA_DISPLAY_HEIGHT = 90

CAMERA_MARGIN = 10

# Network transmission settings.
VIDEO_SEND_WIDTH = 320
VIDEO_SEND_HEIGHT = 180

VIDEO_SEND_FPS = 10
JPEG_QUALITY = 40

MAX_CHAT_LENGTH = 500


# ============================================================
# PYGAME INITIALIZATION
# ============================================================

pygame.init()

screen = pygame.display.set_mode(
    (WIDTH, HEIGHT)
)

pygame.display.set_caption(
    "Pygame Video Chat"
)

clock = pygame.time.Clock()

font = pygame.font.SysFont(
    "consolas",
    20
)

small_font = pygame.font.SysFont(
    "consolas",
    15
)


# ============================================================
# THEME
# ============================================================

theme = {
    "bg": (30, 30, 30),
    "panel": (37, 37, 37),
    "border": (58, 58, 58),
    "text": (237, 237, 237),
    "muted": (160, 160, 160),
    "accent": (0, 174, 239),
    "input_bg": (45, 45, 45),
    "input_border": (90, 90, 90),
    "error": (255, 90, 90),
    "black": (0, 0, 0)
}


# ============================================================
# USER INFORMATION
# ============================================================

username = "Shawn"
icon_color = (0, 200, 255)

remote_username = ""
remote_icon_color = (200, 200, 200)


# ============================================================
# APPLICATION STATE
# ============================================================

chat_log = []
chat_lock = threading.Lock()

current_input = ""

cursor_visible = True
last_cursor_toggle = time.time()
cursor_interval = 0.5

mode = "chat"

settings_input = ""
color_input = ""

focused_field = "chat"

remote_frame = None
remote_frame_lock = threading.Lock()

running = True
connected = False

send_lock = threading.Lock()

last_video_send = 0.0


# ============================================================
# CHAT HELPERS
# ============================================================

def add_chat_message(message):
    with chat_lock:
        chat_log.append(message)

        if len(chat_log) > 200:
            del chat_log[:-200]


def wrap_text(
    text,
    selected_font,
    maximum_width
):
    if not text:
        return [""]

    words = text.split(" ")

    lines = []
    current_line = ""

    for word in words:
        if current_line:
            test_line = (
                current_line
                + " "
                + word
            )
        else:
            test_line = word

        if (
            selected_font.size(
                test_line
            )[0]
            <= maximum_width
        ):
            current_line = test_line

        else:
            if current_line:
                lines.append(
                    current_line
                )

            current_line = word

    if current_line:
        lines.append(current_line)

    return lines or [""]


# ============================================================
# CAMERA OPENING
# ============================================================

def open_camera():
    """
    Search indexes 0 through 4 using common Windows backends.
    """

    backends = [
        (
            "DirectShow",
            cv2.CAP_DSHOW
        ),
        (
            "Media Foundation",
            cv2.CAP_MSMF
        ),
        (
            "Automatic",
            cv2.CAP_ANY
        )
    ]

    indexes = [CAMERA_INDEX]

    for camera_index in range(5):
        if camera_index not in indexes:
            indexes.append(camera_index)

    for camera_index in indexes:
        for backend_name, backend in backends:
            print(
                f"Trying camera "
                f"{camera_index} using "
                f"{backend_name}..."
            )

            test_camera = cv2.VideoCapture(
                camera_index,
                backend
            )

            if not test_camera.isOpened():
                test_camera.release()
                continue

            test_camera.set(
                cv2.CAP_PROP_FRAME_WIDTH,
                VIDEO_SEND_WIDTH
            )

            test_camera.set(
                cv2.CAP_PROP_FRAME_HEIGHT,
                VIDEO_SEND_HEIGHT
            )

            test_camera.set(
                cv2.CAP_PROP_FPS,
                VIDEO_SEND_FPS
            )

            test_camera.set(
                cv2.CAP_PROP_BUFFERSIZE,
                1
            )

            for attempt in range(15):
                success, frame = (
                    test_camera.read()
                )

                if (
                    success
                    and frame is not None
                    and frame.size > 0
                ):
                    print(
                        "Camera opened: "
                        f"index {camera_index}, "
                        f"{backend_name}"
                    )

                    return test_camera

                time.sleep(0.05)

            test_camera.release()

    print(
        "No working camera was found."
    )

    return None


# ============================================================
# NETWORK HELPERS
# ============================================================

def recv_exact(connection, byte_count):
    data = bytearray()

    while len(data) < byte_count:
        chunk = connection.recv(
            byte_count - len(data)
        )

        if not chunk:
            raise ConnectionError(
                "Server closed the connection"
            )

        data.extend(chunk)

    return bytes(data)


def send_packet(packet_type, payload=b""):
    global connected

    if not connected:
        return False

    packet = (
        packet_type
        + len(payload).to_bytes(
            4,
            "big"
        )
        + payload
    )

    try:
        with send_lock:
            sock.sendall(packet)

        return True

    except (
        OSError,
        ConnectionError,
        ConnectionResetError,
        BrokenPipeError
    ) as error:
        print(
            f"Send failed: {error}"
        )

        connected = False

        return False


# ============================================================
# SEND DATA
# ============================================================

def send_text(message):
    message = message.strip()

    if not message:
        return

    message = message[:MAX_CHAT_LENGTH]

    send_packet(
        b"T",
        message.encode("utf-8")
    )


def send_userinfo():
    information = {
        "username": username,
        "icon_color": list(icon_color)
    }

    payload = json.dumps(
        information
    ).encode("utf-8")

    send_packet(
        b"U",
        payload
    )


def send_video(frame):
    """
    Resize before compression to reduce network bandwidth.
    """

    reduced_frame = cv2.resize(
        frame,
        (
            VIDEO_SEND_WIDTH,
            VIDEO_SEND_HEIGHT
        ),
        interpolation=cv2.INTER_AREA
    )

    success, jpeg = cv2.imencode(
        ".jpg",
        reduced_frame,
        [
            cv2.IMWRITE_JPEG_QUALITY,
            JPEG_QUALITY
        ]
    )

    if not success:
        return

    send_packet(
        b"V",
        jpeg.tobytes()
    )


# ============================================================
# NETWORK RECEIVER THREAD
# ============================================================

def network_thread():
    global connected
    global remote_frame
    global remote_username
    global remote_icon_color

    try:
        while connected:
            header = recv_exact(
                sock,
                5
            )

            packet_type = header[:1]

            payload_length = int.from_bytes(
                header[1:5],
                "big"
            )

            if payload_length > 2_000_000:
                raise ValueError(
                    "Incoming packet is too large"
                )

            payload = recv_exact(
                sock,
                payload_length
            )

            # ------------------------------------------------
            # TEXT
            # ------------------------------------------------

            if packet_type == b"T":
                message = payload.decode(
                    "utf-8",
                    errors="replace"
                )

                add_chat_message(message)

            # ------------------------------------------------
            # VIDEO
            # ------------------------------------------------

            elif packet_type == b"V":
                jpeg_array = np.frombuffer(
                    payload,
                    dtype=np.uint8
                )

                decoded_frame = cv2.imdecode(
                    jpeg_array,
                    cv2.IMREAD_COLOR
                )

                if decoded_frame is not None:
                    with remote_frame_lock:
                        remote_frame = (
                            decoded_frame
                        )

            # ------------------------------------------------
            # USER INFORMATION
            # ------------------------------------------------

            elif packet_type == b"U":
                information = json.loads(
                    payload.decode("utf-8")
                )

                remote_username = str(
                    information.get(
                        "username",
                        "Remote"
                    )
                )[:24]

                color = information.get(
                    "icon_color",
                    [200, 200, 200]
                )

                try:
                    remote_icon_color = (
                        max(
                            0,
                            min(255, int(color[0]))
                        ),
                        max(
                            0,
                            min(255, int(color[1]))
                        ),
                        max(
                            0,
                            min(255, int(color[2]))
                        )
                    )

                except (
                    TypeError,
                    ValueError,
                    IndexError
                ):
                    remote_icon_color = (
                        200,
                        200,
                        200
                    )

            # ------------------------------------------------
            # SERVER ERROR
            # ------------------------------------------------

            elif packet_type == b"E":
                error_message = payload.decode(
                    "utf-8",
                    errors="replace"
                )

                add_chat_message(
                    "System: " + error_message
                )

                connected = False

    except (
        OSError,
        ConnectionError,
        ConnectionResetError,
        BrokenPipeError,
        ValueError,
        json.JSONDecodeError
    ) as error:
        print(
            f"Network connection ended: "
            f"{error}"
        )

    finally:
        connected = False

        add_chat_message(
            "System: Disconnected from server"
        )


# ============================================================
# FRAME TO PYGAME SURFACE
# ============================================================

def frame_to_surface(
    frame,
    width,
    height
):
    rgb_frame = cv2.cvtColor(
        frame,
        cv2.COLOR_BGR2RGB
    )

    resized_frame = cv2.resize(
        rgb_frame,
        (width, height),
        interpolation=cv2.INTER_AREA
    )

    surface = pygame.image.frombuffer(
        resized_frame.tobytes(),
        (width, height),
        "RGB"
    ).copy()

    return surface


# ============================================================
# DRAW CHAT
# ============================================================

def draw_chat():
    global cursor_visible
    global last_cursor_toggle

    panel = pygame.Rect(
        WIDTH - 350,
        0,
        350,
        HEIGHT
    )

    pygame.draw.rect(
        screen,
        theme["panel"],
        panel
    )

    pygame.draw.rect(
        screen,
        theme["border"],
        panel,
        1
    )

    if connected:
        status_text = "Connected"
        status_color = theme["accent"]
    else:
        status_text = "Disconnected"
        status_color = theme["error"]

    status_surface = small_font.render(
        status_text,
        True,
        status_color
    )

    screen.blit(
        status_surface,
        (panel.x + 10, 10)
    )

    input_box = pygame.Rect(
        panel.x + 10,
        HEIGHT - 45,
        330,
        35
    )

    chat_top = 38
    chat_bottom = input_box.y - 8
    line_height = 20

    with chat_lock:
        messages = list(chat_log)

    lines = []

    for message in messages:
        wrapped = wrap_text(
            message,
            small_font,
            panel.width - 20
        )

        lines.extend(wrapped)

    maximum_lines = max(
        1,
        (
            chat_bottom - chat_top
        ) // line_height
    )

    lines = lines[-maximum_lines:]

    y = chat_top

    for line in lines:
        surface = small_font.render(
            line,
            True,
            theme["text"]
        )

        screen.blit(
            surface,
            (panel.x + 10, y)
        )

        y += line_height

    pygame.draw.rect(
        screen,
        theme["input_bg"],
        input_box
    )

    pygame.draw.rect(
        screen,
        theme["input_border"],
        input_box,
        1
    )

    displayed_input = current_input

    while (
        displayed_input
        and font.size(displayed_input)[0]
        > input_box.width - 14
    ):
        displayed_input = (
            displayed_input[1:]
        )

    text_surface = font.render(
        displayed_input,
        True,
        theme["text"]
    )

    screen.blit(
        text_surface,
        (
            input_box.x + 5,
            input_box.y + 7
        )
    )

    if (
        time.time() - last_cursor_toggle
        > cursor_interval
    ):
        cursor_visible = not cursor_visible

        last_cursor_toggle = time.time()

    if (
        cursor_visible
        and mode == "chat"
    ):
        cursor_x = (
            input_box.x
            + 5
            + text_surface.get_width()
            + 2
        )

        pygame.draw.line(
            screen,
            theme["accent"],
            (
                cursor_x,
                input_box.y + 6
            ),
            (
                cursor_x,
                input_box.bottom - 6
            ),
            2
        )


# ============================================================
# DRAW VIDEO
# ============================================================

def draw_video(local_frame):
    local_box = pygame.Rect(
        CAMERA_MARGIN,
        CAMERA_MARGIN,
        CAMERA_DISPLAY_WIDTH,
        CAMERA_DISPLAY_HEIGHT
    )

    remote_box = pygame.Rect(
        CAMERA_MARGIN
        + CAMERA_DISPLAY_WIDTH
        + 10,
        CAMERA_MARGIN,
        CAMERA_DISPLAY_WIDTH,
        CAMERA_DISPLAY_HEIGHT
    )

    # Local camera border.
    pygame.draw.rect(
        screen,
        theme["border"],
        local_box.inflate(4, 4)
    )

    if local_frame is not None:
        local_surface = frame_to_surface(
            local_frame,
            CAMERA_DISPLAY_WIDTH,
            CAMERA_DISPLAY_HEIGHT
        )

        screen.blit(
            local_surface,
            local_box
        )

    else:
        pygame.draw.rect(
            screen,
            theme["panel"],
            local_box
        )

        label = small_font.render(
            "No local camera",
            True,
            theme["muted"]
        )

        screen.blit(
            label,
            label.get_rect(
                center=local_box.center
            )
        )

    # Remote camera border.
    pygame.draw.rect(
        screen,
        theme["border"],
        remote_box.inflate(4, 4)
    )

    with remote_frame_lock:
        frame_copy = (
            None
            if remote_frame is None
            else remote_frame.copy()
        )

    if frame_copy is not None:
        remote_surface = frame_to_surface(
            frame_copy,
            CAMERA_DISPLAY_WIDTH,
            CAMERA_DISPLAY_HEIGHT
        )

        screen.blit(
            remote_surface,
            remote_box
        )

    else:
        pygame.draw.rect(
            screen,
            theme["panel"],
            remote_box
        )

        label = small_font.render(
            "Waiting for remote",
            True,
            theme["muted"]
        )

        screen.blit(
            label,
            label.get_rect(
                center=remote_box.center
            )
        )


# ============================================================
# DRAW USER LABELS
# ============================================================

def draw_local_icon():
    x = 20
    y = 120

    pygame.draw.circle(
        screen,
        icon_color,
        (x, y),
        8
    )

    name_surface = font.render(
        username,
        True,
        theme["text"]
    )

    screen.blit(
        name_surface,
        (x + 15, y - 10)
    )


def draw_remote_icon():
    x = (
        CAMERA_MARGIN
        + CAMERA_DISPLAY_WIDTH
        + 20
    )

    y = 120

    pygame.draw.circle(
        screen,
        remote_icon_color,
        (x, y),
        8
    )

    display_name = (
        remote_username
        if remote_username
        else "Remote"
    )

    name_surface = font.render(
        display_name,
        True,
        theme["text"]
    )

    screen.blit(
        name_surface,
        (x + 15, y - 10)
    )


# ============================================================
# SETTINGS
# ============================================================

def draw_settings():
    screen.fill(
        theme["bg"]
    )

    title = font.render(
        "Settings",
        True,
        theme["text"]
    )

    screen.blit(
        title,
        (50, 40)
    )

    username_label = font.render(
        "Username:",
        True,
        theme["text"]
    )

    screen.blit(
        username_label,
        (50, 100)
    )

    username_box = pygame.Rect(
        50,
        130,
        300,
        35
    )

    pygame.draw.rect(
        screen,
        theme["input_bg"],
        username_box
    )

    username_border = (
        theme["accent"]
        if focused_field
        == "settings_username"
        else theme["input_border"]
    )

    pygame.draw.rect(
        screen,
        username_border,
        username_box,
        1
    )

    username_text = font.render(
        settings_input or username,
        True,
        theme["text"]
    )

    screen.blit(
        username_text,
        (
            username_box.x + 5,
            username_box.y + 7
        )
    )

    color_label = font.render(
        "Icon color (R,G,B):",
        True,
        theme["text"]
    )

    screen.blit(
        color_label,
        (50, 190)
    )

    color_box = pygame.Rect(
        50,
        220,
        300,
        35
    )

    pygame.draw.rect(
        screen,
        theme["input_bg"],
        color_box
    )

    color_border = (
        theme["accent"]
        if focused_field
        == "settings_color"
        else theme["input_border"]
    )

    pygame.draw.rect(
        screen,
        color_border,
        color_box,
        1
    )

    color_value = (
        color_input
        or (
            f"{icon_color[0]},"
            f"{icon_color[1]},"
            f"{icon_color[2]}"
        )
    )

    color_text_surface = font.render(
        color_value,
        True,
        theme["text"]
    )

    screen.blit(
        color_text_surface,
        (
            color_box.x + 5,
            color_box.y + 7
        )
    )

    pygame.draw.circle(
        screen,
        icon_color,
        (400, 150),
        25
    )

    preview_label = small_font.render(
        "Icon preview",
        True,
        theme["text"]
    )

    screen.blit(
        preview_label,
        (360, 190)
    )

    save_button = pygame.Rect(
        50,
        280,
        120,
        35
    )

    pygame.draw.rect(
        screen,
        theme["accent"],
        save_button
    )

    save_text = font.render(
        "Save",
        True,
        theme["black"]
    )

    screen.blit(
        save_text,
        save_text.get_rect(
            center=save_button.center
        )
    )

    back_button = pygame.Rect(
        190,
        280,
        120,
        35
    )

    pygame.draw.rect(
        screen,
        theme["panel"],
        back_button
    )

    pygame.draw.rect(
        screen,
        theme["border"],
        back_button,
        1
    )

    back_text = font.render(
        "Back",
        True,
        theme["text"]
    )

    screen.blit(
        back_text,
        back_text.get_rect(
            center=back_button.center
        )
    )

    return (
        save_button,
        back_button,
        username_box,
        color_box
    )


def apply_settings():
    global username
    global icon_color
    global settings_input
    global color_input

    if settings_input.strip():
        username = (
            settings_input.strip()[:24]
        )

    settings_input = ""

    if color_input.strip():
        try:
            parts = color_input.split(",")

            if len(parts) != 3:
                raise ValueError(
                    "RGB needs three values"
                )

            red, green, blue = [
                max(
                    0,
                    min(255, int(part.strip()))
                )
                for part in parts
            ]

            icon_color = (
                red,
                green,
                blue
            )

        except ValueError:
            add_chat_message(
                "System: Invalid RGB color"
            )

    color_input = ""

    if connected:
        send_userinfo()


# ============================================================
# SHOW STARTUP WINDOW
# ============================================================

screen.fill(
    theme["bg"]
)

startup_surface = font.render(
    "Starting video chat...",
    True,
    theme["text"]
)

screen.blit(
    startup_surface,
    startup_surface.get_rect(
        center=(
            WIDTH // 2,
            HEIGHT // 2
        )
    )
)

pygame.display.flip()
pygame.event.pump()


# ============================================================
# OPEN CAMERA
# ============================================================

camera = open_camera()


# ============================================================
# CONNECT TO SERVER
# ============================================================

sock = socket.socket(
    socket.AF_INET,
    socket.SOCK_STREAM
)

sock.setsockopt(
    socket.IPPROTO_TCP,
    socket.TCP_NODELAY,
    1
)

sock.settimeout(4.0)

try:
    print(
        f"Connecting to "
        f"{SERVER_IP}:{SERVER_PORT}..."
    )

    sock.connect(
        (SERVER_IP, SERVER_PORT)
    )

    sock.settimeout(None)

    connected = True

    print("Connected to server.")

except (
    socket.timeout,
    OSError
) as error:
    connected = False

    print(
        f"Connection failed: {error}"
    )

    add_chat_message(
        f"System: Connection failed: {error}"
    )


# ============================================================
# START NETWORK THREAD
# ============================================================

if connected:
    receiver = threading.Thread(
        target=network_thread,
        daemon=True
    )

    receiver.start()

    send_userinfo()


# ============================================================
# MAIN LOOP
# ============================================================

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.KEYDOWN:
            if mode == "chat":
                if event.key == pygame.K_ESCAPE:
                    mode = "settings"

                elif event.key == pygame.K_RETURN:
                    message = current_input.strip()

                    if message:
                        complete_message = (
                            f"{username}: {message}"
                        )

                        add_chat_message(
                            complete_message
                        )

                        if connected:
                            send_text(
                                complete_message
                            )

                        current_input = ""

                elif event.key == pygame.K_BACKSPACE:
                    current_input = (
                        current_input[:-1]
                    )

                elif (
                    event.unicode
                    and event.unicode.isprintable()
                    and len(current_input)
                    < MAX_CHAT_LENGTH
                ):
                    current_input += (
                        event.unicode
                    )

            elif mode == "settings":
                if event.key == pygame.K_ESCAPE:
                    mode = "chat"

                elif (
                    focused_field
                    == "settings_username"
                ):
                    if event.key == pygame.K_RETURN:
                        apply_settings()
                        mode = "chat"

                    elif event.key == pygame.K_BACKSPACE:
                        settings_input = (
                            settings_input[:-1]
                        )

                    elif (
                        event.unicode
                        and event.unicode.isprintable()
                        and len(settings_input) < 24
                    ):
                        settings_input += (
                            event.unicode
                        )

                elif (
                    focused_field
                    == "settings_color"
                ):
                    if event.key == pygame.K_RETURN:
                        apply_settings()
                        mode = "chat"

                    elif event.key == pygame.K_BACKSPACE:
                        color_input = (
                            color_input[:-1]
                        )

                    elif (
                        event.unicode
                        and event.unicode
                        in "0123456789,"
                        and len(color_input) < 11
                    ):
                        color_input += (
                            event.unicode
                        )

        elif (
            event.type
            == pygame.MOUSEBUTTONDOWN
            and mode == "settings"
        ):
            (
                save_button,
                back_button,
                username_box,
                color_box
            ) = draw_settings()

            if username_box.collidepoint(
                event.pos
            ):
                focused_field = (
                    "settings_username"
                )

                if not settings_input:
                    settings_input = username

            elif color_box.collidepoint(
                event.pos
            ):
                focused_field = (
                    "settings_color"
                )

                if not color_input:
                    color_input = (
                        f"{icon_color[0]},"
                        f"{icon_color[1]},"
                        f"{icon_color[2]}"
                    )

            elif save_button.collidepoint(
                event.pos
            ):
                apply_settings()
                mode = "chat"

            elif back_button.collidepoint(
                event.pos
            ):
                settings_input = ""
                color_input = ""
                mode = "chat"

    # --------------------------------------------------------
    # READ CAMERA
    # --------------------------------------------------------

    local_frame = None

    if camera is not None:
        success, frame = camera.read()

        if (
            success
            and frame is not None
            and frame.size > 0
        ):
            local_frame = frame

    # --------------------------------------------------------
    # SEND CAMERA AT A CONTROLLED RATE
    # --------------------------------------------------------

    current_time = time.monotonic()

    if (
        connected
        and local_frame is not None
        and current_time - last_video_send
        >= 1.0 / VIDEO_SEND_FPS
    ):
        send_video(local_frame)

        last_video_send = current_time

    # --------------------------------------------------------
    # DRAW
    # --------------------------------------------------------

    screen.fill(
        theme["bg"]
    )

    if mode == "chat":
        draw_video(local_frame)
        draw_chat()
        draw_local_icon()
        draw_remote_icon()

    else:
        draw_settings()

    pygame.display.flip()

    clock.tick(30)


# ============================================================
# SHUTDOWN
# ============================================================

connected = False

if camera is not None:
    camera.release()

try:
    sock.shutdown(
        socket.SHUT_RDWR
    )
except OSError:
    pass

try:
    sock.close()
except OSError:
    pass

pygame.quit()
