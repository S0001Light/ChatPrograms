import pygame
import cv2
import socket
import threading
import numpy as np
import json
import time
import os
import struct
import subprocess
import sys

import tkinter as tk
from tkinter import filedialog


# ============================================================
# CONFIGURATION
# ============================================================

WIDTH = 1280
HEIGHT = 720

CHAT_WIDTH = 350
CAMERA_AREA_WIDTH = WIDTH - CHAT_WIDTH

SERVER_IP = "192.168.1.72"

# Camera / chat
CHAT_PORT = 5000

# File server
FILE_PORT = 5001

MAX_USERS = 20

GRID_COLUMNS = 5
GRID_ROWS = 4

CAMERA_INDEX = 0

# Keep video small for 20-user rooms
SEND_WIDTH = 320
SEND_HEIGHT = 180

VIDEO_FPS = 8
JPEG_QUALITY = 35

MAX_MESSAGE_LENGTH = 500

FILE_BUFFER_SIZE = 64 * 1024
MAX_FILE_SIZE = 100 * 1024 * 1024


# ============================================================
# DIRECTORIES
# ============================================================

BASE_DIR = os.path.dirname(
    os.path.abspath(__file__)
)

DOWNLOAD_DIR = os.path.join(
    BASE_DIR,
    "downloads"
)

os.makedirs(
    DOWNLOAD_DIR,
    exist_ok=True
)


# ============================================================
# PYGAME
# ============================================================

pygame.init()

screen = pygame.display.set_mode(
    (WIDTH, HEIGHT)
)

pygame.display.set_caption(
    "CamBunches"
)

clock = pygame.time.Clock()

font = pygame.font.SysFont(
    "consolas",
    16
)

small_font = pygame.font.SysFont(
    "consolas",
    13
)

large_font = pygame.font.SysFont(
    "consolas",
    22
)


# ============================================================
# THEME
# ============================================================

theme = {
    "bg": (25, 25, 25),
    "panel": (37, 37, 37),
    "panel2": (42, 42, 42),

    "border": (70, 70, 70),

    "text": (237, 237, 237),
    "muted": (150, 150, 150),

    "accent": (0, 174, 239),
    "accent_hover": (30, 194, 255),

    "green": (70, 200, 100),
    "red": (255, 90, 90),

    "input_bg": (45, 45, 45),
    "input_border": (90, 90, 90),

    "black": (0, 0, 0)
}


# ============================================================
# LOCAL USER
# ============================================================

username = "Shawn"

icon_color = (
    0,
    200,
    255
)

my_id = None


# ============================================================
# APPLICATION STATE
# ============================================================

users = {}
users_lock = threading.Lock()

chat_log = []
chat_lock = threading.Lock()

current_input = ""

running = True
connected = False

send_lock = threading.Lock()

last_video_send = 0.0

# Screen modes:
#
# chat
# files

mode = "chat"


# ============================================================
# FILE SERVER STATE
# ============================================================

server_files = []
server_files_lock = threading.Lock()

file_status = ""

file_operation_running = False

file_scroll = 0


# ============================================================
# CHAT HELPERS
# ============================================================

def add_chat_message(
    user_id,
    message
):
    with chat_lock:

        chat_log.append(
            (
                user_id,
                message
            )
        )

        if len(chat_log) > 250:
            del chat_log[:-250]


def add_system_message(message):

    add_chat_message(
        0,
        message
    )


# ============================================================
# EXACT RECEIVE
# ============================================================

def recv_exact(
    sock,
    size
):
    data = bytearray()

    while len(data) < size:

        chunk = sock.recv(
            size - len(data)
        )

        if not chunk:

            raise ConnectionError(
                "Connection closed"
            )

        data.extend(
            chunk
        )

    return bytes(data)


# ============================================================
# CHAT NETWORK SEND
# ============================================================

def send_packet(
    packet_type,
    payload=b""
):
    global connected

    if not connected:
        return False

    packet = (
        packet_type
        + len(payload).to_bytes(
            4,
            "big"
        )
        + payload
    )

    try:

        with send_lock:

            chat_socket.sendall(
                packet
            )

        return True

    except (
        OSError,
        ConnectionError,
        BrokenPipeError
    ) as error:

        print(
            f"Send error: {error}"
        )

        connected = False

        return False


# ============================================================
# USER INFORMATION
# ============================================================

def send_userinfo():

    data = {
        "username": username,
        "icon_color": list(
            icon_color
        )
    }

    payload = json.dumps(
        data
    ).encode(
        "utf-8"
    )

    send_packet(
        b"U",
        payload
    )


# ============================================================
# TEXT
# ============================================================

def send_text(message):

    message = message.strip()

    if not message:
        return

    message = message[
        :MAX_MESSAGE_LENGTH
    ]

    send_packet(
        b"T",
        message.encode(
            "utf-8"
        )
    )


# ============================================================
# VIDEO
# ============================================================

def send_video(frame):

    small = cv2.resize(
        frame,
        (
            SEND_WIDTH,
            SEND_HEIGHT
        ),
        interpolation=cv2.INTER_AREA
    )

    success, jpeg = cv2.imencode(
        ".jpg",
        small,
        [
            cv2.IMWRITE_JPEG_QUALITY,
            JPEG_QUALITY
        ]
    )

    if not success:
        return

    send_packet(
        b"V",
        jpeg.tobytes()
    )


# ============================================================
# USER MANAGEMENT
# ============================================================

def create_default_user(
    user_id
):

    return {
        "username":
            f"User {user_id}",

        "icon_color":
            (200, 200, 200),

        "frame":
            None
    }


def update_user(
    user_id,
    new_username=None,
    new_color=None
):

    with users_lock:

        if user_id not in users:

            users[user_id] = (
                create_default_user(
                    user_id
                )
            )

        if new_username is not None:

            users[user_id][
                "username"
            ] = str(
                new_username
            )[:24]

        if new_color is not None:

            try:

                color = tuple(

                    max(
                        0,
                        min(
                            255,
                            int(value)
                        )
                    )

                    for value
                    in new_color[:3]
                )

                if len(color) == 3:

                    users[user_id][
                        "icon_color"
                    ] = color

            except (
                ValueError,
                TypeError
            ):
                pass


def update_user_frame(
    user_id,
    frame
):

    with users_lock:

        if user_id not in users:

            users[user_id] = (
                create_default_user(
                    user_id
                )
            )

        users[user_id][
            "frame"
        ] = frame


def remove_user(user_id):

    with users_lock:

        users.pop(
            user_id,
            None
        )


# ============================================================
# CHAT NETWORK RECEIVER
# ============================================================

def network_loop():

    global my_id
    global connected

    try:

        while connected:

            header = recv_exact(
                chat_socket,
                5
            )

            packet_type = (
                header[:1]
            )

            payload_length = (
                int.from_bytes(
                    header[1:5],
                    "big"
                )
            )

            if (
                payload_length
                > 2_000_000
            ):
                raise ValueError(
                    "Packet too large"
                )

            payload = recv_exact(
                chat_socket,
                payload_length
            )

            # =================================================
            # CLIENT ID
            # =================================================

            if packet_type == b"I":

                my_id = int.from_bytes(
                    payload,
                    "big"
                )

                update_user(
                    my_id,
                    username,
                    icon_color
                )

                send_userinfo()

                print(
                    "My client ID:",
                    my_id
                )

            # =================================================
            # ROSTER
            # =================================================

            elif packet_type == b"J":

                info = json.loads(
                    payload.decode(
                        "utf-8"
                    )
                )

                user_id = int(
                    info["id"]
                )

                update_user(
                    user_id,

                    info.get(
                        "username",
                        f"User {user_id}"
                    ),

                    info.get(
                        "icon_color",
                        [200, 200, 200]
                    )
                )

            # =================================================
            # USER INFO
            # =================================================

            elif packet_type == b"U":

                if len(payload) < 4:
                    continue

                user_id = (
                    int.from_bytes(
                        payload[:4],
                        "big"
                    )
                )

                information = (
                    json.loads(
                        payload[
                            4:
                        ].decode(
                            "utf-8"
                        )
                    )
                )

                update_user(
                    user_id,

                    information.get(
                        "username",
                        f"User {user_id}"
                    ),

                    information.get(
                        "icon_color",
                        [200, 200, 200]
                    )
                )

            # =================================================
            # CHAT
            # =================================================

            elif packet_type == b"T":

                if len(payload) < 4:
                    continue

                user_id = int.from_bytes(
                    payload[:4],
                    "big"
                )

                message = payload[
                    4:
                ].decode(
                    "utf-8",
                    errors="replace"
                )

                add_chat_message(
                    user_id,
                    message
                )

            # =================================================
            # VIDEO
            # =================================================

            elif packet_type == b"V":

                if len(payload) < 5:
                    continue

                user_id = (
                    int.from_bytes(
                        payload[:4],
                        "big"
                    )
                )

                jpeg_data = payload[4:]

                jpeg_array = (
                    np.frombuffer(
                        jpeg_data,
                        dtype=np.uint8
                    )
                )

                frame = cv2.imdecode(
                    jpeg_array,
                    cv2.IMREAD_COLOR
                )

                if frame is not None:

                    update_user_frame(
                        user_id,
                        frame
                    )

            # =================================================
            # USER LEFT
            # =================================================

            elif packet_type == b"L":

                if len(payload) < 4:
                    continue

                user_id = int.from_bytes(
                    payload[:4],
                    "big"
                )

                with users_lock:

                    old_name = users.get(
                        user_id,
                        {}
                    ).get(
                        "username",
                        f"User {user_id}"
                    )

                remove_user(
                    user_id
                )

                add_system_message(
                    old_name
                    + " disconnected"
                )

            # =================================================
            # ERROR
            # =================================================

            elif packet_type == b"E":

                message = payload.decode(
                    "utf-8",
                    errors="replace"
                )

                add_system_message(
                    message
                )

                connected = False

    except (
        OSError,
        ConnectionError,
        ValueError,
        json.JSONDecodeError
    ) as error:

        print(
            "Network ended:",
            error
        )

    finally:

        connected = False

        add_system_message(
            "Disconnected from server"
        )


# ============================================================
# CAMERA OPENING
# ============================================================

def open_camera():

    backends = [
        (
            "DirectShow",
            cv2.CAP_DSHOW
        ),

        (
            "Media Foundation",
            cv2.CAP_MSMF
        ),

        (
            "Automatic",
            cv2.CAP_ANY
        )
    ]

    camera_indexes = [
        CAMERA_INDEX
    ]

    for index in range(5):

        if index not in camera_indexes:

            camera_indexes.append(
                index
            )

    for index in camera_indexes:

        for (
            backend_name,
            backend
        ) in backends:

            print(
                f"Trying camera "
                f"{index} using "
                f"{backend_name}"
            )

            camera = (
                cv2.VideoCapture(
                    index,
                    backend
                )
            )

            if not camera.isOpened():

                camera.release()

                continue

            camera.set(
                cv2.CAP_PROP_FRAME_WIDTH,
                SEND_WIDTH
            )

            camera.set(
                cv2.CAP_PROP_FRAME_HEIGHT,
                SEND_HEIGHT
            )

            camera.set(
                cv2.CAP_PROP_FPS,
                VIDEO_FPS
            )

            camera.set(
                cv2.CAP_PROP_BUFFERSIZE,
                1
            )

            for attempt in range(10):

                success, frame = (
                    camera.read()
                )

                if (
                    success
                    and frame is not None
                    and frame.size > 0
                ):

                    print(
                        f"Camera opened: "
                        f"{index} "
                        f"{backend_name}"
                    )

                    return camera

                time.sleep(
                    0.05
                )

            camera.release()

    print(
        "No camera found."
    )

    return None


# ============================================================
# CONVERT CAMERA FRAME
# ============================================================

def frame_to_surface(
    frame,
    width,
    height
):

    rgb = cv2.cvtColor(
        frame,
        cv2.COLOR_BGR2RGB
    )

    frame_height, frame_width = (
        rgb.shape[:2]
    )

    scale = min(
        width / frame_width,
        height / frame_height
    )

    new_width = max(
        1,
        int(
            frame_width
            * scale
        )
    )

    new_height = max(
        1,
        int(
            frame_height
            * scale
        )
    )

    resized = cv2.resize(
        rgb,
        (
            new_width,
            new_height
        ),
        interpolation=cv2.INTER_AREA
    )

    surface = pygame.image.frombuffer(
        resized.tobytes(),
        (
            new_width,
            new_height
        ),
        "RGB"
    ).copy()

    return surface


# ============================================================
# TEXT WRAPPING
# ============================================================

def wrap_text(
    text,
    selected_font,
    maximum_width
):

    if not text:
        return [""]

    words = text.split(" ")

    output = []

    line = ""

    for word in words:

        test = (
            word
            if not line
            else line
            + " "
            + word
        )

        if (
            selected_font.size(
                test
            )[0]
            <= maximum_width
        ):

            line = test

        else:

            if line:
                output.append(
                    line
                )

            line = word

    if line:
        output.append(
            line
        )

    return output or [""]


# ============================================================
# DRAW ONE CAMERA
# ============================================================

def draw_camera_tile(
    rect,
    user_id,
    data
):

    pygame.draw.rect(
        screen,
        theme["panel"],
        rect
    )

    if user_id == my_id:

        border = theme[
            "accent"
        ]

        thickness = 2

    else:

        border = theme[
            "border"
        ]

        thickness = 1

    pygame.draw.rect(
        screen,
        border,
        rect,
        thickness
    )

    video_rect = pygame.Rect(
        rect.x + 3,
        rect.y + 3,
        rect.width - 6,
        rect.height - 29
    )

    frame = data.get(
        "frame"
    )

    if frame is not None:

        try:

            surface = (
                frame_to_surface(
                    frame,
                    video_rect.width,
                    video_rect.height
                )
            )

            screen.blit(
                surface,
                (
                    video_rect.centerx
                    - surface.get_width()
                    // 2,

                    video_rect.centery
                    - surface.get_height()
                    // 2
                )
            )

        except Exception:
            pass

    else:

        color = data.get(
            "icon_color",
            (200, 200, 200)
        )

        pygame.draw.circle(
            screen,
            color,
            video_rect.center,
            20
        )

    # --------------------------------------------------------
    # NAME BAR
    # --------------------------------------------------------

    name_bar = pygame.Rect(
        rect.x + 1,
        rect.bottom - 25,
        rect.width - 2,
        24
    )

    pygame.draw.rect(
        screen,
        theme["black"],
        name_bar
    )

    name = data.get(
        "username",
        f"User {user_id}"
    )

    if user_id == my_id:
        name += " (You)"

    color = data.get(
        "icon_color",
        (200, 200, 200)
    )

    pygame.draw.circle(
        screen,
        color,
        (
            rect.x + 11,
            rect.bottom - 13
        ),
        5
    )

    while (
        name
        and
        small_font.size(name)[0]
        > rect.width - 32
    ):

        name = name[:-1]

    name_surface = (
        small_font.render(
            name,
            True,
            theme["text"]
        )
    )

    screen.blit(
        name_surface,
        (
            rect.x + 21,
            rect.bottom - 21
        )
    )


# ============================================================
# DRAW CAMERA GRID
# ============================================================

def draw_camera_grid(
    local_frame
):

    tile_width = (
        CAMERA_AREA_WIDTH
        // GRID_COLUMNS
    )

    tile_height = (
        HEIGHT
        // GRID_ROWS
    )

    with users_lock:

        snapshot = {

            user_id:
                dict(data)

            for user_id, data
            in users.items()
        }

    # Local user before server ID arrives
    local_id = (
        my_id
        if my_id is not None
        else -1
    )

    if local_id not in snapshot:

        snapshot[
            local_id
        ] = create_default_user(
            local_id
        )

    snapshot[
        local_id
    ]["username"] = username

    snapshot[
        local_id
    ]["icon_color"] = icon_color

    snapshot[
        local_id
    ]["frame"] = local_frame

    if my_id is not None:

        snapshot.pop(
            -1,
            None
        )

    ordered = sorted(
        snapshot.items(),

        key=lambda item: (
            0
            if item[0] == my_id
            else 1,

            item[0]
        )
    )[:MAX_USERS]

    for slot in range(
        MAX_USERS
    ):

        row = (
            slot
            // GRID_COLUMNS
        )

        column = (
            slot
            % GRID_COLUMNS
        )

        x = (
            column
            * tile_width
        )

        y = (
            row
            * tile_height
        )

        rect = pygame.Rect(
            x,
            y,
            tile_width,
            tile_height
        )

        if slot < len(ordered):

            user_id, data = (
                ordered[slot]
            )

            draw_camera_tile(
                rect,
                user_id,
                data
            )

        else:

            pygame.draw.rect(
                screen,
                theme["panel"],
                rect
            )

            pygame.draw.rect(
                screen,
                theme["border"],
                rect,
                1
            )

            empty = small_font.render(
                f"Empty {slot + 1}",
                True,
                theme["muted"]
            )

            screen.blit(
                empty,
                empty.get_rect(
                    center=rect.center
                )
            )


# ============================================================
# FILE SOCKET
# ============================================================

def connect_file_server():

    file_socket = socket.socket(
        socket.AF_INET,
        socket.SOCK_STREAM
    )

    file_socket.settimeout(
        5.0
    )

    file_socket.connect(
        (
            SERVER_IP,
            FILE_PORT
        )
    )

    file_socket.settimeout(
        None
    )

    return file_socket


# ============================================================
# RECEIVE FILE SERVER CONTROL PACKET
# ============================================================

def receive_file_packet(sock):

    packet_type = recv_exact(
        sock,
        1
    )

    payload_size = struct.unpack(
        "!Q",
        recv_exact(
            sock,
            8
        )
    )[0]

    if payload_size > (
        MAX_FILE_SIZE
        + 1024 * 1024
    ):

        raise ValueError(
            "File server packet too large"
        )

    payload = recv_exact(
        sock,
        payload_size
    )

    return (
        packet_type,
        payload
    )


# ============================================================
# REFRESH SERVER FILE LIST
# ============================================================

def refresh_file_list_worker():

    global server_files
    global file_status
    global file_operation_running

    file_operation_running = True

    file_status = (
        "Loading file list..."
    )

    sock = None

    try:

        sock = (
            connect_file_server()
        )

        # L = list
        sock.sendall(
            b"L"
        )

        packet_type, payload = (
            receive_file_packet(
                sock
            )
        )

        if packet_type == b"L":

            result = json.loads(
                payload.decode(
                    "utf-8"
                )
            )

            with server_files_lock:

                server_files = (
                    result
                    if isinstance(
                        result,
                        list
                    )
                    else []
                )

            file_status = (
                f"{len(result)} "
                f"shared file(s)"
            )

        elif packet_type == b"E":

            file_status = (
                payload.decode(
                    "utf-8",
                    errors="replace"
                )
            )

    except Exception as error:

        file_status = (
            "File server error: "
            + str(error)
        )

    finally:

        if sock is not None:

            try:
                sock.close()
            except OSError:
                pass

        file_operation_running = (
            False
        )


def refresh_file_list():

    global file_operation_running

    if file_operation_running:
        return

    threading.Thread(
        target=(
            refresh_file_list_worker
        ),
        daemon=True
    ).start()


# ============================================================
# SELECT FILE FOR UPLOAD
# ============================================================

def select_upload_file():

    root = tk.Tk()

    root.withdraw()

    try:

        root.attributes(
            "-topmost",
            True
        )

    except tk.TclError:
        pass

    filename = (
        filedialog.askopenfilename(
            title=(
                "Select file to upload"
            ),
            filetypes=[
                (
                    "All files",
                    "*.*"
                )
            ]
        )
    )

    root.destroy()

    return filename


# ============================================================
# UPLOAD
# ============================================================

def upload_file_worker(
    filepath
):

    global file_status
    global file_operation_running

    file_operation_running = True

    sock = None

    try:

        if not os.path.isfile(
            filepath
        ):

            raise ValueError(
                "File does not exist"
            )

        file_size = (
            os.path.getsize(
                filepath
            )
        )

        if file_size > MAX_FILE_SIZE:

            raise ValueError(
                "File exceeds "
                "100 MB limit"
            )

        filename = os.path.basename(
            filepath
        )

        filename_data = (
            filename.encode(
                "utf-8"
            )
        )

        if len(filename_data) > 255:

            raise ValueError(
                "Filename is too long"
            )

        sock = (
            connect_file_server()
        )

        file_status = (
            "Uploading "
            + filename
            + "..."
        )

        # ----------------------------------------------------
        # UPLOAD REQUEST
        #
        # U
        # uint16 filename length
        # filename
        # uint64 file size
        # raw file
        # ----------------------------------------------------

        sock.sendall(
            b"U"
        )

        sock.sendall(
            struct.pack(
                "!H",
                len(filename_data)
            )
        )

        sock.sendall(
            filename_data
        )

        sock.sendall(
            struct.pack(
                "!Q",
                file_size
            )
        )

        sent = 0

        with open(
            filepath,
            "rb"
        ) as input_file:

            while True:

                chunk = (
                    input_file.read(
                        FILE_BUFFER_SIZE
                    )
                )

                if not chunk:
                    break

                sock.sendall(
                    chunk
                )

                sent += len(chunk)

                if file_size:

                    percent = int(
                        sent
                        * 100
                        / file_size
                    )

                    file_status = (
                        f"Uploading "
                        f"{filename}: "
                        f"{percent}%"
                    )

        # Server returns O packet.
        packet_type, payload = (
            receive_file_packet(
                sock
            )
        )

        if packet_type == b"O":

            file_status = (
                "Uploaded: "
                + filename
            )

            add_system_message(
                username
                + " uploaded "
                + filename
            )

        else:

            file_status = (
                payload.decode(
                    "utf-8",
                    errors="replace"
                )
            )

    except Exception as error:

        file_status = (
            "Upload failed: "
            + str(error)
        )

    finally:

        if sock is not None:

            try:
                sock.close()
            except OSError:
                pass

        file_operation_running = (
            False
        )

        # Refresh after upload
        refresh_file_list()


def start_upload():

    global file_status

    if file_operation_running:

        file_status = (
            "Another file operation "
            "is running."
        )

        return

    filepath = (
        select_upload_file()
    )

    if not filepath:

        file_status = (
            "Upload cancelled."
        )

        return

    threading.Thread(
        target=upload_file_worker,
        args=(
            filepath,
        ),
        daemon=True
    ).start()


# ============================================================
# DOWNLOAD
# ============================================================

def download_file_worker(
    filename
):

    global file_status
    global file_operation_running

    file_operation_running = True

    sock = None

    output_path = None

    try:

        filename_data = (
            filename.encode(
                "utf-8"
            )
        )

        if (
            not filename_data
            or
            len(filename_data) > 255
        ):

            raise ValueError(
                "Invalid filename"
            )

        sock = (
            connect_file_server()
        )

        file_status = (
            "Downloading "
            + filename
            + "..."
        )

        # ----------------------------------------------------
        # DOWNLOAD REQUEST
        #
        # D
        # uint16 filename length
        # filename
        # ----------------------------------------------------

        sock.sendall(
            b"D"
        )

        sock.sendall(
            struct.pack(
                "!H",
                len(filename_data)
            )
        )

        sock.sendall(
            filename_data
        )

        # Response starts with one-byte type.
        response_type = recv_exact(
            sock,
            1
        )

        # ----------------------------------------------------
        # ERROR RESPONSE
        # ----------------------------------------------------

        if response_type == b"E":

            payload_size = (
                struct.unpack(
                    "!Q",
                    recv_exact(
                        sock,
                        8
                    )
                )[0]
            )

            message = recv_exact(
                sock,
                payload_size
            ).decode(
                "utf-8",
                errors="replace"
            )

            raise ValueError(
                message
            )

        if response_type != b"D":

            raise ValueError(
                "Unexpected download response"
            )

        # ----------------------------------------------------
        # DOWNLOAD HEADER
        # ----------------------------------------------------

        name_length = (
            struct.unpack(
                "!H",
                recv_exact(
                    sock,
                    2
                )
            )[0]
        )

        received_name = (
            recv_exact(
                sock,
                name_length
            ).decode(
                "utf-8",
                errors="replace"
            )
        )

        received_name = (
            os.path.basename(
                received_name
            )
        )

        file_size = (
            struct.unpack(
                "!Q",
                recv_exact(
                    sock,
                    8
                )
            )[0]
        )

        if file_size > MAX_FILE_SIZE:

            raise ValueError(
                "Downloaded file "
                "exceeds size limit"
            )

        output_path = os.path.join(
            DOWNLOAD_DIR,
            received_name
        )

        remaining = file_size
        received = 0

        # ----------------------------------------------------
        # RECEIVE FILE DATA
        # ----------------------------------------------------

        with open(
            output_path,
            "wb"
        ) as output_file:

            while remaining > 0:

                chunk = sock.recv(
                    min(
                        FILE_BUFFER_SIZE,
                        remaining
                    )
                )

                if not chunk:

                    raise ConnectionError(
                        "Download interrupted"
                    )

                output_file.write(
                    chunk
                )

                received += len(
                    chunk
                )

                remaining -= len(
                    chunk
                )

                if file_size:

                    percent = int(
                        received
                        * 100
                        / file_size
                    )

                    file_status = (
                        f"Downloading "
                        f"{received_name}: "
                        f"{percent}%"
                    )

        file_status = (
            "Downloaded: "
            + received_name
        )

        add_system_message(
            "Downloaded "
            + received_name
        )

    except Exception as error:

        file_status = (
            "Download failed: "
            + str(error)
        )

        # Remove incomplete downloads.
        if (
            output_path
            and
            os.path.isfile(
                output_path
            )
        ):

            try:
                os.remove(
                    output_path
                )
            except OSError:
                pass

    finally:

        if sock is not None:

            try:
                sock.close()
            except OSError:
                pass

        file_operation_running = (
            False
        )


def download_file(filename):

    global file_status

    if file_operation_running:

        file_status = (
            "Another file operation "
            "is running."
        )

        return

    threading.Thread(
        target=download_file_worker,
        args=(
            filename,
        ),
        daemon=True
    ).start()


# ============================================================
# OPEN DOWNLOADS FOLDER
# ============================================================

def open_download_folder():

    try:

        if sys.platform.startswith(
            "win"
        ):

            os.startfile(
                DOWNLOAD_DIR
            )

        elif sys.platform == "darwin":

            subprocess.Popen([
                "open",
                DOWNLOAD_DIR
            ])

        else:

            subprocess.Popen([
                "xdg-open",
                DOWNLOAD_DIR
            ])

    except Exception as error:

        global file_status

        file_status = (
            "Cannot open downloads: "
            + str(error)
        )


# ============================================================
# DRAW BUTTON
# ============================================================

def draw_button(
    rect,
    text,
    color=None
):

    if color is None:

        color = theme[
            "panel2"
        ]

    mouse_position = (
        pygame.mouse.get_pos()
    )

    if rect.collidepoint(
        mouse_position
    ):

        if color == theme["accent"]:

            draw_color = theme[
                "accent_hover"
            ]

        else:

            draw_color = (
                55,
                55,
                55
            )

    else:

        draw_color = color

    pygame.draw.rect(
        screen,
        draw_color,
        rect
    )

    pygame.draw.rect(
        screen,
        theme["border"],
        rect,
        1
    )

    text_surface = (
        small_font.render(
            text,
            True,
            theme["text"]
        )
    )

    screen.blit(
        text_surface,
        text_surface.get_rect(
            center=rect.center
        )
    )


# ============================================================
# CHAT PANEL
# ============================================================

def draw_chat():

    panel = pygame.Rect(
        CAMERA_AREA_WIDTH,
        0,
        CHAT_WIDTH,
        HEIGHT
    )

    pygame.draw.rect(
        screen,
        theme["panel"],
        panel
    )

    pygame.draw.line(
        screen,
        theme["border"],
        (
            panel.x,
            0
        ),
        (
            panel.x,
            HEIGHT
        )
    )

    # --------------------------------------------------------
    # TITLE
    # --------------------------------------------------------

    title = large_font.render(
        "CamBunches",
        True,
        theme["text"]
    )

    screen.blit(
        title,
        (
            panel.x + 10,
            8
        )
    )

    # --------------------------------------------------------
    # USER COUNT
    # --------------------------------------------------------

    with users_lock:
        user_count = len(
            users
        )

    if (
        my_id is None
        or my_id not in users
    ):

        user_count += 1

    if connected:

        status = (
            f"Online | "
            f"{user_count}/20 users"
        )

        status_color = (
            theme["green"]
        )

    else:

        status = "Disconnected"

        status_color = (
            theme["red"]
        )

    status_surface = (
        small_font.render(
            status,
            True,
            status_color
        )
    )

    screen.blit(
        status_surface,
        (
            panel.x + 10,
            36
        )
    )

    # --------------------------------------------------------
    # FILE BUTTONS
    # --------------------------------------------------------

    server_files_button = (
        pygame.Rect(
            panel.x + 10,
            62,
            155,
            32
        )
    )

    upload_button = (
        pygame.Rect(
            panel.x + 175,
            62,
            165,
            32
        )
    )

    draw_button(
        server_files_button,
        "SERVER FILES"
    )

    draw_button(
        upload_button,
        "UPLOAD",
        theme["accent"]
    )

    # --------------------------------------------------------
    # CHAT CONTENT
    # --------------------------------------------------------

    with users_lock:

        names = {

            user_id:
                data.get(
                    "username",
                    f"User {user_id}"
                )

            for user_id, data
            in users.items()
        }

    if my_id is not None:

        names[
            my_id
        ] = username

    with chat_lock:

        messages = list(
            chat_log
        )

    lines = []

    for (
        user_id,
        message
    ) in messages:

        if user_id == 0:

            prefix = "System"

        else:

            prefix = names.get(
                user_id,
                f"User {user_id}"
            )

        text = (
            prefix
            + ": "
            + message
        )

        wrapped = wrap_text(
            text,
            small_font,
            CHAT_WIDTH - 20
        )

        lines.extend(
            wrapped
        )

    input_box = pygame.Rect(
        panel.x + 10,
        HEIGHT - 42,
        CHAT_WIDTH - 20,
        32
    )

    chat_top = 108

    maximum_lines = (
        (
            input_box.y
            - chat_top
            - 8
        )
        // 16
    )

    lines = lines[
        -maximum_lines:
    ]

    y = chat_top

    for line in lines:

        text_surface = (
            small_font.render(
                line,
                True,
                theme["text"]
            )
        )

        screen.blit(
            text_surface,
            (
                panel.x + 10,
                y
            )
        )

        y += 16

    # --------------------------------------------------------
    # INPUT
    # --------------------------------------------------------

    pygame.draw.rect(
        screen,
        theme["input_bg"],
        input_box
    )

    pygame.draw.rect(
        screen,
        theme[
            "input_border"
        ],
        input_box,
        1
    )

    displayed_input = (
        current_input
    )

    while (
        displayed_input
        and
        font.size(
            displayed_input
        )[0]
        > input_box.width - 14
    ):

        displayed_input = (
            displayed_input[1:]
        )

    input_surface = (
        font.render(
            displayed_input,
            True,
            theme["text"]
        )
    )

    screen.blit(
        input_surface,
        (
            input_box.x + 6,
            input_box.y + 6
        )
    )

    if (
        int(
            time.time() * 2
        )
        % 2
        == 0
    ):

        cursor_x = (
            input_box.x
            + 6
            + input_surface.get_width()
        )

        pygame.draw.line(
            screen,
            theme["accent"],
            (
                cursor_x,
                input_box.y + 5
            ),
            (
                cursor_x,
                input_box.bottom - 5
            ),
            2
        )

    return (
        server_files_button,
        upload_button
    )


# ============================================================
# FORMAT FILE SIZE
# ============================================================

def format_file_size(
    byte_count
):

    size = float(
        byte_count
    )

    if size < 1024:

        return (
            f"{int(size)} B"
        )

    size /= 1024

    if size < 1024:

        return (
            f"{size:.1f} KB"
        )

    size /= 1024

    if size < 1024:

        return (
            f"{size:.1f} MB"
        )

    size /= 1024

    return (
        f"{size:.1f} GB"
    )


# ============================================================
# FILE BROWSER
# ============================================================

def draw_file_browser():

    screen.fill(
        theme["bg"]
    )

    # --------------------------------------------------------
    # HEADER
    # --------------------------------------------------------

    title = large_font.render(
        "Server Shared Files",
        True,
        theme["text"]
    )

    screen.blit(
        title,
        (
            30,
            22
        )
    )

    back_button = pygame.Rect(
        WIDTH - 130,
        20,
        100,
        35
    )

    upload_button = pygame.Rect(
        WIDTH - 300,
        20,
        155,
        35
    )

    refresh_button = pygame.Rect(
        WIDTH - 465,
        20,
        150,
        35
    )

    downloads_button = (
        pygame.Rect(
            WIDTH - 650,
            20,
            170,
            35
        )
    )

    draw_button(
        downloads_button,
        "DOWNLOADS"
    )

    draw_button(
        refresh_button,
        "REFRESH"
    )

    draw_button(
        upload_button,
        "UPLOAD",
        theme["accent"]
    )

    draw_button(
        back_button,
        "BACK"
    )

    # --------------------------------------------------------
    # STATUS
    # --------------------------------------------------------

    status_surface = (
        small_font.render(
            file_status,
            True,
            theme["muted"]
        )
    )

    screen.blit(
        status_surface,
        (
            30,
            65
        )
    )

    pygame.draw.line(
        screen,
        theme["border"],
        (
            30,
            92
        ),
        (
            WIDTH - 30,
            92
        ),
        1
    )

    # --------------------------------------------------------
    # TABLE HEADINGS
    # --------------------------------------------------------

    screen.blit(
        small_font.render(
            "FILE NAME",
            True,
            theme["muted"]
        ),
        (
            45,
            108
        )
    )

    screen.blit(
        small_font.render(
            "SIZE",
            True,
            theme["muted"]
        ),
        (
            WIDTH - 260,
            108
        )
    )

    screen.blit(
        small_font.render(
            "ACTION",
            True,
            theme["muted"]
        ),
        (
            WIDTH - 145,
            108
        )
    )

    # --------------------------------------------------------
    # FILES
    # --------------------------------------------------------

    with server_files_lock:

        files = list(
            server_files
        )

    row_height = 42

    start_y = 135

    visible_count = (
        (
            HEIGHT - start_y - 20
        )
        // row_height
    )

    selected_files = files[
        file_scroll:
        file_scroll
        + visible_count
    ]

    download_buttons = []

    for offset, file_info \
            in enumerate(
                selected_files
            ):

        actual_index = (
            file_scroll
            + offset
        )

        row_y = (
            start_y
            + offset
            * row_height
        )

        row_rect = pygame.Rect(
            30,
            row_y,
            WIDTH - 60,
            row_height - 4
        )

        pygame.draw.rect(
            screen,
            theme["panel"],
            row_rect
        )

        pygame.draw.rect(
            screen,
            theme["border"],
            row_rect,
            1
        )

        filename = str(
            file_info.get(
                "name",
                "Unknown"
            )
        )

        file_size = int(
            file_info.get(
                "size",
                0
            )
        )

        # Truncate long display names.
        display_name = filename

        while (
            display_name
            and
            small_font.size(
                display_name
            )[0]
            > WIDTH - 390
        ):

            display_name = (
                display_name[:-1]
            )

        name_surface = (
            small_font.render(
                display_name,
                True,
                theme["text"]
            )
        )

        screen.blit(
            name_surface,
            (
                row_rect.x + 14,
                row_rect.y + 11
            )
        )

        size_surface = (
            small_font.render(
                format_file_size(
                    file_size
                ),
                True,
                theme["muted"]
            )
        )

        screen.blit(
            size_surface,
            (
                WIDTH - 260,
                row_rect.y + 11
            )
        )

        download_button = (
            pygame.Rect(
                WIDTH - 145,
                row_rect.y + 5,
                100,
                28
            )
        )

        draw_button(
            download_button,
            "DOWNLOAD",
            theme["accent"]
        )

        download_buttons.append(
            (
                download_button,
                actual_index,
                filename
            )
        )

    if not files:

        empty_surface = (
            font.render(
                "No shared files.",
                True,
                theme["muted"]
            )
        )

        screen.blit(
            empty_surface,
            empty_surface.get_rect(
                center=(
                    WIDTH // 2,
                    HEIGHT // 2
                )
            )
        )

    return (
        back_button,
        upload_button,
        refresh_button,
        downloads_button,
        download_buttons
    )


# ============================================================
# STARTUP DISPLAY
# ============================================================

screen.fill(
    theme["bg"]
)

startup = large_font.render(
    "Starting CamBunches...",
    True,
    theme["text"]
)

screen.blit(
    startup,
    startup.get_rect(
        center=(
            WIDTH // 2,
            HEIGHT // 2
        )
    )
)

pygame.display.flip()

pygame.event.pump()


# ============================================================
# OPEN CAMERA
# ============================================================

camera = open_camera()


# ============================================================
# CONNECT CHAT/CAMERA SERVER
# ============================================================

chat_socket = socket.socket(
    socket.AF_INET,
    socket.SOCK_STREAM
)

chat_socket.setsockopt(
    socket.IPPROTO_TCP,
    socket.TCP_NODELAY,
    1
)

chat_socket.settimeout(
    4.0
)

try:

    print(
        f"Connecting chat/video to "
        f"{SERVER_IP}:{CHAT_PORT}"
    )

    chat_socket.connect(
        (
            SERVER_IP,
            CHAT_PORT
        )
    )

    chat_socket.settimeout(
        None
    )

    connected = True

    print(
        "Chat/video connected."
    )

except (
    socket.timeout,
    OSError
) as error:

    connected = False

    print(
        "Connection failed:",
        error
    )

    add_system_message(
        "Chat connection failed: "
        + str(error)
    )


# ============================================================
# START RECEIVER
# ============================================================

if connected:

    receiver = threading.Thread(
        target=network_loop,
        daemon=True
    )

    receiver.start()


# ============================================================
# MAIN LOOP
# ============================================================

while running:

    # --------------------------------------------------------
    # BUTTON RECTS
    # --------------------------------------------------------

    server_files_button = None
    upload_button = None

    back_button = None
    file_upload_button = None
    refresh_button = None
    downloads_button = None

    download_buttons = []

    # --------------------------------------------------------
    # EVENTS
    # --------------------------------------------------------

    for event in pygame.event.get():

        if event.type == pygame.QUIT:

            running = False

        # ====================================================
        # KEYBOARD
        # ====================================================

        elif event.type == pygame.KEYDOWN:

            if event.key == pygame.K_ESCAPE:

                if mode == "files":

                    mode = "chat"

                else:

                    running = False

            elif (
                mode == "chat"
                and
                event.key
                == pygame.K_RETURN
            ):

                message = (
                    current_input.strip()
                )

                if message:

                    if connected:

                        send_text(
                            message
                        )

                    else:

                        add_system_message(
                            "Not connected"
                        )

                    current_input = ""

            elif (
                mode == "chat"
                and
                event.key
                == pygame.K_BACKSPACE
            ):

                current_input = (
                    current_input[:-1]
                )

            elif mode == "chat":

                if (
                    event.unicode
                    and
                    event.unicode.isprintable()
                    and
                    len(current_input)
                    < MAX_MESSAGE_LENGTH
                ):

                    current_input += (
                        event.unicode
                    )

            # File browser scrolling.
            elif mode == "files":

                if event.key == pygame.K_UP:

                    file_scroll = max(
                        0,
                        file_scroll - 1
                    )

                elif event.key == pygame.K_DOWN:

                    with server_files_lock:

                        maximum = max(
                            0,
                            len(server_files)
                            - 1
                        )

                    file_scroll = min(
                        maximum,
                        file_scroll + 1
                    )

        # ====================================================
        # MOUSE WHEEL
        # ====================================================

        elif (
            event.type
            == pygame.MOUSEWHEEL
            and
            mode == "files"
        ):

            with server_files_lock:

                maximum = max(
                    0,
                    len(server_files)
                    - 1
                )

            file_scroll -= (
                event.y
            )

            file_scroll = max(
                0,
                min(
                    maximum,
                    file_scroll
                )
            )

        # ====================================================
        # MOUSE
        # ====================================================

        elif (
            event.type
            == pygame.MOUSEBUTTONDOWN
            and
            event.button == 1
        ):

            # -----------------------------------------------
            # CHAT BUTTONS
            # -----------------------------------------------

            if mode == "chat":

                panel_x = (
                    CAMERA_AREA_WIDTH
                )

                server_rect = (
                    pygame.Rect(
                        panel_x + 10,
                        62,
                        155,
                        32
                    )
                )

                upload_rect = (
                    pygame.Rect(
                        panel_x + 175,
                        62,
                        165,
                        32
                    )
                )

                if server_rect.collidepoint(
                    event.pos
                ):

                    mode = "files"

                    refresh_file_list()

                elif upload_rect.collidepoint(
                    event.pos
                ):

                    start_upload()

            # -----------------------------------------------
            # FILE BROWSER BUTTONS
            # -----------------------------------------------

            elif mode == "files":

                back_rect = pygame.Rect(
                    WIDTH - 130,
                    20,
                    100,
                    35
                )

                upload_rect = (
                    pygame.Rect(
                        WIDTH - 300,
                        20,
                        155,
                        35
                    )
                )

                refresh_rect = (
                    pygame.Rect(
                        WIDTH - 465,
                        20,
                        150,
                        35
                    )
                )

                downloads_rect = (
                    pygame.Rect(
                        WIDTH - 650,
                        20,
                        170,
                        35
                    )
                )

                if back_rect.collidepoint(
                    event.pos
                ):

                    mode = "chat"

                elif upload_rect.collidepoint(
                    event.pos
                ):

                    start_upload()

                elif refresh_rect.collidepoint(
                    event.pos
                ):

                    refresh_file_list()

                elif downloads_rect.collidepoint(
                    event.pos
                ):

                    open_download_folder()

                else:

                    # ---------------------------------------
                    # CHECK DOWNLOAD BUTTONS
                    # ---------------------------------------

                    with server_files_lock:

                        files_snapshot = list(
                            server_files
                        )

                    row_height = 42
                    start_y = 135

                    visible_count = (
                        (
                            HEIGHT
                            - start_y
                            - 20
                        )
                        // row_height
                    )

                    visible_files = (
                        files_snapshot[
                            file_scroll:
                            file_scroll
                            + visible_count
                        ]
                    )

                    for offset, info \
                            in enumerate(
                                visible_files
                            ):

                        row_y = (
                            start_y
                            + offset
                            * row_height
                        )

                        button = pygame.Rect(
                            WIDTH - 145,
                            row_y + 5,
                            100,
                            28
                        )

                        if button.collidepoint(
                            event.pos
                        ):

                            filename = str(
                                info.get(
                                    "name",
                                    ""
                                )
                            )

                            if filename:

                                download_file(
                                    filename
                                )

                            break

    # ========================================================
    # CAMERA
    # ========================================================

    local_frame = None

    if camera is not None:

        success, captured = (
            camera.read()
        )

        if (
            success
            and
            captured is not None
            and
            captured.size > 0
        ):

            local_frame = captured

    # ========================================================
    # SEND VIDEO
    # ========================================================

    current_time = (
        time.monotonic()
    )

    if (
        connected
        and
        local_frame is not None
        and
        current_time
        - last_video_send
        >=
        1.0 / VIDEO_FPS
    ):

        send_video(
            local_frame
        )

        last_video_send = (
            current_time
        )

    # ========================================================
    # DRAW
    # ========================================================

    screen.fill(
        theme["bg"]
    )

    if mode == "chat":

        draw_camera_grid(
            local_frame
        )

        draw_chat()

    elif mode == "files":

        draw_file_browser()

    pygame.display.flip()

    clock.tick(
        30
    )


# ============================================================
# SHUTDOWN
# ============================================================

connected = False

if camera is not None:

    camera.release()

try:

    chat_socket.shutdown(
        socket.SHUT_RDWR
    )

except OSError:
    pass

try:

    chat_socket.close()

except OSError:
    pass

pygame.quit()
